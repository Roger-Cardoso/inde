#include "inde/application/writing_service.hpp"
#include <glib.h>

#include "inde/project/manifest.hpp"
#include "inde/project/document_state.hpp"

#include <algorithm>
#include <stdexcept>
#include <unordered_set>
#include <utility>

namespace inde::application {

const project::Project &WritingService::require_project() const {
  const auto *value = session_.current();
  if (!value)
    throw std::runtime_error("Nenhum projeto está aberto");
  return *value;
}

void WritingService::validate_placement(
    const std::optional<std::string> &editorial_node_id) const {
  if (!editorial_node_id)
    return;
  const auto found = std::find_if(
      session_.structural_nodes().begin(), session_.structural_nodes().end(),
      [&](const auto &node) { return node.id == *editorial_node_id; });
  if (found == session_.structural_nodes().end())
    throw std::runtime_error("A unidade editorial do Documento não existe");
}

void WritingService::validate_entity_references(
    const project::Document &value) const {
  for (const auto &reference : value.entity_references) {
    // A FK repete a invariante dentro da transação. Esta leitura antecipa uma
    // mensagem compreensível ao caso de uso antes da gravação.
    if (!store_.referenced_entity_exists(require_project().path(),
                                         reference.entity_id))
      throw std::runtime_error("A entidade vinculada ao Documento não existe");
  }
}

void WritingService::validate_organization(
    const project::Document &value) const {
  if (value.group_id &&
      !store_.document_group(require_project().path(), *value.group_id))
    throw std::runtime_error("O grupo do Documento não existe");
  if (value.revision_of_id) {
    const auto source =
        store_.document(require_project().path(), *value.revision_of_id);
    if (!source)
      throw std::runtime_error(
          "O Documento de origem desta revisão não existe");
    auto ancestor = source->revision_of_id;
    std::size_t depth = 0;
    while (ancestor) {
      if (*ancestor == value.id)
        throw std::runtime_error(
            "A cadeia de revisões documentais não pode formar um ciclo");
      const auto document =
          store_.document(require_project().path(), *ancestor);
      ancestor = document ? document->revision_of_id : std::nullopt;
      if (++depth > 1000)
        throw std::runtime_error(
            "A cadeia de revisões documentais é profunda demais");
    }
  }
}

std::vector<project::Document>
WritingService::documents(const persistence::DocumentQuery &query) const {
  return store_.documents(require_project().path(), query);
}

std::vector<project::DocumentSummary> WritingService::document_summaries(
    const persistence::DocumentQuery &query) const {
  return store_.document_summaries(require_project().path(), query);
}

std::size_t
WritingService::document_count(const persistence::DocumentQuery &query) const {
  return store_.document_count(require_project().path(), query);
}

std::optional<project::Document>
WritingService::document(const std::string &id) const {
  return store_.document(require_project().path(), id);
}

std::vector<project::DocumentGroup> WritingService::document_groups() const {
  return store_.document_groups(require_project().path());
}

std::optional<project::DocumentGroup>
WritingService::document_group(const std::string &id) const {
  return store_.document_group(require_project().path(), id);
}

project::DocumentGroup
WritingService::create_document_group(std::string name,
                                      std::string description) {
  const auto &active = require_project();
  const auto now = project::utc_now();
  project::DocumentGroup value{project::new_uuid(), std::move(name),
                               std::move(description), now, now};
  project::validate(value);
  store_.save_group(active.path(), value);
  return value;
}

project::DocumentGroup
WritingService::update_document_group(const project::DocumentGroup &input) {
  const auto &active = require_project();
  const auto current = store_.document_group(active.path(), input.id);
  if (!current)
    throw std::runtime_error("Grupo documental não encontrado");
  auto value = input;
  value.created_at = current->created_at;
  value.updated_at = project::utc_now();
  project::validate(value);
  store_.save_group(active.path(), value);
  return value;
}

void WritingService::delete_document_group(const std::string &id) {
  const auto &active = require_project();
  if (!store_.document_group(active.path(), id))
    throw std::runtime_error("Grupo documental não encontrado");
  store_.remove_group(active.path(), id);
}

project::Document
WritingService::create_document(std::string title,
                                std::optional<std::string> editorial_node_id) {
  const auto &active = require_project();
  validate_placement(editorial_node_id);
  const auto now = project::utc_now();
  project::Document value{project::new_uuid(),
                          std::move(editorial_node_id),
                          std::move(title),
                          {},
                          now,
                          now,
                          std::nullopt,
                          {},
                          {},
                          {},
                          std::nullopt,
                          project::DocumentPurpose::MainText,
                          std::nullopt,
                          {},
                          {},
                          {},
                          {}};
  project::validate(value);
  validate_organization(value);
  validate_entity_references(value);
  store_.save(active.path(), value);
  return value;
}

project::Document
WritingService::update_document(const project::Document &input) {
  return update_document_checked(input, nullptr);
}
project::Document WritingService::create_recovery_document(const project::Document &source) {
  const auto &owner=require_project();
  project::Document copy; copy.id=project::new_uuid(); copy.title="Resgate — "+source.title;
  copy.content=source.content; copy.formatting=source.formatting; copy.word_goal=source.word_goal;
  copy.inline_commands=source.inline_commands;
  copy.perspective=source.perspective; copy.created_at=copy.updated_at=project::utc_now();
  project::validate(copy); store_.save(owner.path(),copy); return copy;
}
project::Document WritingService::create_editorial_revision(const project::Document &expected,const std::string &label) {
  const auto &owner=require_project();const auto source=document(expected.id);
  if(!source || !project::same_document_state(*source,expected))throw std::runtime_error("A fonte mudou; reabra a criação da revisão");
  if(label.find_first_not_of(" \t\r\n")==std::string::npos || label.size()>256 ||
     label.find('\0')!=std::string::npos || !g_utf8_validate(label.data(),label.size(),nullptr))
    throw std::runtime_error("Informe uma identificação curta e válida para a revisão");
  project::Document copy;copy.id=project::new_uuid();copy.title="Revisão — "+expected.title;
  copy.content=expected.content;copy.formatting=expected.formatting;copy.word_goal=expected.word_goal;
  copy.inline_commands=expected.inline_commands;copy.perspective=expected.perspective;
  copy.group_id=expected.group_id;copy.editorial_node_id=expected.editorial_node_id;
  copy.purpose=project::DocumentPurpose::Revision;copy.revision_of_id=expected.id;copy.revision_label=label;
  copy.created_at=copy.updated_at=project::utc_now();project::validate(copy);validate_organization(copy);
  store_.save(owner.path(),copy);return copy;
}
project::Document WritingService::update_document_if_unchanged(const project::Document &input,
    const project::Document &expected) {
  return update_document_checked(input, &expected);
}
DocumentSaveSnapshot WritingService::save_snapshot(project::Document document,
    project::Document expected, std::uint64_t epoch, std::uint64_t revision) const {
  return {require_project(), session_.structural_nodes(), std::move(document), std::move(expected), epoch, revision, {}, 0, 0, 0};
}
project::Document WritingService::update_document_checked(const project::Document &input,
    const project::Document *expected) {
  const auto &active = require_project();
  const auto current = store_.document(active.path(), input.id);
  if (!current)
    throw std::runtime_error("Documento não encontrado");
  validate_placement(input.editorial_node_id);
  auto value = input;
  value.created_at = current->created_at;
  value.updated_at = project::utc_now();
  project::validate(value);
  validate_organization(value);
  validate_entity_references(value);
  std::unordered_set<std::string> retained_anchors;
  for (const auto &anchor : value.anchors)
    retained_anchors.insert(anchor.id);
  for (const auto &anchor : current->anchors) {
    if (!retained_anchors.contains(anchor.id) &&
        store_.text_references(active.path(), {value.id, true, anchor.id, 1, 0})
                .total != 0)
      throw std::runtime_error("A âncora “" + anchor.label +
                               "” é referenciada por outro Documento. "
                               "Desvincule seus usos antes de removê-la.");
  }
  if (expected) store_.save_if_unchanged(active.path(), value, *expected, active.manifest().project_id);
  else store_.save(active.path(), value);
  return value;
}

void WritingService::delete_document(const std::string &id) {
  const auto &active = require_project();
  if (!store_.document(active.path(), id))
    throw std::runtime_error("Documento não encontrado");
  if (store_.text_references(active.path(), {id, true, std::nullopt, 1, 0})
          .total != 0)
    throw std::runtime_error(
        "Este Documento é referenciado por outros Documentos. "
        "Abra Referências textuais e desvincule seus usos antes de removê-lo.");
  store_.remove(active.path(), id);
}

persistence::WritingStore::TextReferencePage WritingService::text_references(
    const persistence::WritingStore::TextReferenceQuery &query) const {
  return store_.text_references(require_project().path(), query);
}

project::DocumentTextReference
WritingService::add_text_reference(const std::string &source_document_id,
                                   const std::string &target_document_id,
                                   std::optional<std::string> target_anchor_id,
                                   std::string notes) {
  const auto &path = require_project().path();
  if (source_document_id == target_document_id)
    throw std::runtime_error(
        "Escolha outro Documento como destino da referência");
  if (!store_.document(path, source_document_id))
    throw std::runtime_error("Documento de origem não encontrado");
  const auto target = store_.document(path, target_document_id);
  if (!target)
    throw std::runtime_error("Documento de destino não encontrado");
  if (target_anchor_id &&
      std::ranges::none_of(target->anchors, [&](const auto &anchor) {
        return anchor.id == *target_anchor_id;
      }))
    throw std::runtime_error("A âncora não pertence ao Documento de destino");
  project::DocumentTextReference value{
      project::new_uuid(),         source_document_id, target_document_id,
      std::move(target_anchor_id), std::move(notes),   project::utc_now()};
  store_.add_text_reference(path, value);
  return value;
}

void WritingService::remove_text_reference(
    const std::string &source_document_id, const std::string &id) {
  store_.remove_text_reference(require_project().path(), source_document_id,
                               id);
}

} // namespace inde::application
