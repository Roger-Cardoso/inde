#include "contextual_planning_page.hpp"
#include "contextual_planning_helpers.hpp"
#include "inde/application/project_service.hpp"
#include "inde/ui/accessibility.hpp"
#include "inde/ui/bounded_choices.hpp"
#include "inde/ui/context_menu.hpp"
#include "inde/ui/overlay_dialog.hpp"
#include <algorithm>
#include <cmath>
#include <map>
#include <memory>
#include <unordered_set>
namespace inde::ui {
namespace {
Gtk::Label *label(const std::string &text) {
  auto *v = Gtk::make_managed<Gtk::Label>(text);
  v->set_xalign(0);
  v->set_wrap(true);
  v->set_max_width_chars(72);
  return v;
}
std::string display(const std::string &title, const std::string &description) {
  const auto text = Glib::ustring(title.empty() ? description : title);
  return text.substr(0, 100).raw() + (text.size() > 100 ? "…" : "");
}
struct Form {
  OverlayDialog *dialog;
  Gtk::Entry *title;
  Gtk::TextView *body;
  Gtk::Label *error;
};
Form form(Gtk::Window &owner, const std::string &caption,
          const std::string &hint, const std::string &title,
          const std::string &body, bool with_title) {
  auto *d = new OverlayDialog(caption, owner, true);
  d->set_secondary_text(hint);
  auto *e = Gtk::make_managed<Gtk::Entry>();
  e->set_text(title);
  e->set_max_length(200);
  set_accessible_label(*e, "Título do acontecimento (opcional)");
  if (with_title) {
    d->get_content_area()->append(*label("Título (opcional)"));
    d->get_content_area()->append(*e);
  }
  auto *t = Gtk::make_managed<Gtk::TextView>();
  t->set_wrap_mode(Gtk::WrapMode::WORD_CHAR);
  t->get_buffer()->set_text(body);
  set_accessible_label(*t, with_title ? "Descrição do acontecimento"
                                      : "Nota desta participação");
  d->get_content_area()->append(*label(with_title
                                           ? "Descrição (pode ser incompleta)"
                                           : "Nota livre (opcional)"));
  auto *scroll = Gtk::make_managed<Gtk::ScrolledWindow>();
  scroll->set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
  scroll->set_min_content_height(160);
  scroll->set_child(*t);
  d->get_content_area()->append(*scroll);
  // Unparented managed entries are not owned by a widget. Notes have no title.
  if (!with_title) {
    d->get_content_area()->append(*e);
    e->set_visible(false);
  }
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Salvar", Gtk::ResponseType::ACCEPT);
  return {d, e, t, error};
}
} // namespace
ContextualPlanningPage::ContextualPlanningPage(application::ProjectService &p)
    : Gtk::Box(Gtk::Orientation::VERTICAL, 6), project_(p), service_(p) {
  help_.set_text("Arraste para organizar. Abra um trecho para desenvolver seu interior.");
  help_.add_css_class("dim-label");
  help_.set_tooltip_text("Disposição visual não declara tempo, causalidade, categoria ou ordem narrativa. Consulte Superfície para outras ações.");
  help_.set_xalign(0);
  help_.set_wrap(true);
  help_.set_max_width_chars(90);
  append(help_);
  bound_choice_width(plans_);
  set_accessible_label(plans_, "Composição contextual desta Obra");
  plans_.set_hexpand(true);
  navigation_.append(back_);
  navigation_.append(plans_);
  assembly_.set_label("Montagem");
  assembly_.set_tooltip_text(
      "Criar, reunir e reutilizar trechos; experimentar opções");
  navigation_.append(assembly_);
  append(navigation_);
  actions_.set_selection_mode(Gtk::SelectionMode::NONE);
  actions_.set_column_spacing(6);
  actions_.set_row_spacing(6);
  actions_.set_max_children_per_line(1);
  actions_.set_min_children_per_line(1);
  for (auto *b : {&new_plan_, &reuse_, &compose_, &group_, &slots_, &refresh_})
    actions_.append(*b);
  auto *assembly_pop = Gtk::make_managed<Gtk::Popover>();
  assembly_pop->set_child(actions_);
  assembly_.set_popover(*assembly_pop);
  quick_.set_placeholder_text(
      "Anote uma ideia ou um trecho; Enter para acrescentar");
  quick_.set_hexpand(true);
  quick_.set_max_length(200);
  set_accessible_label(quick_, "Capturar trecho sem classificação");
  capture_.append(quick_);
  capture_.append(new_moment_);
  append(capture_);
  focus_.set_xalign(0);
  focus_.set_ellipsize(Pango::EllipsizeMode::END);
  focus_.set_hexpand(true);
  selection_.append(focus_);
  selection_.append(develop_);
  selection_.append(text_);
  more_.set_label("Trabalhar trecho");
  auto *more_pop = Gtk::make_managed<Gtk::Popover>();
  auto *more_list = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 3);
  for (auto *b :
       {&edit_, &note_, &role_, &scale_, &up_, &down_, &context_, &detach_})
    more_list->append(*b);
  auto *more_scroll = Gtk::make_managed<Gtk::ScrolledWindow>();
  more_scroll->set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
  more_scroll->set_max_content_height(360);
  more_scroll->set_propagate_natural_height(true);
  more_scroll->set_child(*more_list);
  more_pop->set_child(*more_scroll);
  more_.set_popover(*more_pop);
  selection_.append(more_);
  append(selection_);
  for (auto *b : {&new_plan_, &reuse_, &compose_, &group_, &slots_, &refresh_})
    b->signal_clicked().connect([assembly_pop] { assembly_pop->popdown(); });
  for (auto *b :
       {&edit_, &note_, &role_, &scale_, &up_, &down_, &context_, &detach_})
    b->signal_clicked().connect([more_pop] { more_pop->popdown(); });
  rows_.set_selection_mode(Gtk::SelectionMode::SINGLE);
  rows_.add_css_class("boxed-list");
  scroll_.set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
  scroll_.set_vexpand(true);
  scroll_.set_child(rows_);
  init_visual();
  pager_.append(previous_);
  pager_.append(page_label_);
  pager_.append(next_);
  append(pager_);
  plans_.signal_changed().connect([this] {
    if (loading_)
      return;
    if (!quick_.get_text().empty()) {
      loading_ = true;
      plans_.set_active_id(snapshot_.plan_id);
      loading_ = false;
      status_.emit("A ideia por acrescentar foi preservada. Acrescente-a ou "
                   "limpe o campo antes de trocar de montagem.");
      return;
    }
    offset_ = 0;
    selected_id_.clear();
    selected_slot_.clear();
    selected_option_.clear();
    context_returns_.clear();
    module_returns_.clear();
    refresh(work_id_);
  });
  rows_.signal_row_selected().connect([this](Gtk::ListBoxRow *row) {
    if (loading_)
      return;
    context_returns_.clear();
    const auto at =
        row ? offset_ + row->get_index() : snapshot_.participations.size();
    selected_id_ = at < snapshot_.participations.size()
                       ? snapshot_.participations[at].id
                       : "";
    if (list_mode_.get_active()) canvas_.select_part(selected_id_);
    selection_actions();
  });
  new_plan_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::create_plan));
  auto capture = [this] {
    if (quick_.get_text().empty()) {
      edit_content(true);
      return;
    }
    try {
      selected_id_ = service_.create_moment(snapshot_, quick_.get_text(), "",
          capture_placement_ ? &*capture_placement_ : nullptr);
      if(capture_placement_)capture_placement_->x=std::min<std::int64_t>(100000,capture_placement_->x+300);
      offset_ = (snapshot_.participations.size() / 50) * 50;
      quick_.set_text("");
      refresh(work_id_);
      quick_.grab_focus();
    } catch (const std::exception &e) {
      status_.emit(e.what());
    }
  };
  new_moment_.signal_clicked().connect(capture);
  quick_.signal_activate().connect(capture);
  develop_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::develop_selected));
  back_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::return_module));
  role_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::edit_role));
  scale_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::edit_scale));
  group_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::group_parts));
  compose_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::compose_existing));
  edit_.signal_clicked().connect([this] { edit_content(false); });
  note_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::edit_note));
  reuse_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::reuse));
  detach_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::remove));
  up_.signal_clicked().connect([this] {
    execute([&] { service_.move(snapshot_, selected().id, -1); });
  });
  down_.signal_clicked().connect(
      [this] { execute([&] { service_.move(snapshot_, selected().id, 1); }); });
  refresh_.signal_clicked().connect([this] { refresh(work_id_); });
  slots_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::show_slots));
  context_.signal_clicked().connect([this] { show_context(); });
  text_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::open_text));
  previous_.signal_clicked().connect([this] {
    if (offset_ >= 50) {
      offset_ -= 50;
      selected_id_.clear();
      render();
    }
  });
  next_.signal_clicked().connect([this] {
    if (offset_ + 50 < snapshot_.participations.size()) {
      offset_ += 50;
      selected_id_.clear();
      render();
    }
  });
  reset();
}
void ContextualPlanningPage::reset() {
  loading_ = true;
  project_id_.clear();
  work_id_.clear();
  selected_id_.clear();
  selected_slot_.clear();
  selected_option_.clear();
  context_returns_.clear();
  module_returns_.clear();
  quick_.set_text("");
  offset_ = 0;
  snapshot_ = {};
  capture_placement_.reset();
  plans_.remove_all();
  loading_ = false;
  new_plan_.set_sensitive(false);
  render();
}
void ContextualPlanningPage::refresh(const std::string &work_id) {
  if (!project_.current()) {
    reset();
    return;
  }
  const auto project_id = project_.current()->manifest().project_id;
  if (project_id != project_id_ || work_id != work_id_) {
    reset();
    project_id_ = project_id;
    work_id_ = work_id;
  }
  if (work_id.empty()) {
    new_plan_.set_sensitive(false);
    return;
  }
  const auto wanted = plans_.get_active_id().raw();
  try {
    const auto plans = service_.plans(work_id);
    loading_ = true;
    plans_.remove_all();
    for (const auto &p : plans)
      plans_.append(p.id, display(p.title, ""));
    if (!wanted.empty())
      plans_.set_active_id(wanted);
    if (plans_.get_active_row_number() < 0 && !plans.empty())
      plans_.set_active(0);
    loading_ = false;
    new_plan_.set_sensitive(true);
    snapshot_ = plans_.get_active_id().empty()
                    ? application::ContextualSnapshot{}
                    : service_.snapshot(plans_.get_active_id());
  } catch (const std::exception &e) {
    loading_ = false;
    snapshot_ = {};
    new_plan_.set_sensitive(false);
    status_.emit(e.what());
  }
  render();
}
void ContextualPlanningPage::render() {
  loading_ = true;
  const auto available = service_.included_participations(snapshot_);
  const std::unordered_set<std::string> included(available.begin(),
                                                 available.end());
  while (auto *child = rows_.get_first_child())
    rows_.remove(*child);
  if (offset_ >= snapshot_.participations.size())
    offset_ = snapshot_.participations.empty()
                  ? 0
                  : ((snapshot_.participations.size() - 1) / 50) * 50;
  for (std::size_t i = offset_;
       i < std::min(offset_ + 50, snapshot_.participations.size()); ++i) {
    const auto &x = snapshot_.participations[i];
    auto *body = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 4);
    body->set_margin(8);
    auto *title =
        label(std::to_string(i + 1) + " · " + display(x.title, x.description));
    title->add_css_class("heading");
    body->append(*title);
    body->set_tooltip_text(x.description);
    const auto member =
        std::find_if(snapshot_.memberships.begin(), snapshot_.memberships.end(),
                     [&](auto &m) { return m.participation_id == x.id; });
    std::string role = "Continuação comum";
    if (member != snapshot_.memberships.end()) {
      const auto option =
          std::find_if(snapshot_.options.begin(), snapshot_.options.end(),
                       [&](auto &o) { return o.id == member->option_id; });
      role = (option == snapshot_.options.end() ? "Opção ausente"
                                                : option->title) +
             std::string(included.contains(x.id)
                             ? " · na escolha atual"
                             : " · fora da escolha atual ou não resolvida");
    }
    if (member != snapshot_.memberships.end())
      body->append(*label(role));
    std::string details = x.scale;
    if (!x.category.empty())
      details += (details.empty() ? "" : " · ") + x.category;
    if (x.parallel)
      details += (details.empty() ? "" : " · ") + std::string("Paralelo");
    if (!x.contents_plan_id.empty())
      details += (details.empty() ? "" : " · ") +
                 std::string("Tem interior · Desenvolver trecho");
    if (!details.empty())
      body->append(*label(details));
    if (!x.note.empty())
      body->append(*label("Nota local: " + display("", x.note)));
    rows_.append(*body);
    const auto id = x.id;
    auto choose = [this, id] {
      selected_id_ = id;
      for (auto *child = rows_.get_first_child(); child;
           child = child->get_next_sibling()) {
        auto *r = dynamic_cast<Gtk::ListBoxRow *>(child);
        if (r &&
            static_cast<std::size_t>(r->get_index()) + offset_ <
                snapshot_.participations.size() &&
            snapshot_
                    .participations[static_cast<std::size_t>(r->get_index()) +
                                    offset_]
                    .id == id) {
          rows_.select_row(*r);
          break;
        }
      }
    };
    attach_context_menu(*body, {{"Desenvolver trecho",
                                 [this, choose] {
                                   choose();
                                   develop_selected();
                                 }},
                                {"Editar conteúdo compartilhado",
                                 [this, choose] {
                                   choose();
                                   edit_content(false);
                                 }},
                                {"Papel neste conjunto…",
                                 [this, choose] {
                                   choose();
                                   edit_role();
                                 }},
                                {"Escala do trecho…",
                                 [this, choose] {
                                   choose();
                                   edit_scale();
                                 }},
                                {"Escrever neste contexto",
                                 [this, choose] {
                                   choose();
                                   open_text();
                                 }},
                                {"Contexto desta participação",
                                 [this, choose] {
                                   choose();
                                   show_context();
                                 }},
                                {"Retirar participação",
                                 [this, choose] {
                                   choose();
                                   remove();
                                 },
                                 "", true, true, true}});
    if (x.id == selected_id_)
      rows_.select_row(*rows_.get_row_at_index(static_cast<int>(i - offset_)));
  }
  if (!rows_.get_selected_row())
    selected_id_.clear();
  loading_ = false;
  for (auto *b : {&new_moment_, &reuse_, &slots_})
    b->set_sensitive(!snapshot_.plan_id.empty());
  for (auto *b : {&edit_, &note_, &detach_, &up_, &down_, &context_, &text_,
                  &scale_, &role_})
    b->set_sensitive(!selected_id_.empty());
  previous_.set_sensitive(offset_ >= 50);
  next_.set_sensitive(offset_ + 50 < snapshot_.participations.size());
  page_label_.set_text(std::to_string(snapshot_.participations.size()) +
                       " trechos · página " + std::to_string(offset_ / 50 + 1));
  pager_.set_visible(list_mode_.get_active() && snapshot_.participations.size() > 50);
  quick_.set_sensitive(!snapshot_.plan_id.empty());
  compose_.set_sensitive(!snapshot_.plan_id.empty());
  group_.set_sensitive(snapshot_.participations.size() >= 2);
  selection_actions();
  refresh_visual();
}
const application::ContextualParticipation &
ContextualPlanningPage::selected() const {
  const auto at = std::find_if(
      snapshot_.participations.begin(), snapshot_.participations.end(),
      [this](const auto &x) { return x.id == selected_id_; });
  if (at == snapshot_.participations.end())
    throw std::runtime_error("Selecione uma participação");
  return *at;
}
void ContextualPlanningPage::execute(const std::function<void()> &f) {
  try {
    f();
  } catch (const std::exception &e) {
    status_.emit(e.what());
    return;
  }
  status_.emit("Operação contextual gravada; reversão disponível no histórico "
               "do Projeto.");
  refresh(work_id_);
}
void ContextualPlanningPage::create_plan() {
  if (!quick_.get_text().empty()) {
    status_.emit(
        "Acrescente ou limpe a ideia pendente antes de criar outra montagem.");
    return;
  }
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  auto *d = new OverlayDialog("Nova composição contextual", *owner, true);
  auto *title = Gtk::make_managed<Gtk::Entry>();
  title->set_max_length(200);
  set_accessible_label(*title, "Nome da composição contextual");
  d->get_content_area()->append(*label("Nome da composição"));
  d->get_content_area()->append(*title);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Criar", Gtk::ResponseType::ACCEPT);
  const auto work = work_id_, project = project_id_;
  d->signal_response().connect(sigc::track_obj(
      [this, d, title, error, work, project](int r) {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        std::string id;
        try {
          if (project_id_ != project || work_id_ != work)
            throw std::runtime_error("Contexto de trabalho mudou");
          id = service_.create_plan(work, title->get_text());
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work);
        loading_ = true;
        plans_.set_active_id(id);
        loading_ = false;
        refresh(work);
      },
      *this));
  d->present();
}
void ContextualPlanningPage::edit_content(bool creating) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = contextual_ui::observation(snapshot_);
    const auto count = snapshot_.participations.size();
    const auto placement = capture_placement_;
    application::ContextualMoment moment;
    if (!creating)
      moment = service_.moment(selected().moment_id);
    auto f =
        form(*owner,
             creating ? "Novo acontecimento" : "Editar conteúdo compartilhado",
             creating ? "Título ou descrição basta. Nenhum fato, data ou "
                        "efeito será inferido."
                      : "Alterar esta origem afeta todas as participações "
                        "abaixo; notas locais permanecem.",
             moment.title, moment.description, true);
    if (!creating) {
      std::map<std::string, std::size_t> counts;
      for (const auto &use : moment.uses)
        ++counts[use.plan_title + " · " + use.plan_id];
      auto *scope = Gtk::make_managed<Gtk::Expander>(
          std::to_string(moment.uses.size()) + " participações em " +
          std::to_string(counts.size()) + " composições — consultar alcance");
      std::string uses;
      for (const auto &[name, count] : counts)
        uses += name + " (" + std::to_string(count) + ")\n";
      scope->set_child(*label(uses));
      f.dialog->get_content_area()->prepend(*scope);
    }
    f.dialog->signal_response().connect(sigc::track_obj(
        [this, f, creating, expected, moment, count, placement](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            if (creating) {
              selected_id_ =
                  service_.create_moment(expected, f.title->get_text(),
                                         f.body->get_buffer()->get_text(),
                                         placement ? &*placement : nullptr);
              offset_ = (count / 50) * 50;
            } else
              service_.update_moment(moment, f.title->get_text(),
                                     f.body->get_buffer()->get_text());
          } catch (const std::exception &e) {
            f.error->set_text(e.what());
            f.dialog->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    f.dialog->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_note() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = contextual_ui::observation(snapshot_);
    const auto x = selected();
    auto f = form(*owner, "Nota desta participação",
                  "Só este uso em " + snapshot_.title +
                      ". Não modifica o acontecimento nem declara herança.",
                  "", x.note, false);
    f.dialog->signal_response().connect(sigc::track_obj(
        [this, f, expected, id = x.id](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.set_note(expected, id, f.body->get_buffer()->get_text());
          } catch (const std::exception &e) {
            f.error->set_text(e.what());
            f.dialog->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    f.dialog->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::reuse() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  const auto expected = contextual_ui::observation(snapshot_);
  const auto count = snapshot_.participations.size();
  auto *d = new OverlayDialog("Reutilizar acontecimento", *owner, true);
  d->set_secondary_text(
      "Escolha uma origem da mesma Obra. Conteúdo será compartilhado; notas e "
      "ordem são locais. Não é confirmação de realização.");
  auto *search = Gtk::make_managed<Gtk::Entry>();
  set_accessible_label(*search, "Buscar acontecimento");
  auto *find = Gtk::make_managed<Gtk::Button>("Buscar");
  auto *combo = Gtk::make_managed<Gtk::ComboBoxText>();
  bound_choice_width(*combo);
  set_accessible_label(*combo, "Acontecimento a reutilizar");
  auto *previous = Gtk::make_managed<Gtk::Button>("Anterior"),
       *next = Gtk::make_managed<Gtk::Button>("Próxima");
  auto *hint = label("");
  auto *error = label("");
  error->add_css_class("error");
  for (auto *v : std::vector<Gtk::Widget *>{search, find, combo, previous, hint,
                                            next, error})
    d->get_content_area()->append(*v);
  struct Query {
    std::size_t offset{};
    std::string search;
    application::ContextualMomentPage page;
  };
  auto state = std::make_shared<Query>();
  auto load = [this, state, expected, combo, previous, next, hint, error] {
    try {
      state->page =
          service_.moments(expected.work_id, state->search, state->offset);
      combo->remove_all();
      for (const auto &m : state->page.rows)
        combo->append(m.id, display(m.title, m.description));
      if (!state->page.rows.empty())
        combo->set_active(0);
      previous->set_sensitive(state->offset > 0);
      next->set_sensitive(state->page.more);
      hint->set_text("Página " + std::to_string(state->offset / 50 + 1) +
                     " · " + std::to_string(state->page.rows.size()) +
                     " resultados (até 50)");
      error->set_text("");
    } catch (const std::exception &e) {
      combo->remove_all();
      previous->set_sensitive(false);
      next->set_sensitive(false);
      error->set_text(e.what());
    }
  };
  find->signal_clicked().connect(sigc::track_obj(
      [state, search, load] {
        state->offset = 0;
        state->search = search->get_text();
        load();
      },
      *this));
  search->signal_activate().connect(sigc::track_obj(
      [state, search, load] {
        state->offset = 0;
        state->search = search->get_text();
        load();
      },
      *this));
  previous->signal_clicked().connect(sigc::track_obj(
      [state, load] {
        if (state->offset >= 50)
          state->offset -= 50;
        load();
      },
      *this));
  next->signal_clicked().connect(sigc::track_obj(
      [state, load] {
        if (state->page.more)
          state->offset += 50;
        load();
      },
      *this));
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Reutilizar", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj(
      [this, d, combo, error, expected, state, count](int r) {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        try {
          const auto id = combo->get_active_id().raw();
          const auto at =
              std::find_if(state->page.rows.begin(), state->page.rows.end(),
                           [&](const auto &row) { return row.id == id; });
          if (at == state->page.rows.end())
            throw std::runtime_error("Escolha um acontecimento desta página");
          const auto observed = service_.moment(id);
          if (observed.title != at->title ||
              observed.description != at->description)
            throw std::runtime_error("O acontecimento mudou desde a lista; "
                                     "busque novamente antes de reutilizar");
          selected_id_ = service_.reuse_moment(expected, observed);
          offset_ = (count / 50) * 50;
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work_id_);
      },
      *this));
  load();
  d->present();
}
void ContextualPlanningPage::remove() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = contextual_ui::observation(snapshot_);
    const auto id = selected_id_;
    selected();
    auto *d = new OverlayDialog("Retirar participação", *owner, true);
    d->set_secondary_text(
        "Retira somente este uso e sua nota local. O acontecimento e os outros "
        "usos permanecem. Há reversão no histórico do Projeto.");
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Retirar participação", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, error, expected, id](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.detach(expected, id);
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          selected_id_.clear();
          refresh(work_id_);
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
ViewState ContextualPlanningPage::capture_view() const {
  const auto camera = canvas_.camera();
  ViewState::Array capture_point;
  if(capture_placement_){capture_point.emplace_back(capture_placement_->x);capture_point.emplace_back(capture_placement_->y);}
  ViewState::Array returns;
  for (const auto &id : context_returns_)
    returns.emplace_back(id);
  ViewState::Array modules;
  for (const auto &frame : module_returns_)
    modules.emplace_back(frame);
  return ViewState::Object{
      {"plan", plans_.get_active_id().raw()},
      {"participation", selected_id_},
      {"slot", selected_slot_},
      {"option", selected_option_},
      {"origin_returns", returns},
      {"module_returns", modules},
      {"quick_draft", quick_.get_text().raw()},
      {"capture_point", capture_point},
      {"visual_list", list_mode_.get_active()},
      {"camera_x", static_cast<std::int64_t>(std::llround(camera[0]*1000))},
      {"camera_y", static_cast<std::int64_t>(std::llround(camera[1]*1000))},
      {"camera_zoom", static_cast<std::int64_t>(std::llround(camera[2]*1000))},
      {"offset", static_cast<std::int64_t>(offset_)},
      {"scroll", scroll_state(scroll_.get_vadjustment()->get_value())}};
}
void ContextualPlanningPage::restore_view(const std::string &work,
                                          const ViewState &v) {
  const auto draft = v.as_object().contains("quick_draft")
                         ? v.at("quick_draft").as_string()
                         : std::string{};
  if (draft.size() > 800 ||
      !g_utf8_validate(draft.data(), draft.size(), nullptr) ||
      draft.find('\0') != std::string::npos ||
      g_utf8_strlen(draft.data(), draft.size()) > 200)
    throw std::runtime_error(
        "Rascunho de captura inválido; contexto não foi aplicado");
  auto offset = view_offset(v.at("offset"));
  if (offset > 1950 || offset % 50)
    throw std::runtime_error("Página contextual inválida");
  const auto plan = v.at("plan").as_string(),
             participation = v.at("participation").as_string();
  if (plan.size() > 128 || participation.size() > 128)
    throw std::runtime_error("Identidade contextual inválida");
  refresh(work);
  selected_slot_ =
      v.as_object().contains("slot") ? v.at("slot").as_string() : "";
  selected_option_ =
      v.as_object().contains("option") ? v.at("option").as_string() : "";
  if (selected_slot_.size() > 128 || selected_option_.size() > 128)
    throw std::runtime_error("Identidade de encaixe inválida");
  loading_ = true;
  if (!plans_.set_active_id(plan))
    plans_.set_active(-1);
  loading_ = false;
  quick_.set_text(draft);
  if (plan.empty() || plans_.get_active_id().empty()) {
    snapshot_ = {};
    render();
    return;
  }
  refresh(work);
  offset_ = offset;
  selected_id_ = participation;
  context_returns_.clear();
  module_returns_.clear();
  if (v.as_object().contains("module_returns")) {
    const auto &frames = v.at("module_returns").as_array();
    if (frames.size() > 16)
      throw std::runtime_error("Retornos de trechos excedem 16 níveis");
    for (const auto &frame : frames) {
      const auto text = frame.as_string();
      if (text.size() > 4096)
        throw std::runtime_error("Retorno de trecho inválido");
      parse_view_state(text);
      module_returns_.push_back(text);
    }
  }
  if (v.as_object().contains("origin_returns")) {
    const auto &rows = v.at("origin_returns").as_array();
    if (rows.size() > 16)
      throw std::runtime_error("Retornos de origem excedem limite");
    for (const auto &row : rows) {
      const auto id = row.as_string();
      if (id.empty() || id.size() > 1024)
        throw std::runtime_error("Origem inválida");
      context_returns_.push_back(id);
    }
  }
  render();
  if(v.as_object().contains("visual_list"))list_mode_.set_active(v.at("visual_list").as_boolean());
  if(v.as_object().contains("camera_x"))canvas_.camera({static_cast<double>(v.at("camera_x").as_integer())/1000.0,static_cast<double>(v.at("camera_y").as_integer())/1000.0,static_cast<double>(v.at("camera_zoom").as_integer())/1000.0});
  capture_placement_.reset();
  if(v.as_object().contains("capture_point")){
    const auto &xy=v.at("capture_point").as_array();
    if(!xy.empty()){
      if(xy.size()!=2||xy[0].as_integer()<-100000||xy[0].as_integer()>100000||xy[1].as_integer()<-100000||xy[1].as_integer()>100000)throw std::runtime_error("Ponto de captura visual inválido");
      application::ContextualVisualItem point;point.x=xy[0].as_integer();point.y=xy[1].as_integer();capture_placement_=point;
    }
  }
  const auto scroll = view_scroll(v.at("scroll"));
  Glib::signal_idle().connect_once(sigc::track_obj(
      [this, scroll] { scroll_.get_vadjustment()->set_value(scroll); }, *this));
}
void ContextualPlanningPage::reveal(const std::string &work,
                                    const std::string &plan,
                                    const std::string &part) {
  refresh(work);
  loading_ = true;
  const auto found = plans_.set_active_id(plan);
  loading_ = false;
  if (!found)
    throw std::runtime_error("Composição contextual não encontrada");
  offset_ = 0;
  selected_id_.clear();
  refresh(work);
  if (!part.empty())
    navigate_context(plan, part);
}
} // namespace inde::ui
