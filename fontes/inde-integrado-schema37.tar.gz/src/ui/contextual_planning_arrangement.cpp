#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include <algorithm>
#include <map>
#include <memory>
#include <set>

namespace inde::ui {
using namespace contextual_ui;
namespace {
// Bounded rows even for a large selection. The reviewed vector is the command;
// geometry only supplies an optional, visible proposal.
class SequenceReview final : public Gtk::Box {
public:
  SequenceReview(const application::ContextualSnapshot &snapshot,
                 const std::vector<std::string> &parts)
      : Gtk::Box(Gtk::Orientation::VERTICAL, 5), snapshot_(snapshot), parts_(parts) {
    for (const auto &p : snapshot.participations)
      titles_.emplace(p.id, caption(p.title.empty() ? p.description : p.title));
    order_.append("local", "Ordem local atual");
    order_.append("horizontal", "Propor: esquerda para direita");
    order_.append("vertical", "Propor: cima para baixo");
    order_.set_name("sequence-order");
    set_accessible_label(order_, "Proposta de ordem para revisão");
    append(order_);
    scroll_.set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
    scroll_.set_min_content_height(std::min(180, static_cast<int>(parts.size()) * 36));
    scroll_.set_max_content_height(220);
    scroll_.set_child(rows_);
    append(scroll_);
    for (auto *b : {&before_, &after_, &previous_, &next_})
      controls_.append(*b);
    controls_.append(page_);
    append(controls_);
    reorder.set_active(true);
    reorder.set_name("sequence-reorder");
    succession.set_name("sequence-succession");
    append(reorder);
    append(succession);
    const std::set<std::string> chosen(parts.begin(), parts.end());
    std::vector<std::string> declared;
    for (const auto &e : snapshot.dependencies)
      if (chosen.contains(e.source) && chosen.contains(e.target))
        declared.push_back(kind(e.kind) + " · " + titles_.at(e.source) + " → " +
                           titles_.at(e.target) + (e.note.empty() ? "" : "\n" + caption(e.note)));
    relations_.set_child(*Gtk::make_managed<TextPager>(declared));
    relations_.set_visible(!declared.empty());
    append(relations_);
    summary_.set_wrap(true);
    summary_.set_xalign(0);
    append(summary_);
    order_.signal_changed().connect([this] {
      ordered = application::contextual_selection_order(snapshot_, parts_, order_.get_active_id());
      cursor_ = offset_ = 0;
      render();
    });
    rows_.signal_row_selected().connect([this](Gtk::ListBoxRow *row) {
      if (!rendering_ && row) {
        cursor_ = offset_ + row->get_index();
        sensitivity();
      }
    });
    before_.signal_clicked().connect([this] { move(-1); });
    after_.signal_clicked().connect([this] { move(1); });
    previous_.signal_clicked().connect([this] { cursor_ = offset_ - 50; offset_ -= 50; render(); });
    next_.signal_clicked().connect([this] { offset_ += 50; cursor_ = offset_; render(); });
    order_.set_active_id("local");
  }
  Gtk::CheckButton reorder{"Aplicar ordem local aos lugares dos selecionados"},
      succession{"Declarar sucessão entre vizinhos desta revisão"};
  std::vector<std::string> ordered;

private:
  void sensitivity() {
    before_.set_sensitive(cursor_ > 0);
    after_.set_sensitive(cursor_ + 1 < ordered.size());
    previous_.set_sensitive(offset_ > 0);
    next_.set_sensitive(offset_ + 50 < ordered.size());
    previous_.set_visible(ordered.size() > 50);
    next_.set_visible(ordered.size() > 50);
  }
  void move(int direction) {
    if ((direction < 0 && cursor_ == 0) || (direction > 0 && cursor_ + 1 >= ordered.size()))
      return;
    const auto next = static_cast<std::size_t>(static_cast<std::int64_t>(cursor_) + direction);
    std::swap(ordered[cursor_], ordered[next]);
    cursor_ = next;
    offset_ = cursor_ / 50 * 50;
    render();
  }
  void render() {
    rendering_ = true;
    while (auto *child = rows_.get_first_child())
      rows_.remove(*child);
    for (std::size_t i = offset_; i < std::min(offset_ + 50, ordered.size()); ++i) {
      auto *text = label(std::to_string(i + 1) + ". " + titles_.at(ordered[i]));
      text->set_margin(3);
      rows_.append(*text);
    }
    rows_.select_row(*rows_.get_row_at_index(static_cast<int>(cursor_ - offset_)));
    rendering_ = false;
    sensitivity();
    page_.set_text(std::to_string(offset_ + 1) + "–" +
                   std::to_string(std::min(offset_ + 50, ordered.size())) + " / " + std::to_string(ordered.size()));
    const std::set<std::string> chosen(parts_.begin(), parts_.end());
    std::size_t preserved{}, reverse{};
    std::set<std::pair<std::string, std::string>> edges;
    for (const auto &e : snapshot_.dependencies) {
      if (chosen.contains(e.source) && chosen.contains(e.target))
        ++preserved;
      if (e.kind == "succession")
        edges.emplace(e.source, e.target);
    }
    for (std::size_t i = 1; i < ordered.size(); ++i)
      reverse += edges.contains({ordered[i], ordered[i - 1]});
    summary_.set_text(std::to_string(preserved) + " ligações anteriores entre os selecionados serão preservadas. " +
                      (reverse ? std::to_string(reverse) + " sucessões apontam no sentido inverso da proposta. " : "") +
                      "Sucessão é opcional e não transmite contexto. Participações em opções continuam opções. "
                      "Nenhum texto, data, escolha ou outro uso será reordenado.");
  }
  application::ContextualSnapshot snapshot_;
  std::vector<std::string> parts_;
  std::map<std::string, std::string> titles_;
  std::size_t cursor_{}, offset_{};
  bool rendering_{};
  Gtk::ComboBoxText order_;
  Gtk::ScrolledWindow scroll_;
  Gtk::ListBox rows_;
  Gtk::Box controls_{Gtk::Orientation::HORIZONTAL, 5};
  Gtk::Button before_{"Subir na revisão"}, after_{"Descer na revisão"},
      previous_{"Página anterior"}, next_{"Próxima página"};
  Gtk::Label page_, summary_;
  Gtk::Expander relations_{"Consultar ligações anteriores entre os selecionados"};
};
} // namespace
void ContextualPlanningPage::review_sequence() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  const auto parts = canvas_.selected_parts();
  if (!owner || parts.size() < 2)
    return;
  const auto expected = observation(snapshot_);
  auto *d = new OverlayDialog("Revisar sequência selecionada", *owner, true);
  d->set_secondary_text("Revise a ordem antes de confirmar. Os trechos não selecionados conservam seus lugares. "
                        "A posição no desenho nunca muda a ordem automaticamente; ligações existentes não serão removidas.");
  auto *review = Gtk::make_managed<SequenceReview>(snapshot_, parts);
  d->get_content_area()->append(*review);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Confirmar sequência", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj(
      [this, d, review, expected, error](int r) {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        try {
          service_.sequence_selection(expected, review->ordered,
                                      review->reorder.get_active(), review->succession.get_active());
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work_id_);
        status_.emit("Revisão aplicada somente a esta composição; reversão no histórico do Projeto.");
      }, *this));
  d->present();
}
void ContextualPlanningPage::arrange_selection() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  const auto parts = canvas_.selected_parts();
  if (!owner || parts.size() < 2)
    return;
  const auto baseline = std::make_shared<const application::ContextualSnapshot>(snapshot_);
  const auto expected = observation(snapshot_);
  auto *d = new OverlayDialog("Organizar trechos selecionados", *owner, true);
  d->set_secondary_text("Prévia na superfície, sem gravação até confirmar. Somente blocos selecionados: "
                        "não altera extensão, curva, faixa, ordem narrativa ou relações. Cancelar restaura o desenho.");
  auto *mode = Gtk::make_managed<Gtk::ComboBoxText>();
  for (const auto &[id, title] : std::initializer_list<std::pair<const char *, const char *>>{
           {"left", "Alinhar à esquerda"}, {"right", "Alinhar à direita"},
           {"top", "Alinhar pelo topo"}, {"bottom", "Alinhar pela base"},
           {"distribute_x", "Distribuir horizontalmente entre extremos"},
           {"distribute_y", "Distribuir verticalmente entre extremos"},
           {"pack_x", "Fila horizontal com intervalo de 40"},
           {"pack_y", "Coluna vertical com intervalo de 40"}})
    mode->append(id, title);
  mode->set_name("visual-arrangement");
  set_accessible_label(*mode, "Organização geométrica da seleção");
  d->get_content_area()->append(*mode);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  const auto proposal = std::make_shared<std::optional<std::vector<application::ContextualVisualItem>>>();
  mode->signal_changed().connect(sigc::track_obj([this, mode, error, baseline, parts, proposal] {
    try {
      *proposal = application::contextual_arrange_selection(*baseline, parts, mode->get_active_id());
      canvas_.preview_layout(**proposal);
      error->set_text("");
    } catch (const std::exception &e) {
      proposal->reset();
      canvas_.preview_layout(application::contextual_visual_layout(*baseline));
      error->set_text(e.what());
    }
  }, *this));
  mode->set_active_id("left");
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Salvar organização", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj([this, d, expected, proposal, error](int r) {
    if (r == Gtk::ResponseType::ACCEPT) {
      try {
        if (!*proposal)
          throw std::runtime_error("Escolha uma organização válida antes de salvar");
        commit_visual(expected, **proposal);
      } catch (const std::exception &e) {
        error->set_text(e.what());
        d->keep_open_on_response();
        return;
      }
    }
    refresh(work_id_);
  }, *this));
  d->present();
}
} // namespace inde::ui
