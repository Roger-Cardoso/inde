#include "inde/ui/text_coordinates.hpp"
#include "inde/ui/reading_block_gutter.hpp"
#include "inde/ui/accessibility.hpp"
#include "inde/ui/application_theme.hpp"
#include <algorithm>
#include <cmath>
namespace inde::ui {
namespace {
double coordinate_y(const Gtk::Widget &from, const Gtk::Widget &to, double y) {
  const graphene_point_t input{0, static_cast<float>(std::clamp(y, double(std::numeric_limits<int>::min()), double(std::numeric_limits<int>::max())))};
  graphene_point_t output{};
  if (gtk_widget_compute_point(const_cast<GtkWidget *>(from.gobj()),
      const_cast<GtkWidget *>(to.gobj()), &input, &output)) return output.y;
  return y;
}
}
ReadingBlockGutter::ReadingBlockGutter(Gtk::TextView &editor) : editor_(editor) {
  set_name("reading-block-gutter");
  set_size_request(44, -1); set_hexpand(false); set_vexpand(true);
  set_focusable(true); set_cursor("grab");
  set_accessible_label(*this, "Blocos na ordem de leitura");
  set_accessible_description(*this, "Arraste um círculo para mover o bloco. "
    "Setas escolhem bloco; Ctrl+seta acima ou abaixo move; Enter volta à escrita; "
    "Escape cancela o arrasto. Não muda cronologia ou planejamento.");
  set_tooltip_text("Arraste o círculo para reordenar a leitura. "
                   "Também disponível em Ações do Documento.");
  set_draw_func(sigc::mem_fun(*this, &ReadingBlockGutter::draw));
  signal_application_theme_changed().connect(sigc::track_obj([this] { queue_draw(); }, *this));
  auto drag = Gtk::GestureDrag::create();
  drag->set_button(1);
  drag->signal_drag_begin().connect([this](double x, double y) {
    cancel_drag();
    const auto i = hit(x, y);
    if (i == blocks_.size()) return;
    grab_focus(); focus_block(i, false);
    dragging_ = blocks_[i].id; start_y_ = pointer_y_ = y;
    destination_ = i; destination_after_ = false; distance_ = 0; set_cursor("grabbing");
    scroll_timer_ = Glib::signal_timeout().connect([this] {
      if (dragging_.empty()) return false;
      const auto a = editor_.get_vadjustment();
      const double step = pointer_y_ < 26 ? -18 : pointer_y_ > get_height() - 26 ? 18 : 0;
      if (a && step) a->set_value(std::clamp(a->get_value() + step, a->get_lower(),
          std::max(a->get_lower(), a->get_upper() - a->get_page_size())));
      std::tie(destination_, destination_after_) = drop_at(pointer_y_); queue_draw(); return true;
    }, 60);
  });
  drag->signal_drag_update().connect([this](double x, double y) {
    if (dragging_.empty()) return;
    distance_ = std::max(distance_, std::hypot(x, y));
    pointer_y_ = start_y_ + y; std::tie(destination_, destination_after_) = drop_at(pointer_y_); queue_draw();
  });
  drag->signal_drag_end().connect([this](double, double y) {
    const auto id = dragging_;
    const bool moved = !id.empty() && distance_ >= 6;
    const auto [dest, after] = drop_at(start_y_ + y);
    const auto reference = dest < blocks_.size() ? blocks_[dest].id : std::string{};
    cancel_drag();
    if (moved && move && !reference.empty()) move(id, reference, after);
  });
  drag->signal_cancel().connect([this](Gdk::EventSequence *) { cancel_drag(); });
  add_controller(drag);
  auto keys = Gtk::EventControllerKey::create();
  keys->signal_key_pressed().connect(sigc::mem_fun(*this, &ReadingBlockGutter::key), false);
  add_controller(keys);
  property_has_focus().signal_changed().connect([this] { queue_draw(); });
}
ReadingBlockGutter::~ReadingBlockGutter() { scroll_timer_.disconnect(); }
void ReadingBlockGutter::cancel_drag() {
  scroll_timer_.disconnect(); dragging_.clear(); distance_ = 0;
  set_cursor("grab"); queue_draw();
}
void ReadingBlockGutter::set_blocks(std::vector<application::ReadingBlock> blocks) {
  cancel_drag(); blocks_ = std::move(blocks);
  if (std::none_of(blocks_.begin(), blocks_.end(), [&](const auto &b) { return b.id == focused_; }))
    focused_ = blocks_.empty() ? "" : blocks_.front().id;
  if (!blocks_.empty()) {
    auto it = std::find_if(blocks_.begin(), blocks_.end(), [&](const auto &b) { return b.id == focused_; });
    focus_block(static_cast<std::size_t>(it - blocks_.begin()), false);
  }
  set_visible(!blocks_.empty()); queue_draw();
}
double ReadingBlockGutter::line_y(std::size_t offset, int *height) const {
  Gdk::Rectangle rect;
  editor_.get_iter_location(editor_.get_buffer()->get_iter_at_offset(gtk_text_offset(offset)), rect);
  int x, y;
  editor_.buffer_to_window_coords(Gtk::TextWindowType::WIDGET, rect.get_x(), rect.get_y(), x, y);
  if (height) *height = rect.get_height();
  return coordinate_y(editor_, *this, y);
}
std::size_t ReadingBlockGutter::hit(double x, double y) const {
  if (!std::isfinite(x) || !std::isfinite(y)) return blocks_.size();
  if (std::abs(x - get_width() / 2.0) > 19 || blocks_.empty()) return blocks_.size();
  int bx, by, top;
  editor_.window_to_buffer_coords(Gtk::TextWindowType::WIDGET, 0, gtk_pixel(coordinate_y(*this, editor_, y)), bx, by);
  Gtk::TextBuffer::const_iterator iter;
  editor_.get_line_at_y(iter, by, top);
  auto it = std::upper_bound(blocks_.begin(), blocks_.end(), static_cast<std::size_t>(iter.get_offset()),
      [](auto p, const auto &b) { return p < b.start; });
  if (it != blocks_.begin()) --it;
  int h;
  const auto line = line_y(it->start, &h);
  const auto cy = line + h / 2.0;
  if (std::abs(y - cy) > std::min(19.0, std::max(8.0, h / 2.0))) return blocks_.size();
  return it - blocks_.begin();
}
std::pair<std::size_t, bool> ReadingBlockGutter::drop_at(double y) const {
  if (blocks_.empty() || !std::isfinite(y)) return {blocks_.size(), false};
  int bx, by, top;
  editor_.window_to_buffer_coords(Gtk::TextWindowType::WIDGET, 0, gtk_pixel(coordinate_y(*this, editor_, y)), bx, by);
  Gtk::TextBuffer::const_iterator iter;
  editor_.get_line_at_y(iter, by, top);
  auto it = std::upper_bound(blocks_.begin(), blocks_.end(), static_cast<std::size_t>(iter.get_offset()),
      [](auto p, const auto &b) { return p < b.start; });
  if (it != blocks_.begin()) --it;
  int h;
  const auto line = line_y(it->start, &h);
  const auto cy = line + h / 2.0;
  return {static_cast<std::size_t>(it - blocks_.begin()), y > cy};
}
void ReadingBlockGutter::focus_block(std::size_t i, bool reveal) {
  if (i >= blocks_.size()) return;
  const auto &b = blocks_[i]; focused_ = b.id;
  set_accessible_label(*this, "Bloco " + std::to_string(i + 1) + " de " + std::to_string(blocks_.size()) +
      (b.first != b.last ? ", resma multilinha indivisível" : "") + ". Ordem de leitura");
  if (reveal) {
    const auto buffer = editor_.get_buffer();
    buffer->select_range(buffer->get_iter_at_offset(gtk_text_offset(b.start)), buffer->get_iter_at_offset(gtk_text_offset(b.end)));
    auto at = buffer->get_iter_at_offset(gtk_text_offset(b.start)); editor_.scroll_to(at, .15);
  }
  queue_draw();
}
bool ReadingBlockGutter::key(guint keyval, guint, Gdk::ModifierType modifiers) {
  if (keyval == GDK_KEY_Escape) { cancel_drag(); return true; }
  if (keyval == GDK_KEY_Return || keyval == GDK_KEY_KP_Enter) { editor_.grab_focus(); return true; }
  if (blocks_.empty()) return false;
  auto it = std::find_if(blocks_.begin(), blocks_.end(), [&](const auto &b) { return b.id == focused_; });
  auto i = it == blocks_.end() ? 0 : static_cast<std::size_t>(it - blocks_.begin());
  if (keyval == GDK_KEY_Home) { focus_block(0, true); return true; }
  if (keyval == GDK_KEY_End) { focus_block(blocks_.size() - 1, true); return true; }
  if (keyval != GDK_KEY_Up && keyval != GDK_KEY_Down) return false;
  const bool up = keyval == GDK_KEY_Up;
  if (static_cast<unsigned>(modifiers & Gdk::ModifierType::CONTROL_MASK)) {
    if ((up && !i) || (!up && i + 1 == blocks_.size())) return true;
    const auto id = blocks_[i].id;
    const auto target = blocks_[up ? i - 1 : i + 1].id;
    cancel_drag(); if (move) move(id, target, !up);
  } else focus_block(up ? (i ? i - 1 : 0) : std::min(i + 1, blocks_.size() - 1), true);
  return true;
}
void ReadingBlockGutter::draw(const Cairo::RefPtr<Cairo::Context> &cr, int width, int height) {
  if (blocks_.empty()) return;
  const auto color = get_color();
  cr->set_source_rgba(color.get_red(), color.get_green(), color.get_blue(), .6);
  Gdk::Rectangle visible; editor_.get_visible_rect(visible);
  Gtk::TextBuffer::const_iterator first; int top;
  editor_.get_line_at_y(first, visible.get_y(), top);
  auto it = std::lower_bound(blocks_.begin(), blocks_.end(), static_cast<std::size_t>(first.get_offset()),
      [](const auto &b, auto p) { return b.end < p; });
  for (; it != blocks_.end(); ++it) {
    int h; const auto line = line_y(it->start, &h);
    const auto cy = line + h / 2.0;
    if (cy > height + 20) break;
    if (cy < -20) continue;
    const bool chosen = it->id == dragging_ || (has_focus() && it->id == focused_);
    cr->set_line_width(chosen ? 2.5 : 1.5);
    cr->arc(width / 2.0, cy, chosen ? 8 : 6, 0, 6.283185307179586);
    if (chosen) { cr->fill_preserve(); } cr->stroke();
    // A second dot distinguishes a grouped, multiline resma without labels
    // occupying or replacing any editable prose.
    if (it->first != it->last) { cr->arc(width / 2.0, cy + 12, 2, 0, 6.283185307179586); cr->fill(); }
  }
  if (!dragging_.empty()) {
    int h{};
    double y = line_y(destination_after_ ? blocks_[destination_].end : blocks_[destination_].start, &h);
    y += destination_after_ ? h + 2 : -2;
    y = std::clamp(y, 2.0, std::max(2.0, height - 2.0));
    cr->set_line_width(3); cr->move_to(3, y); cr->line_to(width - 3, y); cr->stroke();
  }
}
} // namespace inde::ui
