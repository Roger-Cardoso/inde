#include "contextual_canvas.hpp"
#include "inde/ui/accessibility.hpp"
#include "inde/ui/application_theme.hpp"
#include <algorithm>
#include <cmath>
#include <gdk/gdkkeysyms.h>

namespace inde::ui {
namespace {
// Model coordinates are validated to +/-100000 (dimensions <=20000).
// Their conversion to the drawing API's double is exact within those bounds.
double drawing(std::int64_t value) { return static_cast<double>(value); }
bool shifted(Gdk::ModifierType m) {
  return (static_cast<unsigned>(m) & GDK_SHIFT_MASK) != 0;
}
double curve_height(const application::ContextualVisualItem &v) {
  return drawing(std::max<std::int64_t>(1, v.height - (v.expanded ? 120 : 58)));
}
void color(const Cairo::RefPtr<Cairo::Context> &cr, const std::string &hex,
           double a = 1) {
  Gdk::RGBA c(hex);
  cr->set_source_rgba(c.get_red(), c.get_green(), c.get_blue(), a);
}
} // namespace
ContextualCanvas::ContextualCanvas() {
  set_focusable(true);
  set_hexpand(true);
  set_vexpand(true);
  set_content_width(320);
  set_content_height(220);
  set_name("contextual-canvas");
  set_accessible_label(*this, "Superfície de composição visual");
  set_accessible_description(
      *this, "Arraste trechos, Shift para seleção múltipla; canto inferior "
             "redimensiona. Roda aproxima; botão central desloca. Tab percorre "
             "trechos; Ctrl+Shift+seta horizontal amplia a seleção na ordem local; "
             "setas movem; Enter abre interior; F2 propriedades; Home "
             "panorama; Escape cancela gesto.");
  set_tooltip_text("Duplo clique no vazio: anotar aqui. Shift: selecionar "
                   "vários. Arraste o canto para mudar extensão. Botão "
                   "central: câmera. Menu ou Shift+F10: ações.");
  set_draw_func(sigc::mem_fun(*this, &ContextualCanvas::draw));
  signal_application_theme_changed().connect(
      sigc::track_obj([this] { queue_draw(); }, *this));
  auto pointer = Gtk::EventControllerMotion::create();
  pointer->signal_motion().connect([this](double x, double y) {
    pointer_x_ = wx(x);
    pointer_y_ = wy(y);
    const auto id = hit(pointer_x_, pointer_y_);
    if (id != hovered_) {
      hovered_ = id;
      const auto v = std::find_if(items_.begin(), items_.end(),
                                  [&](const auto &v) { return v.id == id; });
      if (v != items_.end()) {
        const auto p = parts_.find(v->participation_id);
        set_tooltip_text(p == parts_.end()
                             ? v->label
                             : p->second.title +
                                   (p->second.description.empty()
                                        ? ""
                                        : "\n" + p->second.description));
      } else
        set_tooltip_text("Duplo clique: anotar aqui. Shift: seleção múltipla. "
                         "Botão central: câmera. Menu: ações.");
    }
  });
  add_controller(pointer);
  const auto cancel_drag = [this](Gdk::EventSequence *) {
    if (dragging_) {
      items_ = before_;
      if (pan_) {
        camera_x_ = old_camera_x_;
        camera_y_ = old_camera_y_;
      }
      dragging_ = rubber_ = false;
      snap_x_.reset();
      snap_y_.reset();
      notify();
    }
  };
  auto primary = Gtk::GestureDrag::create();
  primary->set_button(1);
  primary->signal_drag_begin().connect(
      [this, primary = primary.get()](double x, double y) {
        begin(x, y, false, shifted(primary->get_current_event_state()));
      });
  primary->signal_drag_update().connect(
      sigc::mem_fun(*this, &ContextualCanvas::update));
  primary->signal_drag_end().connect([this](double, double) { finish(); });
  primary->signal_cancel().connect(cancel_drag);
  add_controller(primary);
  auto middle = Gtk::GestureDrag::create();
  middle->set_button(2);
  middle->signal_drag_begin().connect(
      [this](double x, double y) { begin(x, y, true, false); });
  middle->signal_drag_update().connect(
      sigc::mem_fun(*this, &ContextualCanvas::update));
  middle->signal_drag_end().connect([this](double, double) { finish(); });
  middle->signal_cancel().connect(cancel_drag);
  add_controller(middle);
  auto click = Gtk::GestureClick::create();
  click->set_button(1);
  click->signal_pressed().connect(
      [this, click = click.get()](int n, double x, double y) {
        if (n == 2 && click->get_current_button() == 1) {
          if (hit(wx(x), wy(y)).empty()) {
            pointer_x_ = wx(x);
            pointer_y_ = wy(y);
            capture_requested.emit();
          } else if (!selected_parts().empty())
            open_requested.emit();
        }
      });
  add_controller(click);
  auto wheel = Gtk::EventControllerScroll::create();
  wheel->set_flags(Gtk::EventControllerScroll::Flags::BOTH_AXES);
  wheel->signal_scroll().connect(
      [this, wheel = wheel.get()](double dx, double dy) {
        if (dragging_)
          return true;
        if (shifted(wheel->get_current_event_state())) {
          camera_x_ = std::clamp(camera_x_ + dx * 50 / zoom_, -200000.0, 200000.0);
          camera_y_ = std::clamp(camera_y_ + dy * 50 / zoom_, -200000.0, 200000.0);
          queue_draw();
        } else
          zoom(dy < 0 ? 1.15 : 1 / 1.15);
        return true;
      },
      false);
  add_controller(wheel);
  auto keys = Gtk::EventControllerKey::create();
  keys->signal_key_pressed().connect(
      [this](guint k, guint, Gdk::ModifierType m) { return key(k, m); }, false);
  add_controller(keys);
}
void ContextualCanvas::set_data(const application::ContextualSnapshot &s) {
  if (plan_ != s.plan_id) {
    selection_.clear();
    previews_.clear();
    camera_x_ = camera_y_ = 0;
    zoom_ = 1;
  }
  plan_ = s.plan_id;
  items_ = application::contextual_visual_layout(s);
  previews_.clear();
  parts_.clear();
  tab_order_.clear();
  edges_ = s.dependencies;
  std::map<std::string, std::string> visual_ids;
  for (const auto &v : items_)
    if (v.kind == "block")
      visual_ids.emplace(v.participation_id, v.id);
  for (const auto &p : s.participations) {
    parts_.emplace(p.id, p);
    tab_order_.push_back(visual_ids.at(p.id));
  }
  std::erase_if(selection_, [this](const auto &id) {
    return std::none_of(items_.begin(), items_.end(),
                        [&](const auto &v) { return v.id == id; });
  });
  dragging_ = rubber_ = false;
  queue_draw();
}
void ContextualCanvas::select_part(const std::string &id) {
  if (selection_.size() == 1 && selected_parts() == std::vector<std::string>{id})
    return;
  selection_.clear();
  for (const auto &v : items_)
    if (v.participation_id == id) {
      selection_.insert(v.id);
      break;
    }
  queue_draw();
}
std::vector<std::string> ContextualCanvas::selected_parts() const {
  std::vector<std::string> out;
  for (const auto &v : items_)
    if (selection_.contains(v.id) && !v.participation_id.empty())
      out.push_back(v.participation_id);
  return out;
}
bool ContextualCanvas::selected_lane() const {
  return selection_.size() == 1 &&
         std::any_of(items_.begin(), items_.end(), [&](const auto &v) {
           return v.kind == "lane" && selection_.contains(v.id);
         });
}
void ContextualCanvas::select_lane_contents() {
  if (!selected_lane())
    return;
  const auto lane = *std::find_if(items_.begin(), items_.end(), [&](const auto &v) {
    return selection_.contains(v.id);
  });
  for (const auto &v : items_)
    if (v.kind == "block" && v.x >= lane.x && v.y >= lane.y &&
        v.x + v.width <= lane.x + lane.width &&
        v.y + v.height <= lane.y + lane.height)
      selection_.insert(v.id);
  notify();
}
void ContextualCanvas::set_preview(const std::string &part,
                                   const application::ContextualSnapshot &s) {
  auto &out = previews_[part];
  out.clear();
  for (std::size_t i = 0; i < std::min<std::size_t>(s.participations.size(), 6);
       ++i) {
    if (i == 5 && s.participations.size() > 6)
      out.push_back("+ " + std::to_string(s.participations.size() - 5) +
                    " trechos · abrir interior");
    else {
      const auto &p = s.participations[i];
      const bool option = std::any_of(
          s.memberships.begin(), s.memberships.end(),
          [&](const auto &m) { return m.participation_id == p.id; });
      out.push_back((option ? std::string("Opção · ") : std::string{}) +
                    (p.title.empty() ? p.description : p.title));
    }
  }
  queue_draw();
}
void ContextualCanvas::camera(const std::array<double, 3> &c) {
  if (!std::isfinite(c[0]) || !std::isfinite(c[1]) || !std::isfinite(c[2]) ||
      std::abs(c[0]) > 200000 || std::abs(c[1]) > 200000 || c[2] < .05 ||
      c[2] > 4)
    throw std::runtime_error("Câmera visual inválida");
  camera_x_ = c[0];
  camera_y_ = c[1];
  zoom_ = c[2];
  queue_draw();
}
void ContextualCanvas::zoom(double factor) {
  const auto x = camera_x_ + get_width() / 2.0 / zoom_,
             y = camera_y_ + get_height() / 2.0 / zoom_;
  zoom_ = std::clamp(zoom_ * factor, .05, 4.0);
  camera_x_ = std::clamp(x - get_width() / 2.0 / zoom_, -200000.0, 200000.0);
  camera_y_ = std::clamp(y - get_height() / 2.0 / zoom_, -200000.0, 200000.0);
  queue_draw();
}
void ContextualCanvas::fit(bool selected_only) {
  double left = 100000, top = 100000, right = -100000, bottom = -100000;
  bool found = false;
  for (const auto &v : items_)
    if (!selected_only || selection_.contains(v.id)) {
      found = true;
      left = std::min(left, double(v.x));
      top = std::min(top, double(v.y));
      right = std::max(right, double(v.x + v.width));
      bottom = std::max(bottom, double(v.y + v.height));
    }
  if (!found) {
    camera_x_ = camera_y_ = 0;
    zoom_ = 1;
  } else {
    zoom_ = std::clamp(
        std::min(std::max(1, get_width() - 60) / (right - left + 1),
                 std::max(1, get_height() - 60) / (bottom - top + 1)),
        .05, 2.0);
    camera_x_ = left - 30 / zoom_;
    camera_y_ = top - 30 / zoom_;
  }
  queue_draw();
}
std::string ContextualCanvas::hit(double x, double y) const {
  for (const auto *kind : {"block", "marker", "lane"})
    for (auto i = items_.rbegin(); i != items_.rend(); ++i)
      if (i->kind == kind && x >= drawing(i->x) && x <= drawing(i->x) + drawing(i->width) && y >= drawing(i->y) &&
          y <= drawing(i->y) + drawing(i->height))
        return i->id;
  return {};
}
void ContextualCanvas::notify() {
  queue_draw();
  selection_changed.emit();
}
void ContextualCanvas::choose(double x, double y, bool additive) {
  pointer_x_ = wx(x);
  pointer_y_ = wy(y);
  const auto id = hit(wx(x), wy(y));
  if (!additive && !selection_.contains(id))
    selection_.clear();
  if (!id.empty()) {
    if (additive && selection_.contains(id))
      selection_.erase(id);
    else
      selection_.insert(id);
  } else if (!additive)
    selection_.clear();
  grab_focus();
  notify();
}
void ContextualCanvas::begin(double x, double y, bool pan, bool additive) {
  start_x_ = wx(x);
  start_y_ = wy(y);
  dx_ = dy_ = 0;
  pan_ = pan;
  changed_ = resize_ = rubber_ = false;
  handle_ = -1;
  snap_x_.reset();
  snap_y_.reset();
  old_camera_x_ = camera_x_;
  old_camera_y_ = camera_y_;
  before_ = items_;
  drag_id_ = hit(start_x_, start_y_);
  if (!pan) {
    choose(x, y, additive);
    rubber_ = drag_id_.empty();
    for (const auto &v : items_)
      if (v.id == drag_id_) {
        const auto corner =
            std::min({16 / zoom_, drawing(v.width) / 4.0, drawing(v.height) / 4.0});
        resize_ = start_x_ > drawing(v.x) + drawing(v.width) - corner &&
                  start_y_ > drawing(v.y) + drawing(v.height) - corner;
        if (!resize_ && v.kind == "block" &&
            (v.shape == "ecg" || v.shape == "wavy"))
          for (int n = 0; n < 5; ++n) {
            const auto px = drawing(v.x) + 16 + (drawing(v.width) - 32) * n / 4.0,
                       py = drawing(v.y) + 44 + curve_height(v) * drawing(v.curve[n]) / 1000.0;
            if (std::hypot(px - start_x_, py - start_y_) <
                std::min(10 / zoom_, drawing(v.width) / 12.0)) {
              handle_ = n;
              break;
            }
          }
      }
  }
  dragging_ = true;
}
void ContextualCanvas::update(double dx, double dy) {
  if (!dragging_)
    return;
  dx_ = dx / zoom_;
  dy_ = dy / zoom_;
  changed_ = std::abs(dx) + std::abs(dy) > 3;
  if (pan_) {
    camera_x_ = std::clamp(old_camera_x_ - dx_, -200000.0, 200000.0);
    camera_y_ = std::clamp(old_camera_y_ - dy_, -200000.0, 200000.0);
  } else if (rubber_) {
    selection_.clear();
    const auto l = std::min(start_x_, start_x_ + dx_),
               r = std::max(start_x_, start_x_ + dx_),
               t = std::min(start_y_, start_y_ + dy_),
               b = std::max(start_y_, start_y_ + dy_);
    for (const auto &v : items_)
      if (v.kind == "block" && drawing(v.x) >= l && drawing(v.y) >= t && drawing(v.x) + drawing(v.width) <= r &&
          drawing(v.y) + drawing(v.height) <= b)
        selection_.insert(v.id);
  } else {
    items_ = before_;
    // A group moves rigidly; clamp the common delta instead of distorting it.
    double lowx = -200000, highx = 200000, lowy = -200000, highy = 200000;
    for (const auto &v : before_)
      if (selection_.contains(v.id)) {
        lowx = std::max(lowx, -100000.0 - drawing(v.x));
        highx = std::min(highx, 100000.0 - drawing(v.x));
        lowy = std::max(lowy, -100000.0 - drawing(v.y));
        highy = std::min(highy, 100000.0 - drawing(v.y));
      }
    auto move_x = dx_, move_y = dy_;
    snap_x_.reset();
    snap_y_.reset();
    if (!resize_ && handle_ < 0 && !selection_.empty()) {
      double left = 100000, top = 100000, right = -100000, bottom = -100000;
      for (const auto &v : before_)
        if (selection_.contains(v.id)) {
          left = std::min(left, double(drawing(v.x)));
          top = std::min(top, double(drawing(v.y)));
          right = std::max(right, double(drawing(v.x) + drawing(v.width)));
          bottom = std::max(bottom, double(drawing(v.y) + drawing(v.height)));
        }
      double bestx = 8 / zoom_, besty = 8 / zoom_;
      for (const auto &v : before_)
        if (!selection_.contains(v.id)) {
          for (const auto x :
               {double(drawing(v.x)), drawing(v.x) + drawing(v.width) / 2.0, double(drawing(v.x) + drawing(v.width))})
            for (const auto a : {left, (left + right) / 2, right})
              if (std::abs(x - (a + dx_)) < bestx) {
                bestx = std::abs(x - (a + dx_));
                move_x = x - a;
                snap_x_ = x;
              }
          for (const auto y :
               {double(drawing(v.y)), drawing(v.y) + drawing(v.height) / 2.0, double(drawing(v.y) + drawing(v.height))})
            for (const auto a : {top, (top + bottom) / 2, bottom})
              if (std::abs(y - (a + dy_)) < besty) {
                besty = std::abs(y - (a + dy_));
                move_y = y - a;
                snap_y_ = y;
              }
        }
    }
    for (auto &v : items_)
      if (selection_.contains(v.id)) {
        if (handle_ >= 0 && v.id == drag_id_)
          v.curve[handle_] = std::clamp<std::int64_t>(
              std::llround((start_y_ + dy_ - drawing(v.y) - 44) / curve_height(v) *
                           1000),
              0, 1000);
        else if (resize_ && v.id == drag_id_) {
          v.width =
              std::clamp<std::int64_t>(v.width + std::llround(dx_), 80, 20000);
          v.height =
              std::clamp<std::int64_t>(v.height + std::llround(dy_), 64, 4000);
        } else if (!resize_ && handle_ < 0) {
          v.x += std::llround(std::clamp(move_x, lowx, highx));
          v.y += std::llround(std::clamp(move_y, lowy, highy));
        }
      }
  }
  queue_draw();
}
void ContextualCanvas::finish() {
  if (!dragging_)
    return;
  dragging_ = false;
  const bool save = changed_ && !pan_ && !rubber_ && items_ != before_;
  rubber_ = false;
  snap_x_.reset();
  snap_y_.reset();
  if (save)
    committed.emit(items_);
  else
    notify();
  queue_draw();
}
bool ContextualCanvas::key(guint k, Gdk::ModifierType mods) {
  const auto mask = static_cast<unsigned>(mods) &
                    (GDK_CONTROL_MASK | GDK_SHIFT_MASK | GDK_ALT_MASK |
                     GDK_SUPER_MASK | GDK_META_MASK);
  if (k == GDK_KEY_Escape) {
    if (dragging_) {
      items_ = before_;
      if (pan_) {
        camera_x_ = old_camera_x_;
        camera_y_ = old_camera_y_;
      }
    }
    snap_x_.reset();
    snap_y_.reset();
    dragging_ = rubber_ = false;
    selection_.clear();
    notify();
    return true;
  }
  if (mask == GDK_CONTROL_MASK && (k == GDK_KEY_a || k == GDK_KEY_A)) {
    for (const auto &v : items_)
      if (v.kind == "block")
        selection_.insert(v.id);
    notify();
    return true;
  }
  if (mask == GDK_CONTROL_MASK && (k == GDK_KEY_g || k == GDK_KEY_G)) {
    group_requested.emit();
    return true;
  }
  if (mask == (GDK_CONTROL_MASK | GDK_SHIFT_MASK) &&
      (k == GDK_KEY_Left || k == GDK_KEY_Right)) {
    // Start with Tab, then extend a local range without requiring a pointer.
    // Stop at boundaries; never wrap and accidentally select the entire plan.
    if (tab_order_.empty())
      return true;
    int first = static_cast<int>(tab_order_.size()), last = -1;
    for (std::size_t i = 0; i < tab_order_.size(); ++i)
      if (selection_.contains(tab_order_[i])) {
        first = std::min(first, static_cast<int>(i));
        last = static_cast<int>(i);
      }
    const int next = k == GDK_KEY_Right ? last + 1
                         : last < 0 ? static_cast<int>(tab_order_.size()) - 1
                                    : first - 1;
    if (next >= 0 && next < static_cast<int>(tab_order_.size())) {
      selection_.insert(tab_order_[next]);
      fit(true);
      notify();
    }
    return true;
  }
  if (mask != 0 && mask != GDK_SHIFT_MASK)
    return false;
  if (k == GDK_KEY_Home) {
    fit();
    return true;
  }
  if (k == GDK_KEY_plus || k == GDK_KEY_equal) {
    zoom(1.2);
    return true;
  }
  if (k == GDK_KEY_minus) {
    zoom(1 / 1.2);
    return true;
  }
  if (k == GDK_KEY_Return || k == GDK_KEY_KP_Enter) {
    if (!selected_parts().empty())
      open_requested.emit();
    else
      capture_requested.emit();
    return true;
  }
  if (k == GDK_KEY_F2) {
    properties_requested.emit();
    return true;
  }
  if (k == GDK_KEY_Tab || k == GDK_KEY_ISO_Left_Tab) {
    const auto &ids = tab_order_;
    if (ids.empty())
      return false;
    auto at = std::find_if(ids.begin(), ids.end(), [this](auto &id) {
      return selection_.contains(id);
    });
    const int step = shifted(mods) ? -1 : 1;
    const int index = at == ids.end() ? (step < 0 ? 0 : -1)
                                      : static_cast<int>(at - ids.begin());
    const int next = (index + step + int(ids.size())) % int(ids.size());
    selection_ = {ids[next]};
    fit(true);
    notify();
    return true;
  }
  int dx = 0, dy = 0;
  const int step = shifted(mods) ? 50 : 10;
  if (k == GDK_KEY_Left)
    dx = -step;
  else if (k == GDK_KEY_Right)
    dx = step;
  else if (k == GDK_KEY_Up)
    dy = -step;
  else if (k == GDK_KEY_Down)
    dy = step;
  else
    return false;
  if (selection_.empty()) {
    camera_x_ = std::clamp(camera_x_ + dx / zoom_, -200000.0, 200000.0);
    camera_y_ = std::clamp(camera_y_ + dy / zoom_, -200000.0, 200000.0);
    queue_draw();
    return true;
  }
  auto before = items_;
  std::int64_t tx = dx, ty = dy;
  for (const auto &v : items_)
    if (selection_.contains(v.id)) {
      tx = std::clamp<std::int64_t>(tx, -100000 - v.x, 100000 - v.x);
      ty = std::clamp<std::int64_t>(ty, -100000 - v.y, 100000 - v.y);
    }
  for (auto &v : items_)
    if (selection_.contains(v.id)) {
      v.x += tx;
      v.y += ty;
    }
  if (items_ != before)
    committed.emit(items_);
  return true;
}
void ContextualCanvas::draw(const Cairo::RefPtr<Cairo::Context> &cr, int width,
                            int height) {
  const auto fg = get_color();
  const bool dark = (fg.get_red() + fg.get_green() + fg.get_blue()) > 1.5;
  cr->set_source_rgb(dark ? .055 : .97, dark ? .065 : .98, dark ? .085 : .99);
  cr->paint();
  cr->save();
  cr->scale(zoom_, zoom_);
  cr->translate(-camera_x_, -camera_y_);
  auto text = [&](const std::string &value, double x, double y, double w,
                  int size, bool bright = true) {
    if (w <= 0)
      return;
    cr->save();
    cr->rectangle(x, y, w, 32 / std::min(zoom_, 1.0));
    cr->clip();
    auto layout = create_pango_layout(value);
    Pango::FontDescription font;
    font.set_family("Sans");
    font.set_size(static_cast<int>(size / std::min(zoom_, 1.0) * Pango::SCALE));
    layout->set_font_description(font);
    layout->set_width(static_cast<int>(std::min(w, 50000.0) * Pango::SCALE));
    layout->set_ellipsize(Pango::EllipsizeMode::END);
    cr->set_source_rgba(fg.get_red(), fg.get_green(), fg.get_blue(),
                        bright ? 1 : .7);
    cr->move_to(x, y);
    layout->show_in_cairo_context(cr);
    cr->restore();
  };
  auto visible = [&](const auto &v) {
    return drawing(v.x) + drawing(v.width) >= camera_x_ && drawing(v.y) + drawing(v.height) >= camera_y_ &&
           drawing(v.x) <= camera_x_ + width / zoom_ &&
           drawing(v.y) <= camera_y_ + height / zoom_;
  };
  for (const auto &v : items_)
    if (v.kind == "lane" && visible(v)) {
      color(cr, v.color, .09);
      cr->rectangle(drawing(v.x), drawing(v.y), drawing(v.width), drawing(v.height));
      cr->fill();
      color(cr, v.color, .65);
      cr->set_line_width(2 / zoom_);
      cr->rectangle(drawing(v.x), drawing(v.y), drawing(v.width), drawing(v.height));
      cr->stroke();
      text(v.label, drawing(v.x) + 10, drawing(v.y) + 5, drawing(v.width) - 24, 12);
    }
  std::map<std::string, const application::ContextualVisualItem *> geometry;
  for (const auto &v : items_)
    if (v.kind == "block")
      geometry[v.participation_id] = &v;
  for (const auto &e : edges_) {
    const auto a = geometry.find(e.source), b = geometry.find(e.target);
    if (a == geometry.end() || b == geometry.end())
      continue;
    const auto &u = *a->second, &v = *b->second;
    color(cr, "#7b8794", .75);
    if (!included_.contains(e.source) || !included_.contains(e.target))
      cr->set_dash(std::vector<double>{5 / zoom_, 4 / zoom_}, 0);
    cr->set_line_width(1.5 / zoom_);
    const double x = drawing(u.x) + drawing(u.width), y = drawing(u.y) + drawing(u.height) / 2.0, tx = drawing(v.x),
                 ty = drawing(v.y) + drawing(v.height) / 2.0;
    cr->move_to(x, y);
    cr->curve_to(x + 40, y, tx - 40, ty, tx, ty);
    cr->stroke();
    cr->move_to(tx - 8, ty - 5);
    cr->line_to(tx, ty);
    cr->line_to(tx - 8, ty + 5);
    cr->stroke();
    cr->unset_dash();
  }
  for (const auto &v : items_)
    if (visible(v)) {
      const bool chosen = selection_.contains(v.id);
      if (v.kind == "marker") {
        color(cr, v.color);
        cr->set_line_width((chosen ? 3 : 1.5) / zoom_);
        cr->set_dash(std::vector<double>{6 / zoom_, 4 / zoom_}, 0);
        cr->move_to(drawing(v.x), drawing(v.y));
        cr->line_to(drawing(v.x), drawing(v.y) + drawing(v.height));
        cr->stroke();
        cr->unset_dash();
        text(v.label, drawing(v.x) + 8, drawing(v.y) + 4, drawing(v.width) - 12, 12);
      } else if (v.kind == "block") {
        const auto part = parts_.find(v.participation_id);
        if (part == parts_.end())
          continue;
        const auto &p = part->second;
        color(cr, v.color, dark ? .18 : .09);
        cr->rectangle(drawing(v.x), drawing(v.y), drawing(v.width), drawing(v.height));
        cr->fill();
        color(cr, v.color);
        cr->set_line_width((chosen ? 3 : 1.3) / zoom_);
        if (!included_.contains(p.id))
          cr->set_dash(std::vector<double>{5 / zoom_, 4 / zoom_}, 0);
        cr->rectangle(drawing(v.x), drawing(v.y), drawing(v.width), drawing(v.height));
        cr->stroke();
        cr->unset_dash();
        if (v.shape != "box") {
          const auto cy = [&](int n) {
            return drawing(v.y) + 44 +
                   curve_height(v) *
                       (v.shape == "straight" ? .5 : drawing(v.curve[n]) / 1000.0);
          };
          color(cr, v.color);
          cr->set_line_width(2 / zoom_);
          cr->move_to(drawing(v.x) + 16, cy(0));
          for (int n = 1; n < 5; ++n) {
            const double x = drawing(v.x) + 16 + (drawing(v.width) - 32) * n / 4.0,
                         oldx = drawing(v.x) + 16 + (drawing(v.width) - 32) * (n - 1) / 4.0;
            if (v.shape == "wavy")
              cr->curve_to((oldx + x) / 2, cy(n - 1), (oldx + x) / 2, cy(n), x,
                           cy(n));
            else
              cr->line_to(x, cy(n));
          }
          cr->stroke();
          if (zoom_ >= .35)
            for (int n = 0; n < 5; ++n) {
              cr->arc(drawing(v.x) + 16 + (drawing(v.width) - 32) * n / 4.0, cy(n),
                      (chosen ? 5 : 3) / zoom_, 0, 6.2832);
              cr->fill();
            }
        }
        const auto caption =
            (included_.contains(p.id) ? std::string{}
                                      : "Fora da escolha atual · ") +
            (p.title.empty() ? p.description : p.title);
        if (zoom_ < .7) {
          if (drawing(v.width) * zoom_ >= 70 && drawing(v.height) * zoom_ >= 30)
            text(caption, drawing(v.x) + 8 / zoom_, drawing(v.y) + 5 / zoom_,
                 drawing(v.width) - 16 / zoom_, 11);
          if (v.expanded) {
            const auto it = previews_.find(p.id);
            if (it != previews_.end() && drawing(v.width) * zoom_ > 220 &&
                drawing(v.height) * zoom_ > 90) {
              std::string summary = "Partes/opções: ";
              for (const auto &name : it->second) {
                if (summary != "Partes/opções: ")
                  summary += " · ";
                summary += name;
              }
              text(summary, drawing(v.x) + 8 / zoom_, drawing(v.y) + drawing(v.height) - 30 / zoom_,
                   drawing(v.width) - 16 / zoom_, 10, false);
            }
          }
        } else {
          text(caption, drawing(v.x) + 12, drawing(v.y) + 8, drawing(v.width) - 24, 12);
          if (v.shape == "box") {
            std::string detail = v.label;
            if (!p.category.empty())
              detail += (detail.empty() ? "" : " · ") + p.category;
            if (p.parallel)
              detail += (detail.empty() ? "" : " · ") + std::string("Paralelo");
            if (!p.scale.empty())
              detail += (detail.empty() ? "" : " · ") + p.scale;
            text(detail, drawing(v.x) + 12, drawing(v.y) + 36, drawing(v.width) - 24, 10, false);
          } else if (!v.label.empty())
            text(v.label, drawing(v.x) + 12, drawing(v.y) + 28, drawing(v.width) - 24, 10, false);
          if (!p.contents_plan_id.empty())
            text(v.expanded
                     ? "▾ Partes e opções · abrir interior para trabalhar"
                     : "▸ Tem interior · Enter para abrir",
                 drawing(v.x) + 12, drawing(v.y) + drawing(v.height) - 26, drawing(v.width) - 24, 10, false);
          if (v.expanded) {
            const auto preview = previews_.find(p.id);
            if (preview != previews_.end()) {
              const auto &labels = preview->second;
              const auto count = std::min<std::size_t>(labels.size(), 6);
              const auto cell =
                  drawing((v.width - 24) / static_cast<std::int64_t>(std::max<std::size_t>(1, count)));
              for (std::size_t n = 0; n < count; ++n) {
                const double x = drawing(v.x) + 12 + static_cast<double>(n) * cell,
                             y = drawing(v.y) +
                                 std::max(64.0, drawing(v.height) - 72);
                color(cr, v.color, .15);
                cr->rectangle(x, y, cell - 5, 34);
                cr->fill();
                text(labels[n], x + 4, y + 5, cell - 12, 9);
              }
            }
          }
        }
      }
      if (chosen) {
        color(cr, v.color);
        cr->rectangle(drawing(v.x) + drawing(v.width) - 10 / zoom_, drawing(v.y) + drawing(v.height) - 10 / zoom_,
                      8 / zoom_, 8 / zoom_);
        cr->fill();
      }
    }
  if (rubber_) {
    color(cr, "#4589b2", .12);
    cr->rectangle(std::min(start_x_, start_x_ + dx_),
                  std::min(start_y_, start_y_ + dy_), std::abs(dx_),
                  std::abs(dy_));
    cr->fill_preserve();
    color(cr, "#4589b2");
    cr->set_line_width(1 / zoom_);
    cr->stroke();
  }
  if (snap_x_ || snap_y_) {
    color(cr, "#4589b2", .8);
    cr->set_line_width(1 / zoom_);
    cr->set_dash(std::vector<double>{5 / zoom_, 4 / zoom_}, 0);
    if (snap_x_) {
      cr->move_to(*snap_x_, camera_y_);
      cr->line_to(*snap_x_, camera_y_ + height / zoom_);
    }
    if (snap_y_) {
      cr->move_to(camera_x_, *snap_y_);
      cr->line_to(camera_x_ + width / zoom_, *snap_y_);
    }
    cr->stroke();
    cr->unset_dash();
  }
  cr->restore();
  if (items_.empty()) {
    cr->set_source_rgba(fg.get_red(), fg.get_green(), fg.get_blue(), .8);
    cr->move_to(24, 42);
    auto l = create_pango_layout(
        plan_.empty()
            ? "Comece em Montagem → Nova composição contextual.\nDepois anote "
              "trechos e organize sua superfície."
            : "Anote um trecho acima ou dê duplo clique aqui.\nOrganize "
              "primeiro; classifique somente quando precisar.");
    l->show_in_cairo_context(cr);
  }
}
} // namespace inde::ui
