#pragma once
#include <concepts>
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>
namespace inde::ui {
// GTK uses signed int character positions; -1 denotes the end iterator.
// Reject an unrepresentable model position before calling GTK.
template<std::integral Integer> int gtk_text_offset(Integer value) {
  if constexpr (std::signed_integral<Integer>)
    if (value < -1) throw std::runtime_error("Posição textual inválida");
  if (std::cmp_greater(value, std::numeric_limits<int>::max()))
    throw std::runtime_error("O trecho excede o limite de posições do editor");
  return static_cast<int>(value);
}
inline int gtk_pixel(double value) {
  if (!std::isfinite(value)) throw std::runtime_error("Coordenada de ponteiro inválida");
  return static_cast<int>(std::clamp(value,
      static_cast<double>(std::numeric_limits<int>::min()),
      static_cast<double>(std::numeric_limits<int>::max())));
}
}
