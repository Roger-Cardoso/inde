#include "inde/application/document_visibility.hpp"
#include "inde/application/semantic_anchor_engine.hpp"
#include "inde/project/document_alternatives.hpp"
#include <algorithm>
#include <glib.h>
#include <map>
#include <set>
#include <stdexcept>
namespace inde::application {
namespace {
using Range = std::pair<std::size_t, std::size_t>;
using Ranges = std::vector<Range>;
Ranges unite(Ranges v) {
  std::sort(v.begin(), v.end());
  Ranges out;
  for (auto [a, b] : v)
    if (a < b) {
      if (!out.empty() && a <= out.back().second)
        out.back().second = std::max(b, out.back().second);
      else
        out.emplace_back(a, b);
    }
  return out;
}
Ranges subtract(const Ranges &yes, const Ranges &no) {
  Ranges out;
  std::size_t j = 0;
  for (auto [a, b] : yes) {
    while (j < no.size() && no[j].second <= a)
      ++j;
    auto p = a;
    for (auto i = j; i < no.size() && no[i].first < b; ++i) {
      if (p < no[i].first)
        out.emplace_back(p, std::min(b, no[i].first));
      p = std::max(p, no[i].second);
      if (p >= b)
        break;
    }
    if (p < b)
      out.emplace_back(p, b);
  }
  return out;
}
std::string hash(const std::string &s) {
  auto *p = g_compute_checksum_for_data(
      G_CHECKSUM_SHA256, reinterpret_cast<const guchar *>(s.data()), s.size());
  std::string out(p);
  g_free(p);
  return out;
}
std::vector<std::size_t> bytes(const std::string &s) {
  if (!g_utf8_validate(s.data(), s.size(), nullptr))
    throw std::runtime_error("Lente exige UTF-8 válido");
  std::vector<std::size_t> out;
  for (const auto *p = s.data(), *end = p + s.size(); p < end;
       p = g_utf8_next_char(p))
    out.push_back(p - s.data());
  out.push_back(s.size());
  return out;
}
void materialize(VisibilityProjection &p, const project::Document &d,
                 const Ranges &ranges, const std::set<std::size_t> &pinned_lfs = {}) {
  if (ranges.size() > 16384)
    throw std::runtime_error("Lente excede 16.384 intervalos; refine o perfil");
  const auto index = bytes(d.content);
  p.text.clear();
  p.spans.clear();
  std::size_t view = 0;
  auto shown = [&](std::size_t point) {
    auto i =
        std::upper_bound(ranges.begin(), ranges.end(), point,
                         [](auto x, const auto &r) { return x < r.first; });
    return i != ranges.begin() && point < (--i)->second;
  };
  auto span = [&](std::size_t a, std::size_t b, bool editable) {
    if (a < b) {
      if (p.spans.size() >= 16384)
        throw std::runtime_error(
            "Lente excede 16.384 intervalos; refine o perfil");
      p.spans.push_back({a, b, view, view + b - a, editable});
      view += b - a;
    }
  };
  for (auto [a, b] : ranges) {
    if (a > b || b >= index.size())
      throw std::runtime_error("Intervalo da lente fora da origem");
    if (index[b] - index[a] > 16 * 1024 * 1024 - p.text.size())
      throw std::runtime_error("Lente excede 16 MiB; refine o perfil");
    p.text.append(d.content, index[a], index[b] - index[a]);
    auto start = a;
    for (auto i = a; i < b; ++i)
      if (d.content[index[i]] == '\n' &&
          (pinned_lfs.contains(i) || (i > 0 && !shown(i - 1)) ||
           (i + 2 < index.size() && !shown(i + 1)))) {
        span(start, i, true);
        span(i, i + 1, false);
        start = i + 1;
      }
    span(start, b, true);
  }
  if (p.text.size() > 16 * 1024 * 1024)
    throw std::runtime_error("Lente excede 16 MiB; refine o perfil");
}
Ranges coverage(const VisibilityProjection &p) {
  Ranges out;
  for (const auto &r : p.spans)
    out.emplace_back(r.source_start, r.source_end);
  return out;
}
Ranges changed_ranges(const Ranges &ranges, std::size_t a, std::size_t b,
                      std::size_t n) {
  Ranges out;
  for (auto [x, y] : ranges) {
    if (x < a && std::min(y, a) > x)
      out.emplace_back(x, std::min(y, a));
    if (y > b && std::max(x, b) < y)
      out.emplace_back(std::max(x, b) - (b - a) + n, y - (b - a) + n);
  }
  if (n)
    out.emplace_back(a, a + n);
  return unite(std::move(out));
}
} // namespace
VisibilityProjection project_visibility(const project::Document &input,
                                        const std::string &id) {
  project::validate(input);
  auto profile = std::find_if(input.visibility_profiles.begin(),
                              input.visibility_profiles.end(),
                              [&](const auto &p) { return p.id == id; });
  if (profile == input.visibility_profiles.end())
    throw std::runtime_error("Perfil não pertence a este Documento");
  using Kind = project::VisibilityRuleKind;
  std::set<Kind> needed;
  if (!profile->include_all)
    for (const auto &r : profile->include)
      needed.insert(r.kind);
  for (const auto &r : profile->exclude)
    needed.insert(r.kind);
  const bool semantic_needed = needed.contains(Kind::Anchor) ||
                               needed.contains(Kind::SemanticType) ||
                               needed.contains(Kind::Annotation);
  std::optional<project::Document> inspected;
  if (semantic_needed) {
    inspected = input;
    SemanticAnchorEngine::inspect(*inspected);
  }
  const auto &d = inspected ? *inspected : input;
  VisibilityProjection out;
  out.document_id = d.id;
  out.profile_id = id;
  out.source_hash = hash(d.content);
  const auto length = project::utf8_character_count(d.content);
  std::map<std::pair<Kind, std::string>, Ranges> available;
  if (needed.contains(Kind::Paragraph))
    for (const auto &p : d.paragraphs.rows)
      available[{Kind::Paragraph, p.id}].emplace_back(
          p.start, p.end + (p.end < length ? 1 : 0));
  if (needed.contains(Kind::Resma))
    for (const auto &r : d.resmas)
      available[{Kind::Resma, r.id}].emplace_back(r.start, r.end);
  std::map<std::string, Range> anchors;
  std::map<std::string, project::AnchorResolution> states;
  if (semantic_needed)
    for (const auto &e : d.semantics.anchors)
      states[e.anchor_id] = e.state;
  if (semantic_needed)
    for (const auto &a : d.anchors) {
      if (auto it = states.find(a.id);
          it != states.end() &&
          it->second != project::AnchorResolution::Resolved)
        continue;
      anchors[a.id] = {a.start_offset, a.end_offset};
      if (needed.contains(Kind::Anchor))
        available[{Kind::Anchor, a.id}].emplace_back(a.start_offset,
                                                     a.end_offset);
    }
  std::set<std::string> unresolved_types;
  if (needed.contains(Kind::Annotation) || needed.contains(Kind::SemanticType))
    for (const auto &a : d.semantics.annotations) {
      if (a.status == "archived")
        continue;
      Range r;
      if (a.scope == project::AnnotationScope::Document)
        r = {0, length};
      else {
        auto evidence = states.find(a.anchor_id);
        if (evidence == states.end() ||
            evidence->second != project::AnchorResolution::Resolved) {
          unresolved_types.insert(a.type_key);
          continue;
        }
        auto it = anchors.find(a.anchor_id);
        if (it == anchors.end())
          continue;
        r = it->second;
      }
      if (needed.contains(Kind::Annotation))
        available[{Kind::Annotation, a.id}].push_back(r);
      if (needed.contains(Kind::SemanticType))
        available[{Kind::SemanticType, a.type_key}].push_back(r);
    }
  if (needed.contains(Kind::Style))
    for (const auto &f : d.formatting)
      available[{Kind::Style, project::to_string(f.style)}].emplace_back(
          f.start_offset, f.end_offset);
  bool unsafe_exclusion = false;
  auto collect = [&](const std::vector<project::VisibilityRule> &rules,
                     bool excluding) {
    Ranges result;
    for (const auto &r : rules) {
      auto i = available.find({r.kind, r.key});
      const bool unresolved_type =
          r.kind == Kind::SemanticType && unresolved_types.contains(r.key);
      const bool unknown_identity = i == available.end() &&
                                    r.kind != Kind::SemanticType &&
                                    r.kind != Kind::Style;
      if (unresolved_type || unknown_identity) {
        out.diagnostics.push_back("Critério sem trecho disponível/confiável: " +
                                  project::display_name(r.kind) + " · " +
                                  r.key);
        if (excluding)
          unsafe_exclusion = true;
      }
      if (i != available.end())
        result.insert(result.end(), i->second.begin(), i->second.end());
      if (result.size() > 100000)
        throw std::runtime_error(
            "Critérios da lente excedem 100 mil intervalos");
    }
    return unite(std::move(result));
  };
  auto yes = profile->include_all ? Ranges{{0, length}}
                                  : collect(profile->include, false);
  const auto no = collect(profile->exclude, true);
  if (unsafe_exclusion) {
    materialize(out, d, {});
    return out;
  }
  yes = subtract(yes, no);
  if (!profile->include_all && !yes.empty()) {
    // Keep original paragraph separators for displayed paragraphs, never make
    // new text for a lens. Exclusions retain precedence over these separators.
    const auto index = bytes(d.content);
    std::vector<std::size_t> lfs;
    for (std::size_t i = 0; i + 1 < index.size(); ++i)
      if (d.content[index[i]] == '\n')
        lfs.push_back(i);
    Ranges extra;
    for (auto [a, b] : yes)
      for (auto it = std::lower_bound(lfs.begin(), lfs.end(), a);
           it != lfs.end(); ++it) {
        extra.emplace_back(*it, *it + 1);
        if (*it >= b - 1)
          break;
      }
    yes.insert(yes.end(), extra.begin(), extra.end());
    yes = subtract(unite(std::move(yes)), no);
  }
  out.allow_empty_insert =
      length == 0 && profile->include_all && profile->exclude.empty();
  // Empty identified paragraphs are insertion slots, not missing content.
  // Their visibility follows the same explicit include/exclude rules. A zero
  // span adds no glyph or synthetic separator to the document rendering.
  auto point_matches = [&](const auto &rules, std::size_t point) {
    for (const auto &rule : rules) {
      const auto found = available.find({rule.kind, rule.key});
      if (found != available.end())
        for (const auto &[a,b] : found->second)
          if ((a<=point && point<b) || (a==point && b==point)) return true;
    }
    return false;
  };
  // Paragraphs are needed for explicit rules even when include_all avoids
  // materializing the availability index for ordinary nonempty paragraphs.
  std::vector<std::size_t> empty_shown;
  Ranges hidden_empty_lfs;
  std::set<std::size_t> pinned_lfs;
  for (const auto &p : d.paragraphs.rows) if (p.start==p.end) {
    const auto explicit_paragraph = [&](const auto &rules) {
      return std::any_of(rules.begin(),rules.end(),[&](const auto &r){return r.kind==Kind::Paragraph && r.key==p.id;});
    };
    const bool included = profile->include_all || explicit_paragraph(profile->include) || point_matches(profile->include,p.start);
    const bool excluded = explicit_paragraph(profile->exclude) || point_matches(profile->exclude,p.start);
    if (included && !excluded) {
      empty_shown.push_back(p.start);
    } else {
      if(p.start<length)hidden_empty_lfs.emplace_back(p.start,p.start+1);
      if(p.start)pinned_lfs.insert(p.start-1);
    }
  }
  yes=subtract(yes,unite(std::move(hidden_empty_lfs)));
  materialize(out,d,yes,pinned_lfs);
  std::vector<VisibilitySpan> slots;
  for(const auto point:empty_shown) {
      const auto first=std::lower_bound(out.spans.begin(),out.spans.end(),point,
        [](const auto &s,auto point){return s.source_end<point;});
      bool covered=false;
      for(auto it=first;it!=out.spans.end() && it->source_start<=point;++it)
        covered=covered || it->editable;
      if(covered)continue; // Do not nest a zero span inside an ordinary shown run.
      const auto offset = visibility_view_offset(out,point);
      slots.push_back({point,point,offset,offset,true});
  }
  out.spans.insert(out.spans.end(),slots.begin(),slots.end());
  std::stable_sort(out.spans.begin(),out.spans.end(),[](const auto &a,const auto &b){
    return a.source_start<b.source_start || (a.source_start==b.source_start && a.source_end<b.source_end);
  });
  if(out.spans.size()>16384)throw std::runtime_error("Visibilidade excede 16.384 intervalos/posições; refine o perfil");
  return out;
}
std::size_t visibility_view_offset(const VisibilityProjection &p,
                                   std::size_t source) {
  for (const auto &r : p.spans) {
    if (source < r.source_start)
      return r.view_start;
    if (source <= r.source_end)
      return r.view_start + source - r.source_start;
  }
  return project::utf8_character_count(p.text);
}
std::vector<TextRange> visibility_source_ranges(const VisibilityProjection &p,
    std::size_t a, std::size_t b, bool editable) {
  if (a > b) throw std::runtime_error("Seleção invertida");
  std::vector<TextRange> out;
  const auto first=std::lower_bound(p.spans.begin(),p.spans.end(),a,
      [](const auto &s,auto point){return s.source_end<=point;});
  for (auto it=first;it!=p.spans.end() && it->source_start<b;++it) {
    const auto &s=*it;
    const auto start = std::max(a,s.source_start), end = std::min(b,s.source_end);
    if (start < end && (!editable || s.editable)) {
      if (!out.empty() && out.back().end == start) out.back().end=end;
      else out.push_back({start,end});
    }
  }
  return out;
}
TextFragment copy_visibility_fragment(const project::Document &d,
    const VisibilityProjection &p, std::size_t a, std::size_t b, bool styles) {
  if (project_visibility(d,p.profile_id) != p) throw std::runtime_error("Visibilidade obsoleta");
  TextFragment out;
  std::size_t offset = 0;
  for (const auto &r : visibility_source_ranges(p,a,b)) {
    auto part = copy_fragment(d,r.start,r.end,styles);
    out.text += part.text;
    for (auto f : part.formatting) {
      f.start_offset += offset; f.end_offset += offset; out.formatting.push_back(std::move(f));
    }
    offset += project::utf8_character_count(part.text);
  }
  if (out.text.size() > clipboard_limit) throw std::runtime_error("Clipboard excede 16 MiB");
  return out;
}
DocumentEditState paste_visibility_fragment(const DocumentEditState &before,
    const VisibilityProjection &p,std::size_t a,std::size_t b,const TextFragment &fragment,bool styles) {
  // Validate the complete fragment before deleting any selected occurrence.
  (void)encode_fragment(fragment);
  auto after = edit_visibility(before,p,{{visibility_view_offset(p,a),visibility_view_offset(p,b),fragment.text}});
  if (styles && !fragment.text.empty()) {
    const auto length = project::utf8_character_count(fragment.text), start = after.selection.cursor-length;
    std::vector<project::DocumentFormatSpan> retained;
    for (auto f : after.document.formatting) {
      if (f.end_offset<=start || f.start_offset>=start+length) retained.push_back(f);
      else {
        if(f.start_offset<start){auto part=f;part.end_offset=start;retained.push_back(part);}
        if(f.end_offset>start+length){f.start_offset=start+length;retained.push_back(f);}
      }
    }
    for(auto f:fragment.formatting){f.start_offset+=start;f.end_offset+=start;retained.push_back(std::move(f));}
    after.document.formatting=std::move(retained);
    project::validate(after.document);
  }
  return after;
}
DocumentEditState edit_visibility(const DocumentEditState &before,
                                  const VisibilityProjection &projection,
                                  const std::vector<ProjectionEdit> &edits) {
  if (project_visibility(before.document, projection.profile_id) != projection)
    throw std::runtime_error(
        "A origem ou o perfil mudou; reabra a lente antes de editar");
  auto after = before;
  auto working = projection;
  const std::string empty;
  for (std::size_t i = 0; i < edits.size(); ++i) {
    auto edit = edits[i];
    if (edit.start < edit.end && edit.text.empty() && i + 1 < edits.size() &&
        edits[i + 1].start == edit.start && edits[i + 1].end == edit.start)
      edit.text = edits[++i].text;
    const auto length = project::utf8_character_count(working.text);
    if (edit.start > edit.end || edit.end > length)
      throw std::runtime_error("Edição fora da lente");
    if (edit.text.size() > 16 * 1024 * 1024 ||
        edit.text.find('\0') != std::string::npos ||
        !g_utf8_validate(edit.text.data(), edit.text.size(), nullptr))
      throw std::runtime_error("Edição da lente excedida ou inválida");
    std::vector<DocumentTextEdit> plan;
    std::size_t insertion{};
    bool found = false;
    for (const auto &r : working.spans) {
      if (edit.start < edit.end) {
        const auto a = std::max(edit.start, r.view_start),
                   b = std::min(edit.end, r.view_end);
        if (a < b && r.editable)
          plan.push_back({r.source_start + a - r.view_start,
                          r.source_start + b - r.view_start, empty});
      } else if (!found && r.editable && r.view_start <= edit.start &&
                 edit.start < r.view_end) {
        insertion = r.source_start + edit.start - r.view_start;
        found = true;
      }
    }
    if (edit.start == edit.end) {
      if (!found)
        for (auto it = working.spans.rbegin(); it != working.spans.rend(); ++it)
          if (it->editable && it->view_end <= edit.start) {
            insertion = it->source_end;
            found = true;
            break;
          }
      if (!found)
        for (const auto &r : working.spans)
          if (r.editable && r.view_start >= edit.start) {
            insertion = r.source_start;
            found = true;
            break;
          }
      if (!found && working.allow_empty_insert) {
        insertion = 0;
        found = true;
      }
      if (!found)
        throw std::runtime_error(
            "A lente não tem trecho editável; volte ao Documento integral");
      plan.push_back({insertion, insertion, edit.text});
    } else {
      if (plan.empty()) {
        if (!edit.text.empty())
          throw std::runtime_error("Este separador conserva um trecho omitido; "
                                   "insira antes ou depois dele");
        continue;
      }
      plan.front().text = edit.text;
      insertion = plan.front().start;
    }
    auto ranges = coverage(working);
    std::set<std::size_t> preserved_lfs;
    for(const auto &s:working.spans)if(!s.editable)
      for(auto point=s.source_start;point<s.source_end;++point) {
        auto mapped=point;
        for(auto it=plan.rbegin();it!=plan.rend();++it)if(it->end<=mapped)
          mapped=mapped-(it->end-it->start)+project::utf8_character_count(std::string(it->text));
        preserved_lfs.insert(mapped);
      }
    for (auto it = plan.rbegin(); it != plan.rend(); ++it)
      ranges =
          changed_ranges(ranges, it->start, it->end,
                         project::utf8_character_count(std::string(it->text)));
    std::string owner(project::outside_resma_owner);
    const bool visible_at_insertion = std::any_of(
        working.spans.begin(), working.spans.end(), [&](const auto &s) {
          return s.editable && s.source_start <= insertion &&
                 insertion < s.source_end;
        });
    for (const auto &r : after.document.resmas)
      if (visible_at_insertion && r.start <= insertion && insertion < r.end) {
        owner = r.id;
        break;
      }
    if (owner == project::outside_resma_owner)
      for (const auto &r : after.document.resmas)
        if (r.start < r.end && r.end == insertion &&
            std::any_of(working.spans.begin(), working.spans.end(),
                        [&](const auto &s) {
                          return s.editable && s.source_start < insertion &&
                                 s.source_end == insertion;
                        })) {
          owner = r.id;
          break;
        }
    after = replace_text_edits(after, plan, owner);
    const auto caret = insertion + project::utf8_character_count(edit.text);
    after.selection = {caret, caret};
    materialize(working, after.document, ranges, preserved_lfs);
    working.allow_empty_insert = false;
  }
  return after;
}
} // namespace inde::application
