#pragma once
#include "inde/application/contextual_planning.hpp"
#include "inde/persistence/sqlite_database.hpp"
#include "inde/project/project.hpp"
namespace inde::application::contextual_detail {
const project::Project &current(ProjectService &);
persistence::SqliteDatabase open(const project::Project &);
void guard(persistence::SqliteDatabase &, const project::Project &);
void text(const std::string &, std::size_t);
bool blank(const std::string &);
void evidence(std::string &, const std::string &);
std::string hash(const std::string &);
ContextualMoment read_moment(persistence::SqliteDatabase &, const project::Project &,
                             const std::string &);
ContextualMoment check_moment(persistence::SqliteDatabase &, const project::Project &,
                              const ContextualMoment &);
std::string insert(persistence::SqliteDatabase &, const ContextualSnapshot &, const std::string &);
void validate_containment(persistence::SqliteDatabase &, const std::string &work);
ContextualSnapshot read(persistence::SqliteDatabase &, const project::Project &,
                        const std::string &);
ContextualSnapshot check(persistence::SqliteDatabase &,
                         const project::Project &, const ContextualSnapshot &);
const ContextualParticipation &participation(const ContextualSnapshot &,
                                             const std::string &);
void budget(persistence::SqliteDatabase &, const std::string &);
void append_extended_snapshot(persistence::SqliteDatabase &,
                              ContextualSnapshot &, std::string &);
void append_visual_snapshot(persistence::SqliteDatabase &,
                            ContextualSnapshot &, std::string &);
void group_visual(persistence::SqliteDatabase &, const ContextualSnapshot &,
                  const std::vector<std::string> &, const std::string &group);
void insert_visual(persistence::SqliteDatabase &, const ContextualSnapshot &,
                   const ContextualVisualItem &);
std::int64_t extended_budget(persistence::SqliteDatabase &,
                             const std::string &);
BuilderRealization resolve_text(persistence::SqliteDatabase &, const project::Project &,
                                const ContextualTextLink &, bool observe);
} // namespace inde::application::contextual_detail
