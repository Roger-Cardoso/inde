#include "inde/application/contextual_planning.hpp"
#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include "inde/persistence/schema_migrator.hpp"
#include "inde/persistence/sqlite_database.hpp"
#include <algorithm>
#include <glib.h>
#include <limits>
#include <set>
#include <stdexcept>

namespace inde::application {
namespace contextual_detail {
using namespace persistence;
constexpr std::size_t max_rows = 2000;
const project::Project &current(ProjectService &s) {
  if (!s.current())
    throw std::runtime_error("Abra um Projeto primeiro");
  return *s.current();
}
SqliteDatabase open(const project::Project &p) {
  auto path = ProjectDatabaseRepository::database_path(p.path());
  if (!std::filesystem::is_regular_file(path))
    throw std::runtime_error("Banco ausente");
  return SqliteDatabase(path);
}
void guard(SqliteDatabase &db, const project::Project &p) {
  if (SchemaMigrator{}.current_version(db) != current_database_schema_version ||
      db.query_integer("SELECT count(*) FROM projects") != 1 ||
      db.query_text("SELECT id FROM projects") != p.manifest().project_id)
    throw std::runtime_error("Projeto/schema incompatível; reabra o Projeto");
}
void work(SqliteDatabase &db, const project::Project &p,
          const std::string &id) {
  guard(db, p);
  auto q = db.prepare(
      "SELECT w.id FROM works w JOIN intellectual_properties i ON "
      "i.id=w.intellectual_property_id WHERE w.id=? AND i.project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error("Obra ausente neste Projeto");
}
bool blank(const std::string &v) {
  for (const char *at = v.c_str(); *at; at = g_utf8_next_char(at))
    if (!g_unichar_isspace(g_utf8_get_char(at)))
      return false;
  return true;
}
void text(const std::string &v, std::size_t limit) {
  if (v.size() > limit * 4 || v.find('\0') != std::string::npos ||
      !g_utf8_validate(v.data(), v.size(), nullptr) ||
      static_cast<std::size_t>(g_utf8_strlen(v.data(), v.size())) > limit)
    throw std::runtime_error(
        "Texto inválido ou longo demais; rascunho não foi gravado");
}
void content(const std::string &title, const std::string &description) {
  text(title, 200);
  text(description, 4096);
  if (blank(title) && blank(description))
    throw std::runtime_error(
        "Informe um título ou uma descrição; pode ser incompleta");
}
void evidence(std::string &out, const std::string &v) {
  out += std::to_string(v.size()) + ":" + v;
  if (out.size() > 8 * 1024 * 1024)
    throw std::runtime_error("Consulta excede 8 MiB; nada foi truncado");
}
std::string hash(const std::string &v) {
  auto *p =
      g_compute_checksum_for_string(G_CHECKSUM_SHA256, v.data(), v.size());
  if (!p)
    throw std::bad_alloc();
  std::string result(p);
  g_free(p);
  return result;
}
ContextualSnapshot read(SqliteDatabase &db, const project::Project &p,
                        const std::string &id) {
  guard(db, p);
  auto q = db.prepare(
      "SELECT work_id,title FROM contextual_plans WHERE id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error("Composição contextual ausente");
  ContextualSnapshot s;
  s.project_id = p.manifest().project_id;
  s.plan_id = id;
  s.work_id = q.column_text(0);
  s.title = q.column_text(1);
  text(s.title, 200);
  std::string proof;
  for (const auto &v : {s.project_id, s.plan_id, s.work_id, s.title})
    evidence(proof, v);
  auto rows = db.prepare(
      "SELECT x.id,x.moment_id,m.title,m.description,x.note,x.position,m.token,"
      "coalesce(u.scale,''),coalesce(u.contents_plan_id,''),coalesce(r."
      "category,''),coalesce(r.parallel,0) "
      "FROM contextual_participations x JOIN contextual_moments m ON "
      "m.id=x.moment_id LEFT JOIN contextual_modules u ON u.moment_id=m.id "
      "LEFT JOIN contextual_roles r ON r.participation_id=x.id "
      "WHERE x.plan_id=? ORDER BY x.position,x.id");
  rows.bind(1, id);
  while (rows.step()) {
    if (s.participations.size() >= max_rows)
      throw std::runtime_error(
          "Composição excede 2.000 participações; nada foi truncado");
    for (int c = 0; c < 11; ++c)
      evidence(proof, c == 5 || c == 10 ? std::to_string(rows.column_integer(c))
                                        : rows.column_text(c));
    const auto position = rows.column_integer(5);
    text(rows.column_text(2), 200);
    text(rows.column_text(3), 4096);
    text(rows.column_text(4), 4096);
    text(rows.column_text(7), 80);
    text(rows.column_text(9), 80);
    if (!s.participations.empty() &&
        s.participations.back().position >= position)
      throw std::runtime_error(
          "Ordem local inconsistente; nenhuma alteração confirmada");
    s.participations.push_back(
        {rows.column_text(0), rows.column_text(1), rows.column_text(2),
         rows.column_text(3), rows.column_text(4), position,
         rows.column_text(7), rows.column_text(8), rows.column_text(9),
         rows.column_integer(10) != 0});
  }
  append_extended_snapshot(db, s, proof);
  append_visual_snapshot(db, s, proof);
  s.revision = hash(proof);
  return s;
}
ContextualSnapshot check(SqliteDatabase &db, const project::Project &p,
                         const ContextualSnapshot &s) {
  auto actual = read(db, p, s.plan_id);
  if (s.project_id != actual.project_id || s.revision != actual.revision)
    throw std::runtime_error(
        "Composição mudou; atualize antes de confirmar. Nada foi alterado");
  return actual;
}
ContextualMoment read_moment(SqliteDatabase &db, const project::Project &p,
                             const std::string &id) {
  guard(db, p);
  auto q = db.prepare("SELECT work_id,title,description,token FROM "
                      "contextual_moments WHERE id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error("Acontecimento ausente");
  ContextualMoment m{id,
                     p.manifest().project_id,
                     q.column_text(0),
                     q.column_text(1),
                     q.column_text(2),
                     {},
                     {}};
  std::string proof;
  for (const auto &v : {m.id, m.project_id, m.work_id, m.title, m.description,
                        q.column_text(3)})
    evidence(proof, v);
  auto module = db.prepare("SELECT scale,coalesce(contents_plan_id,'') FROM "
                           "contextual_modules WHERE moment_id=?");
  module.bind(1, id);
  if (module.step()) {
    m.scale = module.column_text(0);
    m.contents_plan_id = module.column_text(1);
  }
  text(m.scale, 80);
  evidence(proof, m.scale);
  evidence(proof, m.contents_plan_id);
  auto uses = db.prepare(
      "SELECT x.id,x.plan_id,p.title FROM contextual_participations x "
      "JOIN contextual_plans p ON p.id=x.plan_id WHERE x.moment_id=? ORDER BY "
      "x.id");
  uses.bind(1, id);
  while (uses.step()) {
    if (m.uses.size() >= max_rows)
      throw std::runtime_error(
          "Alcance excede 2.000 usos; edição recusada sem truncamento");
    for (int c = 0; c < 3; ++c)
      evidence(proof, uses.column_text(c));
    m.uses.push_back(
        {uses.column_text(0), uses.column_text(1), uses.column_text(2)});
  }
  m.revision = hash(proof);
  return m;
}
ContextualMoment check_moment(SqliteDatabase &db, const project::Project &p,
                              const ContextualMoment &m) {
  auto actual = read_moment(db, p, m.id);
  if (m.project_id != actual.project_id || m.revision != actual.revision)
    throw std::runtime_error("Conteúdo ou alcance compartilhado mudou; "
                             "consulte novamente. Nada foi alterado");
  return actual;
}
const ContextualParticipation &participation(const ContextualSnapshot &s,
                                             const std::string &id) {
  auto it = std::find_if(s.participations.begin(), s.participations.end(),
                         [&](const auto &x) { return x.id == id; });
  if (it == s.participations.end())
    throw std::runtime_error("Participação ausente desta composição");
  return *it;
}
std::string insert(SqliteDatabase &db, const ContextualSnapshot &s,
                   const std::string &moment) {
  if (s.participations.size() >= max_rows)
    throw std::runtime_error("Limite de 2.000 participações; nada foi criado");
  auto position =
      s.participations.empty() ? 0 : s.participations.back().position;
  if (position == std::numeric_limits<std::int64_t>::max())
    throw std::runtime_error("Ordem local excedida");
  if (!s.participations.empty())
    ++position;
  const auto id = project::new_uuid();
  auto q = db.prepare("INSERT INTO "
                      "contextual_participations(id,project_id,work_id,plan_id,"
                      "moment_id,position) VALUES(?,?,?,?,?,?)");
  q.bind(1, id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, s.plan_id);
  q.bind(5, moment);
  q.bind(6, position);
  q.run();
  return id;
}
// Conservative upper bound for the exact length-prefixed snapshot; protects
// affected plans without materializing every plan during a shared edit.
void budget(SqliteDatabase &db, const std::string &plan) {
  auto q = db.prepare(
      "SELECT count(*),coalesce(sum(length(CAST(x.id AS "
      "BLOB))+length(CAST(x.moment_id AS BLOB))+"
      "length(CAST(m.title AS BLOB))+length(CAST(m.description AS "
      "BLOB))+length(CAST(x.note AS BLOB))+"
      "length(CAST(m.token AS BLOB))+1000),0) FROM contextual_participations x "
      "JOIN contextual_moments m ON m.id=x.moment_id WHERE x.plan_id=?");
  q.bind(1, plan);
  q.step();
  auto visual = db.prepare("SELECT count(*) FROM contextual_visual_items WHERE plan_id=?");
  visual.bind(1, plan);
  visual.step();
  if (q.column_integer(0) > static_cast<std::int64_t>(max_rows) ||
      q.column_integer(1) + extended_budget(db, plan) + visual.column_integer(0)*1400 > 8 * 1024 * 1024 - 2048)
    throw std::runtime_error("A composição excederia 2.000 participações ou 8 "
                             "MiB; nada foi confirmado");
}
} // namespace contextual_detail
using namespace contextual_detail;
using namespace persistence;
std::vector<ContextualPlan>
ContextualPlanningService::plans(const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  work(db, p, id);
  auto q =
      db.prepare("SELECT p.id,p.work_id,p.title FROM contextual_plans p WHERE "
                 "p.project_id=? AND p.work_id=? ORDER BY EXISTS(SELECT 1 FROM "
                 "contextual_modules u WHERE "
                 "u.contents_plan_id=p.id),p.title,p.id LIMIT 201");
  q.bind(1, p.manifest().project_id);
  q.bind(2, id);
  std::vector<ContextualPlan> out;
  while (q.step()) {
    if (out.size() >= 200)
      throw std::runtime_error(
          "Mais de 200 composições nesta Obra; consulta não foi truncada");
    out.push_back({q.column_text(0), q.column_text(1), q.column_text(2)});
  }
  tx.commit();
  return out;
}
ContextualSnapshot
ContextualPlanningService::snapshot(const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  auto out = read(db, p, id);
  tx.commit();
  return out;
}
ContextualMoment
ContextualPlanningService::moment(const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  auto out = read_moment(db, p, id);
  tx.commit();
  return out;
}
ContextualMomentPage
ContextualPlanningService::moments(const std::string &id,
                                   const std::string &search,
                                   std::size_t offset) const {
  text(search, 200);
  if (offset > 1000000)
    throw std::runtime_error("Página fora do limite de consulta");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  work(db, p, id);
  auto q = db.prepare(
      "SELECT id,title,description FROM contextual_moments WHERE project_id=? "
      "AND work_id=? "
      "AND (?='' OR instr(lower(title),lower(?))>0 OR "
      "instr(lower(description),lower(?))>0) ORDER BY id LIMIT 51 OFFSET ?");
  q.bind(1, p.manifest().project_id);
  q.bind(2, id);
  q.bind(3, search);
  q.bind(4, search);
  q.bind(5, search);
  q.bind(6, static_cast<std::int64_t>(offset));
  ContextualMomentPage out;
  while (q.step()) {
    if (out.rows.size() == 50) {
      out.more = true;
      break;
    }
    out.rows.push_back({q.column_text(0), q.column_text(1), q.column_text(2)});
  }
  tx.commit();
  return out;
}
std::string ContextualPlanningService::create_plan(const std::string &id,
                                                   const std::string &title) {
  text(title, 200);
  if (blank(title))
    throw std::runtime_error("Informe um nome para a composição");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Criar composição contextual");
  work(db, p, id);
  auto count =
      db.prepare("SELECT count(*) FROM contextual_plans WHERE work_id=?");
  count.bind(1, id);
  count.step();
  if (count.column_integer(0) >= 200)
    throw std::runtime_error("Limite de 200 composições por Obra");
  auto q =
      db.prepare("INSERT INTO contextual_plans(id,project_id,work_id,title) "
                 "VALUES(?,?,?,?)");
  const auto result = project::new_uuid();
  q.bind(1, result);
  q.bind(2, p.manifest().project_id);
  q.bind(3, id);
  q.bind(4, title);
  q.run();
  tx.commit();
  return result;
}
std::string
ContextualPlanningService::create_moment(const ContextualSnapshot &s,
                                         const std::string &title,
                                         const std::string &description,
                                         const ContextualVisualItem *placement) {
  content(title, description);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Criar acontecimento e participação contextual");
  auto actual = check(db, p, s);
  auto q = db.prepare("INSERT INTO "
                      "contextual_moments(id,project_id,work_id,title,"
                      "description,token) VALUES(?,?,?,?,?,?)");
  const auto id = project::new_uuid();
  q.bind(1, id);
  q.bind(2, actual.project_id);
  q.bind(3, actual.work_id);
  q.bind(4, title);
  q.bind(5, description);
  q.bind(6, project::new_uuid());
  q.run();
  auto result = insert(db, actual, id);
  if (placement) {
    auto v=*placement;
    v.id=v.participation_id=result;
    v.kind="block";
    v.label.clear();
    insert_visual(db,actual,v);
  }
  budget(db, actual.plan_id);
  tx.commit();
  return result;
}
std::string ContextualPlanningService::reuse_moment(const ContextualSnapshot &s,
                                                    const ContextualMoment &m) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Reutilizar acontecimento sem copiar conteúdo");
  auto actual = check(db, p, s);
  auto observed = check_moment(db, p, m);
  if (actual.work_id != observed.work_id)
    throw std::runtime_error("Acontecimento pertence a outra Obra");
  if (observed.uses.size() >= max_rows)
    throw std::runtime_error(
        "Alcance excederia 2.000 usos; nada foi confirmado");
  auto result = insert(db, actual, observed.id);
  if (!observed.contents_plan_id.empty())
    validate_containment(db, actual.work_id);
  budget(db, actual.plan_id);
  tx.commit();
  return result;
}
void ContextualPlanningService::update_moment(const ContextualMoment &m,
                                              const std::string &title,
                                              const std::string &description) {
  content(title, description);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Editar conteúdo compartilhado de acontecimento");
  auto actual = check_moment(db, p, m);
  if (actual.title != title || actual.description != description) {
    auto q = db.prepare("UPDATE contextual_moments SET "
                        "title=?,description=?,token=? WHERE id=?");
    q.bind(1, title);
    q.bind(2, description);
    q.bind(3, project::new_uuid());
    q.bind(4, actual.id);
    q.run();
    // The interior's label is derived mechanically from its shared owner.
    // No second author-maintained synopsis or title is introduced.
    if (!actual.contents_plan_id.empty()) {
      auto name = db.prepare("UPDATE contextual_plans SET title=? WHERE id=?");
      const auto caption =
          title.empty() ? std::string("Interior do trecho") : title;
      name.bind(1, caption);
      name.bind(2, actual.contents_plan_id);
      name.run();
    }
    std::set<std::string> affected;
    for (const auto &use : actual.uses)
      affected.insert(use.plan_id);
    for (const auto &plan : affected)
      budget(db, plan);
  }
  tx.commit();
}
void ContextualPlanningService::set_note(const ContextualSnapshot &s,
                                         const std::string &id,
                                         const std::string &note) {
  text(note, 4096);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Editar nota local de participação");
  auto actual = check(db, p, s);
  participation(actual, id);
  auto q = db.prepare("UPDATE contextual_participations SET note=? WHERE id=?");
  q.bind(1, note);
  q.bind(2, id);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
}
void ContextualPlanningService::detach(const ContextualSnapshot &s,
                                       const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Retirar participação sem excluir acontecimento");
  auto actual = check(db, p, s);
  participation(actual, id);
  auto uses = db.prepare(
      "SELECT (SELECT count(*) FROM contextual_option_members WHERE "
      "participation_id=?1)+"
      "(SELECT count(*) FROM contextual_declarations WHERE "
      "participation_id=?1)+"
      "(SELECT count(*) FROM contextual_dependencies WHERE source_id=?1 OR "
      "target_id=?1)+"
      "(SELECT count(*) FROM contextual_text_links WHERE participation_id=?1)");
  uses.bind(1, id);
  uses.step();
  if (uses.column_integer(0))
    throw std::runtime_error(
        "Retire explicitamente encaixe, declarações, dependências e vínculos "
        "textuais antes de retirar a participação. Nada foi alterado");
  auto role =
      db.prepare("DELETE FROM contextual_roles WHERE participation_id=?");
  role.bind(1, id);
  role.run();
  auto visual = db.prepare("DELETE FROM contextual_visual_items WHERE participation_id=?");
  visual.bind(1, id);
  visual.run();
  auto q = db.prepare("DELETE FROM contextual_participations WHERE id=?");
  q.bind(1, id);
  q.run();
  tx.commit();
}
void ContextualPlanningService::move(const ContextualSnapshot &s,
                                     const std::string &id, int direction) {
  if (direction != 1 && direction != -1)
    throw std::runtime_error("Direção inválida");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db,
                       "Mover participação na apresentação narrativa local");
  auto actual = check(db, p, s);
  const auto &x = participation(actual, id);
  auto at =
      std::find_if(actual.participations.begin(), actual.participations.end(),
                   [&](const auto &v) { return v.id == id; }) -
      actual.participations.begin();
  const auto target = at + direction;
  if (target < 0 ||
      target >= static_cast<std::ptrdiff_t>(actual.participations.size())) {
    tx.commit();
    return;
  }
  const auto &y = actual.participations[target];
  auto q =
      db.prepare("UPDATE contextual_participations SET position=? WHERE id=?");
  q.bind(1, y.position);
  q.bind(2, x.id);
  q.run();
  q.reset();
  q.bind(1, x.position);
  q.bind(2, y.id);
  q.run();
  tx.commit();
}
} // namespace inde::application
