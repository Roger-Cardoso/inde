#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <limits>
#include <stdexcept>
namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
namespace {
struct TargetSql {
  std::string column, from, title, detail, stamp, work;
};
TargetSql target_sql(const std::string &kind) {
  if (kind == "entity")
    return {"entity_id",
            "entities t JOIN entity_types k ON k.id=t.entity_type_id",
            "t.name",
            "k.name||' · '||t.summary",
            "t.updated_at",
            ""};
  if (kind == "relation")
    return {"relation_id",
            "relations t JOIN entities a ON a.id=t.source_entity_id JOIN "
            "entities b ON b.id=t.target_entity_id JOIN relation_types k ON "
            "k.id=t.relation_type_id",
            "a.name||' — '||k.name||' — '||b.name",
            "t.description",
            "t.updated_at",
            ""};
  if (kind == "unit")
    return {
        "unit_id",
        "narrative_units t JOIN narrative_structures s ON s.id=t.structure_id",
        "t.title",
        "s.name||' · '||t.summary",
        "t.updated_at",
        "s.work_id"};
  if (kind == "line")
    return {
        "line_id",
        "narrative_lines t JOIN narrative_structures s ON s.id=t.structure_id",
        "t.name",
        "s.name||' · '||t.description",
        "t.updated_at",
        "s.work_id"};
  if (kind == "time")
    return {
        "reference_id",
        "temporal_references t JOIN fictional_time_axes a ON a.id=t.axis_id",
        "t.label",
        "a.name||' · '||t.note",
        "t.token",
        ""};
  if (kind == "point")
    return {
        "point_id",
        "fictional_time_points t JOIN fictional_time_axes a ON a.id=t.axis_id",
        "t.label",
        "a.name||' · ordem '||t.ordinal",
        "CAST(t.ordinal AS TEXT)",
        ""};
  if (kind == "map")
    return {"map_id",       "cartographic_planets t",
            "t.name",       "'Mapa; não declara coordenada ou presença'",
            "t.created_at", ""};
  if (kind == "document")
    return {"",
            "documents t",
            "t.title",
            "CAST(length(t.content) AS TEXT)||' caracteres'",
            "t.updated_at",
            ""};
  if (kind == "composition")
    return {"", "compositions t", "t.name", "'Montagem de texto'", "t.sha256",
            ""};
  throw std::runtime_error("Tipo de referência contextual inválido");
}
ContextualReferenceTarget row(SqliteStatement &q, const project::Project &p,
                              const std::string &work,
                              const std::string &kind) {
  ContextualReferenceTarget v{
      p.manifest().project_id, work, kind, q.column_text(0), q.column_text(1),
      q.column_text(2),        {}};
  std::string proof;
  for (const auto &s : {v.project_id, v.work_id, v.kind, v.id, v.title,
                        v.detail, q.column_text(3)})
    evidence(proof, s);
  v.revision = hash(proof);
  return v;
}
ContextualReferenceTarget target(SqliteDatabase &db, const project::Project &p,
                                 const std::string &work,
                                 const std::string &kind,
                                 const std::string &id) {
  const auto sql = target_sql(kind);
  auto q = db.prepare("SELECT t.id," + sql.title + "," + sql.detail + "," +
                      sql.stamp + " FROM " + sql.from +
                      " WHERE t.id=? AND t.project_id=?" +
                      (sql.work.empty() ? "" : " AND " + sql.work + "=?"));
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!sql.work.empty())
    q.bind(3, work);
  if (!q.step())
    throw std::runtime_error(
        "Referência ausente no Projeto/Obra; origem preservada");
  return row(q, p, work, kind);
}
} // namespace
ContextualReferenceTarget
ContextualPlanningService::reference_target(const std::string &work,
                                            const std::string &kind,
                                            const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  guard(db, p);
  auto out = target(db, p, work, kind, id);
  tx.commit();
  return out;
}
ContextualReferencePage ContextualPlanningService::reference_targets(
    const std::string &work, const std::string &kind, const std::string &search,
    std::size_t offset) const {
  text(search, 200);
  if (offset > 1000000)
    throw std::runtime_error("Página excede o limite de consulta");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  guard(db, p);
  const auto sql = target_sql(kind);
  // Filter before LIMIT; no wildcard or untrusted identifier interpolation.
  auto q = db.prepare(
      "SELECT t.id," + sql.title + "," + sql.detail + "," + sql.stamp +
      " FROM " + sql.from + " WHERE t.project_id=?1 AND (instr(lower(" +
      sql.title + "||' '||" + sql.detail + "||' '||t.id),lower(?2))>0" +
      (kind == "entity"
           ? " OR EXISTS(SELECT 1 FROM entity_aliases alias WHERE "
             "alias.entity_id=t.id AND instr(lower(alias.name),lower(?2))>0)"
           : "") +
      ")" + (sql.work.empty() ? "" : " AND " + sql.work + "=?3") +
      " ORDER BY " + sql.title + ",t.id LIMIT 51 OFFSET ?4");
  q.bind(1, p.manifest().project_id);
  q.bind(2, search);
  if (!sql.work.empty())
    q.bind(3, work);
  q.bind(4, static_cast<std::int64_t>(offset));
  ContextualReferencePage out;
  std::size_t bytes{};
  while (q.step()) {
    if (out.rows.size() == 50) {
      out.more = true;
      break;
    }
    auto value=row(q,p,work,kind);
    bytes+=value.title.size()+value.detail.size()+512;
    if(bytes>8*1024*1024)throw std::runtime_error("Página de referências excede 8 MiB; refine a busca. Nada foi truncado");
    out.rows.push_back(std::move(value));
  }
  tx.commit();
  return out;
}
std::string ContextualPlanningService::add_reference(
    const ContextualSnapshot &s, const std::string &part,
    const ContextualReferenceTarget &observed, const std::string &note) {
  text(note, 2048);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Referenciar origem no contexto, sem copiar ou promover autoridade");
  const auto a = check(db, p, s);
  participation(a, part);
  const auto v = target(db, p, a.work_id, observed.kind, observed.id);
  if (target_sql(v.kind).column.empty())
    throw std::runtime_error(
        "Use a associação textual para Documento ou montagem");
  if (v.revision != observed.revision || v.project_id != observed.project_id ||
      v.work_id != observed.work_id)
    throw std::runtime_error(
        "Origem mudou; consulte novamente. Rascunho preservado");
  if (std::any_of(a.references.begin(), a.references.end(), [&](auto &r) {
        return r.participation_id == part && r.kind == v.kind &&
               r.target_id == v.id;
      }))
    throw std::runtime_error("Origem já referenciada nesta participação");
  const auto id = project::new_uuid();
  auto q = db.prepare(
      "INSERT INTO "
      "contextual_references(id,project_id,work_id,plan_id,participation_id," +
      target_sql(v.kind).column + ",note) VALUES(?,?,?,?,?,?,?)");
  q.bind(1, id);
  q.bind(2, a.project_id);
  q.bind(3, a.work_id);
  q.bind(4, a.plan_id);
  q.bind(5, part);
  q.bind(6, v.id);
  q.bind(7, note);
  q.run();
  budget(db, a.plan_id);
  tx.commit();
  return id;
}
void ContextualPlanningService::remove_reference(const ContextualSnapshot &s,
                                                 const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db,
                       "Retirar referência contextual, preservando a origem");
  const auto a = check(db, p, s);
  if (std::none_of(a.references.begin(), a.references.end(),
                   [&](auto &v) { return v.id == id; }))
    throw std::runtime_error("Referência ausente deste contexto");
  auto q = db.prepare("DELETE FROM contextual_references WHERE id=?");
  q.bind(1, id);
  q.run();
  tx.commit();
}
ContextualProjectionPage ContextualPlanningService::projection(
    const std::string &kind, const std::string &id, std::size_t offset) const {
  if (offset > 1000000)
    throw std::runtime_error("Página excede limite de consulta");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  guard(db, p);
  const auto sql = target_sql(kind);
  if (sql.column.empty())
    throw std::runtime_error("Use a consulta de vínculos textuais");
  auto q = db.prepare(
      "SELECT r.id,p.id,p.title,x.id,m.title,r.note,CASE WHEN "
      "o.participation_id IS NULL OR c.selected_option_id=o.option_id THEN 1 "
      "ELSE 0 END "
      "FROM contextual_references r JOIN contextual_plans p ON p.id=r.plan_id "
      "JOIN contextual_participations x ON x.id=r.participation_id JOIN "
      "contextual_moments m ON m.id=x.moment_id "
      "LEFT JOIN contextual_option_members o ON o.participation_id=x.id LEFT "
      "JOIN contextual_options z ON z.id=o.option_id "
      "LEFT JOIN contextual_slots c ON c.id=z.slot_id WHERE r." +
      sql.column +
      "=? AND r.project_id=? "
      "ORDER BY p.title,p.id,x.position,r.id LIMIT 51 OFFSET ?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  q.bind(3, static_cast<std::int64_t>(offset));
  ContextualProjectionPage out;
  while (q.step()) {
    if (out.rows.size() == 50) {
      out.more = true;
      break;
    }
    out.rows.push_back({q.column_text(0), q.column_text(1), q.column_text(2),
                        q.column_text(3), q.column_text(4), q.column_text(5),
                        q.column_integer(6) != 0});
  }
  tx.commit();
  return out;
}
std::string ContextualPlanningService::add_bridge(
    const ContextualSnapshot &s, const std::string &dest,
    const ContextualSnapshot &source, const std::string &origin,
    const std::string &kind, const std::string &note) {
  text(note, 2048);
  if (kind != "context" && kind != "succession" && kind != "cause" &&
      kind != "motivation" && kind != "condition")
    throw std::runtime_error("Tipo de dependência inválido");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Declarar dependência entre composições, sem copiar estados");
  const auto a = check(db, p, s), b = check(db, p, source);
  participation(a, dest);
  participation(b, origin);
  if (a.plan_id == b.plan_id || a.work_id != b.work_id)
    throw std::runtime_error("Escolha outra composição da mesma Obra");
  const auto id = project::new_uuid();
  auto q = db.prepare(
      "INSERT INTO "
      "contextual_bridges(id,project_id,work_id,plan_id,target_id,source_plan_"
      "id,source_id,kind,note) VALUES(?,?,?,?,?,?,?,?,?)");
  q.bind(1, id);
  q.bind(2, a.project_id);
  q.bind(3, a.work_id);
  q.bind(4, a.plan_id);
  q.bind(5, dest);
  q.bind(6, b.plan_id);
  q.bind(7, origin);
  q.bind(8, kind);
  q.bind(9, note);
  q.run();
  budget(db, a.plan_id);
  tx.commit();
  return id;
}
void ContextualPlanningService::remove_bridge(const ContextualSnapshot &s,
                                              const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Retirar dependência entre composições");
  const auto a = check(db, p, s);
  if (std::none_of(a.bridges.begin(), a.bridges.end(),
                   [&](auto &v) { return v.id == id; }))
    throw std::runtime_error("Dependência ausente");
  auto q = db.prepare("DELETE FROM contextual_bridges WHERE id=?");
  q.bind(1, id);
  q.run();
  tx.commit();
}
} // namespace inde::application
