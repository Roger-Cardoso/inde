#include "inde/application/semantic_anchor_engine.hpp"
#include <algorithm>
#include <glib.h>
#include <limits>
#include <stdexcept>
#include <string_view>
#include <unordered_map>
namespace inde::application {
namespace {
// One validation/pass per immutable text in an operation. Sparse checkpoints
// bound memory to one byte offset per 256 Unicode scalars; each lookup scans
// at most 255 scalars instead of restarting at the beginning of the Document.
class TextIndex {
public:
  explicit TextIndex(const std::string &text) : text_(text) {
    if (!g_utf8_validate(text.data(), text.size(), nullptr))
      throw std::runtime_error("Âncoras exigem UTF-8 válido");
    checkpoints_.push_back(0);
    for (const char *p = text.data(), *end = p + text.size(); p < end;) {
      p = g_utf8_next_char(p);
      ++length_;
      if (length_ % stride == 0)
        checkpoints_.push_back(static_cast<std::size_t>(p - text.data()));
    }
  }
  std::size_t length() const { return length_; }
  std::size_t byte_offset(std::size_t offset) const {
    if (offset > length_) throw std::runtime_error("Âncora semântica fora do Documento");
    const auto base = offset / stride;
    const char *p = text_.data() + checkpoints_[base];
    for (std::size_t i = 0; i < offset % stride; ++i) p = g_utf8_next_char(p);
    return static_cast<std::size_t>(p - text_.data());
  }
  std::string_view slice(std::size_t start, std::size_t end) const {
    const auto a = byte_offset(start), b = byte_offset(end);
    return std::string_view(text_).substr(a, b - a);
  }
private:
  static constexpr std::size_t stride = 256;
  const std::string &text_;
  std::vector<std::size_t> checkpoints_;
  std::size_t length_{};
};
using AnchorIndex = std::unordered_map<std::string, project::DocumentAnchor *>;
AnchorIndex anchor_index(project::Document &d) {
  AnchorIndex result;
  result.reserve(d.anchors.size());
  for (auto &anchor : d.anchors) result.emplace(anchor.id, &anchor);
  return result;
}
project::DocumentAnchor &find_anchor(const AnchorIndex &anchors, const std::string &id) {
  const auto found = anchors.find(id);
  if (found == anchors.end()) throw std::runtime_error("Evidência sem âncora");
  return *found->second;
}
std::string hash(std::string_view s) {
  auto *h = g_compute_checksum_for_data(
      G_CHECKSUM_SHA256, reinterpret_cast<const guchar *>(s.data()), s.size());
  std::string out(h);
  g_free(h);
  return out;
}
void valid_text(const std::string &s) {
  if (!g_utf8_validate(s.data(), s.size(), nullptr))
    throw std::runtime_error("Âncoras exigem UTF-8 válido");
}
void refresh(const TextIndex &text, const project::DocumentAnchor &a,
             project::SemanticAnchorEvidence &e) {
  e.selected_hash = hash(text.slice(a.start_offset, a.end_offset));
  e.before_hash =
      hash(text.slice(a.start_offset > 32 ? a.start_offset - 32 : 0,
                 a.start_offset));
  e.after_hash =
      hash(text.slice(a.end_offset, std::min(text.length(), a.end_offset + 32)));
}
void inspect(project::Document &d, const TextIndex &text, const AnchorIndex &anchors) {
  for (auto &e : d.semantics.anchors) {
    const auto &a = find_anchor(anchors, e.anchor_id);
    if (a.start_offset > a.end_offset || a.end_offset > text.length())
      throw std::runtime_error("Âncora semântica fora do Documento");
    if (e.state != project::AnchorResolution::Resolved) continue;
    auto expected = e;
    refresh(text, a, expected);
    if (expected.selected_hash != e.selected_hash ||
        expected.before_hash != e.before_hash || expected.after_hash != e.after_hash) {
      e.state = project::AnchorResolution::Ambiguous;
      e.reason = "Fingerprint do trecho divergiu; confirmar reancoragem humana";
    }
  }
}
std::size_t move(std::size_t p, std::size_t a, std::size_t b, std::size_t n,
                 project::AnchorGravity gravity) {
  if (p < a)
    return p;
  if (p > b)
    return p - (b - a) + n;
  return a + (gravity == project::AnchorGravity::Right ? n : 0);
}
} // namespace
project::SemanticAnchorEvidence
SemanticAnchorEngine::evidence(const project::Document &d,
                               const project::DocumentAnchor &a) {
  const TextIndex text(d.content);
  if (a.start_offset >= a.end_offset ||
      a.end_offset > text.length())
    throw std::runtime_error(
        "Selecione um trecho não vazio para a camada semântica");
  project::SemanticAnchorEvidence e;
  e.anchor_id = a.id;
  refresh(text, a, e);
  return e;
}
void SemanticAnchorEngine::edit(project::Document &d, std::size_t start,
                                std::size_t end,
                                const std::string &replacement) {
  const TextIndex text(d.content);
  valid_text(replacement);
  const auto length = text.length();
  if (start > end || end > length)
    throw std::runtime_error("Edição fora do Documento");
  // A trusted new keystroke must not silently bless evidence already divergent
  // at load time (external modification/import). Repair stays a human command.
  const auto anchors = anchor_index(d);
  ::inde::application::inspect(d, text, anchors);
  project::Document after;
  after.content = d.content;
  const auto p = text.byte_offset(start), q = text.byte_offset(end);
  if (text.slice(start, end) == replacement)
    return;
  after.content.replace(p, q - p, replacement);
  const TextIndex after_text(after.content);
  auto n = project::utf8_character_count(replacement);
  for (auto &e : d.semantics.anchors) {
    auto *it = &find_anchor(anchors, e.anchor_id);
    auto old = *it;
    if (e.revision == std::numeric_limits<std::uint64_t>::max())
      throw std::runtime_error("Revisão semântica excedida");
    ++e.revision;
    it->start_offset = move(old.start_offset, start, end, n, e.start_gravity);
    it->end_offset = move(old.end_offset, start, end, n, e.end_gravity);
    if (it->start_offset > it->end_offset)
      it->start_offset = it->end_offset;
    if (e.state == project::AnchorResolution::Resolved && start < end &&
        start <= old.start_offset && end >= old.end_offset) {
      e.state = n ? project::AnchorResolution::Ambiguous
                  : project::AnchorResolution::Orphaned;
      e.reason =
          n ? "O trecho inteiro foi substituído; confirme uma nova ancoragem"
            : "O trecho foi removido; a anotação foi preservada";
    }
    if (e.state == project::AnchorResolution::Resolved &&
        it->start_offset == it->end_offset) {
      e.state = project::AnchorResolution::Orphaned;
      e.reason = "O intervalo ficou vazio; reancoragem humana necessária";
    }
    if (e.state == project::AnchorResolution::Resolved) {
      refresh(after_text, *it, e);
      e.reason.clear();
    }
  }
}
void SemanticAnchorEngine::inspect(project::Document &d) {
  const TextIndex text(d.content);
  ::inde::application::inspect(d, text, anchor_index(d));
}
void SemanticAnchorEngine::relocate(const project::Document &before, project::Document &after) {
  if (before.semantics.anchors.empty()) return;
  auto inspected = before;
  const TextIndex old_text(inspected.content), new_text(after.content);
  const auto old_anchors = anchor_index(inspected), new_anchors = anchor_index(after);
  ::inde::application::inspect(inspected, old_text, old_anchors);
  auto evidence = inspected.semantics.anchors;
  for (auto &e : evidence) {
    const auto &a = find_anchor(old_anchors, e.anchor_id);
    const auto &b = find_anchor(new_anchors, e.anchor_id);
    if (old_text.slice(a.start_offset, a.end_offset) != new_text.slice(b.start_offset, b.end_offset))
      throw std::runtime_error("Mover não pode substituir o texto de uma marcação");
    if (e.revision == std::numeric_limits<std::uint64_t>::max())
      throw std::runtime_error("Revisão semântica excedida");
    ++e.revision;
    if (e.state == project::AnchorResolution::Resolved) refresh(new_text, b, e);
  }
  after.semantics.anchors = std::move(evidence);
}
void SemanticAnchorEngine::reanchor(project::Document &d, const std::string &id,
                                    std::size_t start, std::size_t end) {
  auto annotation = std::find_if(d.semantics.annotations.begin(),
                                 d.semantics.annotations.end(),
                                 [&](auto &a) { return a.id == id; });
  if (annotation == d.semantics.annotations.end())
    throw std::runtime_error("Anotação ausente");
  auto a = std::find_if(d.anchors.begin(), d.anchors.end(),
                        [&](auto &x) { return x.id == annotation->anchor_id; });
  if (a == d.anchors.end())
    throw std::runtime_error("Âncora ausente");
  auto candidate = *a;
  candidate.start_offset = start;
  candidate.end_offset = end;
  auto fresh = evidence(d, candidate);
  auto e = std::find_if(d.semantics.anchors.begin(), d.semantics.anchors.end(),
                        [&](auto &x) { return x.anchor_id == a->id; });
  if (e == d.semantics.anchors.end())
    throw std::runtime_error("Evidência ausente");
  if (e->revision == std::numeric_limits<std::uint64_t>::max())
    throw std::runtime_error("Revisão semântica excedida");
  fresh.revision = e->revision + 1;
  fresh.start_gravity = e->start_gravity;
  fresh.end_gravity = e->end_gravity;
  *a = candidate;
  *e = fresh;
}
} // namespace inde::application
