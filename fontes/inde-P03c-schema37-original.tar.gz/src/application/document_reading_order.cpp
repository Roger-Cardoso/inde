#include "inde/application/document_reading_order.hpp"
#include "inde/application/semantic_anchor_engine.hpp"
#include <algorithm>
#include <numeric>
#include <stdexcept>
namespace inde::application {
namespace {
std::size_t paragraph_at(const std::vector<project::DocumentParagraph> &rows,
                         std::size_t point) {
  auto i = std::upper_bound(rows.begin(), rows.end(), point,
      [](auto p, const auto &r) { return p < r.start; });
  return i == rows.begin() ? 0 : static_cast<std::size_t>(i - rows.begin() - 1);
}
} // namespace
std::vector<ReadingBlock> reading_blocks(const project::Document &d) {
  const auto &rows = d.paragraphs.rows;
  if (!d.paragraphs.enabled || rows.empty()) return {};
  std::vector<std::size_t> through(rows.size());
  std::iota(through.begin(), through.end(), 0);
  for (const auto &r : d.resmas) {
    const auto a = paragraph_at(rows, r.start), b = paragraph_at(rows, r.end);
    through[a] = std::max(through[a], b);
  }
  std::vector<ReadingBlock> result;
  for (std::size_t a = 0; a < rows.size();) {
    auto b = through[a];
    for (auto i = a; i <= b; ++i) b = std::max(b, through[i]);
    result.push_back({rows[a].id, a, b, rows[a].start, rows[b].end});
    a = b + 1;
  }
  return result;
}
DocumentEditState move_reading_block(const DocumentEditState &before,
                                    const std::string &id,
                                    const std::string &destination) {
  project::validate(before.document);
  const auto blocks = reading_blocks(before.document);
  const auto source = std::find_if(blocks.begin(), blocks.end(),
      [&](const auto &b) { return b.id == id; });
  const auto target = std::find_if(blocks.begin(), blocks.end(),
      [&](const auto &b) { return b.id == destination; });
  if (source == blocks.end() || (!destination.empty() && target == blocks.end()))
    throw std::runtime_error("Bloco/destino não está mais neste Documento");
  if (source == target || (target != blocks.end() && source + 1 == target) ||
      (target == blocks.end() && source + 1 == blocks.end())) return before;
  const auto &old = before.document.paragraphs.rows;
  std::vector<std::size_t> order;
  order.reserve(old.size());
  auto append = [&](const ReadingBlock &b) {
    for (auto i = b.first; i <= b.last; ++i) order.push_back(i);
  };
  for (auto it = blocks.begin(); it != blocks.end(); ++it) {
    if (it == target) append(*source);
    if (it != source) append(*it);
  }
  if (target == blocks.end()) append(*source);
  auto after = before;
  auto &d = after.document;
  project::consolidate_paragraphs(d.paragraphs, d.content);
  const auto contents = d.paragraphs.rows;
  std::vector<std::size_t> starts(old.size()), positions(old.size());
  d.content.clear(); d.content.reserve(before.document.content.size());
  d.paragraphs.rows.clear(); d.paragraphs.rows.reserve(old.size());
  std::size_t offset = 0;
  for (std::size_t pos = 0; pos < order.size(); ++pos) {
    const auto i = order[pos];
    starts[i] = offset; positions[i] = pos;
    d.content += *contents[i].content;
    d.paragraphs.rows.push_back({old[i].id, offset, offset + old[i].end - old[i].start, contents[i].content});
    offset += old[i].end - old[i].start;
    if (pos + 1 < order.size()) { d.content += '\n'; ++offset; }
  }
  // A range can yield several pieces. Styles may split; identities/bindings
  // must remain one unchanged, ordered interval or the whole move is refused.
  auto pieces = [&](std::size_t a, std::size_t b) {
    std::vector<std::pair<std::size_t, std::size_t>> out;
    if (a == b) {
      const auto i = paragraph_at(old, a);
      const auto p = starts[i] + a - old[i].start;
      out.emplace_back(p, p); return out;
    }
    for (auto i = paragraph_at(old, a); i < old.size() && old[i].start < b; ++i) {
      const auto end = old[i].end + (i + 1 < old.size() ? 1 : 0);
      const auto lo = std::max(a, old[i].start), hi = std::min(b, end);
      if (lo >= hi) continue;
      const auto available = old[i].end + (positions[i] + 1 < old.size() ? 1 : 0);
      const auto kept = std::min(hi, available);
      if (lo < kept) out.emplace_back(starts[i] + lo - old[i].start,
                                      starts[i] + kept - old[i].start);
    }
    return out;
  };
  auto interval = [&](std::size_t a, std::size_t b) {
    const auto parts = pieces(a, b);
    std::size_t count = 0;
    for (std::size_t i = 0; i < parts.size(); ++i) {
      count += parts[i].second - parts[i].first;
      if (i && parts[i - 1].second != parts[i].first)
        throw std::runtime_error("Este movimento partiria ou inverteria um trecho marcado. "
          "Mova um conjunto que conserve o trecho inteiro; nenhum vínculo foi alterado.");
    }
    if (parts.empty() || count != b - a)
      throw std::runtime_error("Este movimento retiraria o separador de um trecho marcado. "
                               "Nenhum vínculo foi alterado.");
    return std::pair{parts.front().first, parts.back().second};
  };
  d.formatting.clear();
  for (const auto &f : before.document.formatting)
    for (const auto &[a, b] : pieces(f.start_offset, f.end_offset))
      if (a < b) d.formatting.push_back({f.style, a, b, f.value});
  for (auto &a : d.anchors) {
    const auto [start, end] = interval(a.start_offset, a.end_offset);
    a.start_offset = start; a.end_offset = end;
  }
  for (auto &r : d.resmas) {
    const auto [start, end] = interval(r.start, r.end);
    r.start = start; r.end = end;
  }
  // Covered leaf pointers and all IDs remain exactly the same objects/values.
  SemanticAnchorEngine::relocate(before.document, d);
  after.selection = {starts[source->first], starts[source->last] + old[source->last].end - old[source->last].start};
  project::validate(d);
  return after;
}
DocumentEditState move_reading_relative(const DocumentEditState &before,
    const std::string &id, const std::string &reference, bool after) {
  const auto blocks = reading_blocks(before.document);
  const auto target = std::find_if(blocks.begin(), blocks.end(),
      [&](const auto &b) { return b.id == reference; });
  if (target == blocks.end()) throw std::runtime_error("Referência de leitura não está mais neste Documento");
  if (id == reference) return before;
  const auto next = target + 1;
  return move_reading_block(before, id, !after ? reference
      : next == blocks.end() ? std::string{} : next->id);
}
} // namespace inde::application
