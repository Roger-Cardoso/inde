#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include "inde/persistence/sqlite_writing_repository.hpp"
#include <algorithm>
#include <deque>
#include <glib.h>
#include <map>
#include <set>
#include <unordered_map>
namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
namespace {
std::unordered_map<std::string, bool> active(const ContextualSnapshot &s,
                                             const std::string &slot = "",
                                             const std::string &option = "") {
  std::unordered_map<std::string, std::string> choices, option_slots;
  for (const auto &x : s.slots)
    choices[x.id] = x.selected_option;
  for (const auto &x : s.options)
    option_slots[x.id] = x.slot_id;
  if (!slot.empty()) {
    if (!choices.contains(slot) ||
        (!option.empty() &&
         (!option_slots.contains(option) || option_slots.at(option) != slot)))
      throw std::runtime_error("Opção de comparação não pertence ao encaixe");
    choices[slot] = option;
  } else if (!option.empty())
    throw std::runtime_error("Comparação precisa de encaixe explícito");
  std::unordered_map<std::string, bool> result;
  for (const auto &x : s.participations)
    result[x.id] = true;
  for (const auto &x : s.memberships) {
    if (!result.contains(x.participation_id) ||
        !option_slots.contains(x.option_id) ||
        !choices.contains(option_slots.at(x.option_id)))
      throw std::runtime_error("Participação/encaixe inválido");
    result[x.participation_id] =
        choices.at(option_slots.at(x.option_id)) == x.option_id;
  }
  return result;
}
const ContextualTextLink &link(const ContextualSnapshot &s,
                               const std::string &id) {
  const auto it = std::find_if(s.text_links.begin(), s.text_links.end(),
                               [&](auto &x) { return x.id == id; });
  if (it == s.text_links.end())
    throw std::runtime_error("Vínculo textual ausente desta composição");
  return *it;
}
ContextualTextObservation
document(SqliteDatabase &db, const project::Project &p, const std::string &id) {
  guard(db, p);
  auto q = db.prepare("SELECT title,content,length(CAST(content AS BLOB)) FROM "
                      "documents WHERE id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error("Documento ausente neste Projeto");
  if (q.column_integer(2) > 32 * 1024 * 1024)
    throw std::runtime_error(
        "Observação textual excede 32 MiB; nenhum veredito foi produzido");
  return {p.manifest().project_id, id, q.column_text(0),
          hash(q.column_text(1))};
}
} // namespace
bool ContextualPlanningService::included(const ContextualSnapshot &s,
                                         const std::string &id) const {
  participation(s, id);
  return active(s).at(id);
}
std::vector<std::string> ContextualPlanningService::included_participations(
    const ContextualSnapshot &s) const {
  const auto values = active(s);
  std::vector<std::string> result;
  for (const auto &x : s.participations)
    if (values.at(x.id))
      result.push_back(x.id);
  return result;
}
ContextualView ContextualPlanningService::context(
    const ContextualSnapshot &s, const std::string &id, const std::string &slot,
    const std::string &option) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  const auto actual = check(db, p, s);
  participation(actual, id);
  const auto state = active(actual, slot, option);
  ContextualView out;
  out.included = state.at(id);
  if (!out.included) {
    out.notices.push_back(
        "Participação fora da opção escolhida ou encaixe ainda não resolvido; "
        "suas declarações não foram aplicadas.");
    tx.commit();
    return out;
  }
  struct Edge {
    std::string source_plan, source, target, kind, note;
  };
  std::map<std::string, ContextualSnapshot> plans;
  std::map<std::string, std::unordered_map<std::string, bool>> states;
  std::map<std::string, std::string> titles, node_plan;
  std::map<std::string, std::vector<Edge>> incoming;
  std::map<std::string, std::vector<ContextualDeclaration>> declarations;
  std::size_t nodes{}, bytes{};
  auto install = [&](ContextualSnapshot value, bool initial) {
    nodes += value.participations.size();
    for (const auto &x : value.participations)
      bytes += x.title.size() + x.description.size() + x.note.size() + 512;
    for (const auto &x : value.declarations)
      bytes += x.label.size() + x.value.size() + 512;
    for (const auto &x : value.references)
      bytes += x.note.size() + 900;
    for (const auto &x : value.dependencies)
      bytes += x.note.size() + 900;
    for (const auto &x : value.bridges)
      bytes += x.note.size() + 900;
    for (const auto &x : value.text_links)
      bytes += x.note.size() + x.title.size() + 900;
    if (plans.size() >= 32 || nodes > 16000 || bytes > 32 * 1024 * 1024)
      throw std::runtime_error(
          "Consulta entre composições excede 32 composições, 16.000 "
          "participações ou orçamento de 32 MiB; nada foi truncado");
    const auto plan = value.plan_id;
    states[plan] = initial ? state : active(value);
    for (const auto &x : value.participations) {
      auto label = x.title.empty() ? x.description : x.title;
      titles[x.id] = label.substr(
          0, g_utf8_offset_to_pointer(
                 label.c_str(),
                 std::min<glong>(100,
                                 g_utf8_strlen(label.c_str(), label.size()))) -
                 label.c_str());
      node_plan[x.id] = plan;
    }
    for (const auto &x : value.declarations)
      declarations[x.participation_id].push_back(x);
    for (const auto &x : value.dependencies)
      incoming[x.target].push_back({plan, x.source, x.target, x.kind, x.note});
    for (const auto &x : value.bridges)
      incoming[x.target].push_back(
          {x.source_plan, x.source, x.target, x.kind, x.note});
    plans.emplace(plan, std::move(value));
  };
  install(actual, true);
  std::set<std::string> visited{id};
  std::deque<std::string> queue{id};
  while (!queue.empty()) {
    const auto target = queue.front();
    queue.pop_front();
    const auto &origin_plan = plans.at(node_plan.at(target));
    for (const auto &d : declarations[target])
      out.declarations.push_back({d, titles.at(target), target == id,
                                  origin_plan.plan_id, origin_plan.title});
    // Copy this small incoming list: installing a lazily requested plan can
    // append other lists, including a cycle back to this target.
    const auto edges = incoming[target];
    for (const auto &edge : edges) {
      if (!plans.contains(edge.source_plan)) {
        auto source = read(db, p, edge.source_plan);
        if (source.work_id != actual.work_id)
          throw std::runtime_error(
              "Contexto de outra Obra não pode ser herdado");
        install(std::move(source), false);
      }
      const bool available = states.at(edge.source_plan).at(edge.source);
      if (!available || edge.kind != "context")
        out.notices.push_back(
            contextual_kind_label(edge.kind) + " · origem " +
            plans.at(edge.source_plan).title + " / " + titles.at(edge.source) +
            " [" + edge.source + "]" +
            (available ? " disponível" : " fora da escolha atual") +
            (edge.note.empty() ? "" : " · " + edge.note));
      if (edge.kind == "context" && available &&
          visited.insert(edge.source).second)
        queue.push_back(edge.source);
    }
  }
  // Detect cycles in the actually consulted context subgraph. Never choose a
  // winner or recurse forever, and never evaluate all combinations.
  std::map<std::string, std::size_t> degree;
  std::unordered_map<std::string, std::vector<std::string>> successors;
  for (const auto &node : visited)
    degree[node] = 0;
  for (const auto &[target, edges] : incoming)
    for (const auto &e : edges)
      if (e.kind == "context" && visited.contains(e.source) &&
          visited.contains(target)) {
        ++degree[target];
        successors[e.source].push_back(target);
      }
  std::deque<std::string> ready;
  for (const auto &[node, n] : degree)
    if (!n)
      ready.push_back(node);
  std::size_t sorted{};
  while (!ready.empty()) {
    auto node = ready.front();
    ready.pop_front();
    ++sorted;
    for (const auto &next : successors[node])
      if (--degree[next] == 0)
        ready.push_back(next);
  }
  if (sorted != visited.size())
    out.notices.push_back(
        "Ciclo nos vínculos de contexto consultados: origens preservadas uma "
        "vez; não há precedência ou vencedor automático.");
  std::map<std::pair<std::string, std::string>, std::set<std::string>> values;
  for (const auto &x : out.declarations)
    values[{x.declaration.kind, x.declaration.label}].insert(
        x.declaration.value);
  for (const auto &[key, set] : values)
    if (set.size() > 1)
      out.notices.push_back(
          "Valores diferentes para " + contextual_kind_label(key.first) +
          " · " + key.second +
          ": ambas as origens foram conservadas; não há resolução automática.");
  tx.commit();
  return out;
}
ContextualTextObservation
ContextualPlanningService::text_document(const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  auto out = document(db, p, id);
  tx.commit();
  return out;
}
void ContextualPlanningService::validate_text_destination(
    const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  guard(db, p);
  auto q = db.prepare("SELECT id FROM documents WHERE id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error(
        "Documento não encontrado neste Projeto; origem preservada");
  tx.commit();
}
std::string
ContextualPlanningService::text_target(const ContextualSnapshot &s,
                                       const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  const auto actual = check(db, p, s);
  const auto result = link(actual, id).document_id;
  if (!link(actual, id).anchor_id.empty() ||
      !link(actual, id).composition_id.empty())
    throw std::runtime_error("Este vínculo exige navegação para "
                             "trecho/ocorrência, não Documento inteiro");
  tx.commit();
  return result;
}
std::string ContextualPlanningService::create_text(const ContextualSnapshot &s,
                                                   const std::string &part,
                                                   const std::string &title) {
  text(title, 200);
  if (blank(title))
    throw std::runtime_error("Informe um título para o Documento");
  const auto &p = current(service_);
  project::Document value;
  value.id = project::new_uuid();
  value.title = title;
  value.created_at = value.updated_at = project::utc_now();
  project::validate(value);
  SqliteWritingRepository{}.save_with_context(
      p.path(), value, nullptr, p.manifest().project_id,
      "Criar Documento vazio e associar ao contexto atomicamente",
      [&](SqliteDatabase &db) {
        const auto actual = check(db, p, s);
        participation(actual, part);
        auto q = db.prepare(
            "INSERT INTO "
            "contextual_text_links(id,project_id,work_id,plan_id,participation_"
            "id,document_id,observed_sha) VALUES(?,?,?,?,?,?,?)");
        q.bind(1, project::new_uuid());
        q.bind(2, actual.project_id);
        q.bind(3, actual.work_id);
        q.bind(4, actual.plan_id);
        q.bind(5, part);
        q.bind(6, value.id);
        q.bind(7, hash(""));
        q.run();
        budget(db, actual.plan_id);
      });
  return value.id;
}
std::string ContextualPlanningService::associate_text(
    const ContextualSnapshot &s, const std::string &part,
    const ContextualTextObservation &observed) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Associar texto ao contexto (sem certificar realização)");
  const auto actual = check(db, p, s);
  participation(actual, part);
  const auto doc = document(db, p, observed.document_id);
  if (std::any_of(actual.text_links.begin(), actual.text_links.end(),
                  [&](auto &x) {
                    return x.participation_id == part &&
                           x.document_id == doc.document_id;
                  }))
    throw std::runtime_error("Este texto já está associado à participação; "
                             "abra o vínculo existente");
  if (observed.project_id != doc.project_id || observed.sha != doc.sha ||
      observed.title != doc.title)
    throw std::runtime_error("Documento mudou desde a consulta; associe "
                             "novamente. Nada foi alterado");
  const auto id = project::new_uuid();
  auto q = db.prepare(
      "INSERT INTO "
      "contextual_text_links(id,project_id,work_id,plan_id,participation_id,"
      "document_id,observed_sha) VALUES(?,?,?,?,?,?,?)");
  q.bind(1, id);
  q.bind(2, actual.project_id);
  q.bind(3, actual.work_id);
  q.bind(4, actual.plan_id);
  q.bind(5, part);
  q.bind(6, doc.document_id);
  q.bind(7, doc.sha);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
  return id;
}
ContextualTextReview
ContextualPlanningService::observe_text(const ContextualSnapshot &s,
                                        const std::string &id) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  const auto actual = check(db, p, s);
  const auto target = link(actual, id);
  const auto r = resolve_text(db, p, target, true);
  const ContextualTextObservation doc{p.manifest().project_id, r.document_id,
                                      r.title, r.current_sha};
  tx.commit();
  return {target, doc, target.observed_sha != doc.sha};
}
void ContextualPlanningService::review_text(
    const ContextualSnapshot &s, const ContextualTextReview &observed,
    const std::string &note) {
  text(note, 2048);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Registrar conferência humana opcional do texto "
                           "(não certifica fidelidade)");
  const auto actual = check(db, p, s);
  const auto target = link(actual, observed.link.id);
  const auto r = resolve_text(db, p, target, true);
  const ContextualTextObservation doc{p.manifest().project_id, r.document_id,
                                      r.title, r.current_sha};
  if (observed.current.project_id != doc.project_id ||
      observed.current.document_id != doc.document_id ||
      observed.current.sha != doc.sha)
    throw std::runtime_error("Texto mudou desde a observação; consulte "
                             "novamente. Nada foi alterado");
  auto q =
      db.prepare("UPDATE " + r.table + " SET observed_sha=?,note=? WHERE id=?");
  q.bind(1, doc.sha);
  q.bind(2, note);
  q.bind(3, target.id);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
}
void ContextualPlanningService::remove_text_link(const ContextualSnapshot &s,
                                                 const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Desvincular texto sem apagar Documento ou participação");
  const auto actual = check(db, p, s);
  const auto &x = link(actual, id);
  const auto table = x.anchor_id.empty() && x.composition_id.empty()
                         ? "contextual_text_links"
                         : "contextual_text_targets";
  auto q = db.prepare(std::string("DELETE FROM ") + table + " WHERE id=?");
  q.bind(1, id);
  q.run();
  tx.commit();
}
} // namespace inde::application
