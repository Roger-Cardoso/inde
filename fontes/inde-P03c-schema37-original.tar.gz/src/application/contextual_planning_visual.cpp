#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <set>
#include <stdexcept>
#include <unordered_set>

namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
namespace {
void validate(const ContextualVisualItem &v) {
  text(v.id, 128);
  text(v.label, 200);
  if (v.id.empty() ||
      (v.kind != "block" && v.kind != "lane" && v.kind != "marker") ||
      ((v.kind == "block") != !v.participation_id.empty()) ||
      (v.kind != "block" && v.expanded) ||
      (v.shape != "box" && v.shape != "straight" && v.shape != "ecg" &&
       v.shape != "wavy") ||
      v.x < -100000 || v.x > 100000 || v.y < -100000 || v.y > 100000 ||
      v.width < 80 || v.width > 20000 || v.height < 64 || v.height > 4000 ||
      v.color.size() != 7 || v.color[0] != '#' ||
      v.color.find_first_not_of("0123456789abcdefABCDEF", 1) !=
          std::string::npos ||
      std::any_of(v.curve.begin(), v.curve.end(),
                  [](auto n) { return n < 0 || n > 1000; }))
    throw std::runtime_error("Geometria visual inválida; nada foi alterado");
}
void write(SqliteDatabase &db, const ContextualSnapshot &s,
           const ContextualVisualItem &v) {
  auto q = db.prepare(
      "INSERT INTO contextual_visual_items(id,project_id,work_id,plan_id,"
      "participation_id,kind,label,color,shape,x,y,width,height,c0,c1,c2,c3,c4,"
      "expanded) "
      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE "
      "SET "
      "label=excluded.label,color=excluded.color,shape=excluded.shape,x="
      "excluded.x,"
      "y=excluded.y,width=excluded.width,height=excluded.height,c0=excluded.c0,"
      "c1=excluded.c1,c2=excluded.c2,c3=excluded.c3,c4=excluded.c4,expanded="
      "excluded.expanded");
  q.bind(1, v.id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, s.plan_id);
  if (v.participation_id.empty())
    q.bind_null(5);
  else
    q.bind(5, v.participation_id);
  q.bind(6, v.kind);
  q.bind(7, v.label);
  q.bind(8, v.color);
  q.bind(9, v.shape);
  q.bind(10, v.x);
  q.bind(11, v.y);
  q.bind(12, v.width);
  q.bind(13, v.height);
  for (int i = 0; i < 5; ++i)
    q.bind(14 + i, v.curve[i]);
  q.bind(19, v.expanded ? 1 : 0);
  q.run();
}
} // namespace
std::vector<ContextualVisualItem>
contextual_visual_layout(const ContextualSnapshot &s) {
  auto out = s.visual;
  std::unordered_set<std::string> placed;
  for (const auto &v : out)
    placed.insert(v.participation_id);
  for (std::size_t i = 0; i < s.participations.size(); ++i) {
    const auto &p = s.participations[i];
    if (placed.contains(p.id))
      continue;
    ContextualVisualItem v;
    v.id = v.participation_id = p.id;
    v.x = 40 + static_cast<std::int64_t>(i % 6) * 300;
    v.y = 60 + static_cast<std::int64_t>(i / 6) * 170;
    out.push_back(v);
  }
  return out;
}
std::vector<std::string> contextual_selection_order(
    const ContextualSnapshot &s, const std::vector<std::string> &parts,
    const std::string &order) {
  if (parts.size() < 2 || parts.size() > 2000 ||
      (order != "local" && order != "horizontal" && order != "vertical"))
    throw std::runtime_error("Seleção ou ordem de revisão inválida");
  const std::set<std::string> chosen(parts.begin(), parts.end());
  if (chosen.size() != parts.size())
    throw std::runtime_error("Seleção repetida");
  std::vector<std::string> out;
  for (const auto &p : s.participations)
    if (chosen.contains(p.id))
      out.push_back(p.id);
  if (out.size() != chosen.size())
    throw std::runtime_error("Trecho ausente desta composição");
  if (order == "local")
    return out;
  const auto layout = contextual_visual_layout(s);
  std::map<std::string, std::pair<std::int64_t, std::int64_t>> positions;
  for (const auto &v : layout)
    if (chosen.contains(v.participation_id))
      positions.emplace(v.participation_id,
                        order == "horizontal" ? std::pair{v.x, v.y}
                                              : std::pair{v.y, v.x});
  std::stable_sort(out.begin(), out.end(), [&](const auto &a, const auto &b) {
    return positions.at(a) < positions.at(b);
  });
  return out;
}
std::vector<ContextualVisualItem> contextual_arrange_selection(
    const ContextualSnapshot &s, const std::vector<std::string> &parts,
    const std::string &arrangement) {
  const bool horizontal = arrangement == "distribute_x" || arrangement == "pack_x";
  const bool distribute = arrangement == "distribute_x" || arrangement == "distribute_y";
  const bool pack = arrangement == "pack_x" || arrangement == "pack_y";
  if (!distribute && !pack && arrangement != "left" && arrangement != "right" &&
      arrangement != "top" && arrangement != "bottom")
    throw std::runtime_error("Organização visual desconhecida");
  const auto ordered = contextual_selection_order(
      s, parts, distribute || pack ? (horizontal ? "horizontal" : "vertical") : "local");
  if (distribute && parts.size() < 3)
    throw std::runtime_error("Distribuir exige ao menos três trechos");
  auto out = contextual_visual_layout(s);
  std::map<std::string, std::size_t> indices;
  for (std::size_t i = 0; i < out.size(); ++i)
    indices.emplace(out[i].participation_id, i);
  std::int64_t left = 100000, top = 100000, right = -100000, bottom = -100000;
  for (const auto &id : ordered) {
    const auto &v = out.at(indices.at(id));
    left = std::min(left, v.x);
    top = std::min(top, v.y);
    right = std::max(right, v.x + v.width);
    bottom = std::max(bottom, v.y + v.height);
  }
  std::int64_t cursor{};
  std::int64_t space = 40 * static_cast<std::int64_t>(ordered.size() - 1);
  if (distribute || pack) {
    const auto &first = out.at(indices.at(ordered.front()));
    const auto &last = out.at(indices.at(ordered.back()));
    cursor = horizontal ? first.x : first.y;
    if (distribute) {
      space = (horizontal ? last.x + last.width : last.y + last.height) - cursor;
      for (const auto &id : ordered) {
        const auto &v = out.at(indices.at(id));
        space -= horizontal ? v.width : v.height;
      }
      if (space < 0)
        throw std::runtime_error("Não cabe sem sobrepor: afaste os extremos ou use uma fila com intervalo");
    }
  }
  for (std::size_t i = 0; i < ordered.size(); ++i) {
    auto &v = out.at(indices.at(ordered[i]));
    if (distribute || pack) {
      const auto coordinate = cursor + space * static_cast<std::int64_t>(i) /
                                           static_cast<std::int64_t>(ordered.size() - 1);
      if (horizontal)
        v.x = coordinate;
      else
        v.y = coordinate;
      cursor += horizontal ? v.width : v.height;
    } else if (arrangement == "left")
      v.x = left;
    else if (arrangement == "right")
      v.x = right - v.width;
    else if (arrangement == "top")
      v.y = top;
    else
      v.y = bottom - v.height;
    validate(v); // Reject the whole proposal at a boundary, never clamp pieces.
  }
  return out;
}
namespace contextual_detail {
void insert_visual(SqliteDatabase &db, const ContextualSnapshot &s,
                   const ContextualVisualItem &v) {
  validate(v);
  auto count = db.prepare(
      "SELECT count(*) FROM contextual_visual_items WHERE plan_id=?");
  count.bind(1, s.plan_id);
  count.step();
  if (count.column_integer(0) >= 2400)
    throw std::runtime_error("Limite de 2.400 elementos visuais");
  if (v.expanded) {
    auto n = db.prepare("SELECT count(*) FROM contextual_visual_items WHERE "
                        "plan_id=? AND expanded=1");
    n.bind(1, s.plan_id);
    n.step();
    if (n.column_integer(0) >= 8)
      throw std::runtime_error(
          "Limite de oito interiores expandidos nesta superfície");
  }
  write(db, s, v);
}
void append_visual_snapshot(SqliteDatabase &db, ContextualSnapshot &s,
                            std::string &proof) {
  auto q = db.prepare(
      "SELECT id,coalesce(participation_id,''),kind,label,color,shape,"
      "x,y,width,height,c0,c1,c2,c3,c4,expanded FROM contextual_visual_items "
      "WHERE plan_id=? ORDER BY id");
  q.bind(1, s.plan_id);
  std::size_t expanded{};
  while (q.step()) {
    if (s.visual.size() >= 2400)
      throw std::runtime_error(
          "Mais de 2.400 elementos visuais; consulta não truncada");
    ContextualVisualItem v;
    v.id = q.column_text(0);
    v.participation_id = q.column_text(1);
    v.kind = q.column_text(2);
    v.label = q.column_text(3);
    v.color = q.column_text(4);
    v.shape = q.column_text(5);
    v.x = q.column_integer(6);
    v.y = q.column_integer(7);
    v.width = q.column_integer(8);
    v.height = q.column_integer(9);
    for (int i = 0; i < 5; ++i)
      v.curve[i] = q.column_integer(10 + i);
    v.expanded = q.column_integer(15) != 0;
    if (v.expanded && ++expanded > 8)
      throw std::runtime_error("Superfície excede oito interiores expandidos; "
                               "consulta não truncada");
    validate(v);
    if (!v.participation_id.empty())
      participation(s, v.participation_id);
    for (int i = 0; i < 16; ++i)
      evidence(proof,
               i < 6 ? q.column_text(i) : std::to_string(q.column_integer(i)));
    s.visual.push_back(std::move(v));
  }
}
void group_visual(SqliteDatabase &db, const ContextualSnapshot &s,
                  const std::vector<std::string> &parts,
                  const std::string &group) {
  const std::set<std::string> chosen(parts.begin(), parts.end());
  auto all = contextual_visual_layout(s);
  ContextualVisualItem box;
  box.id = box.participation_id = group;
  box.x = box.y = 100000;
  std::int64_t right = -100000, bottom = -100000;
  for (const auto &v : all)
    if (chosen.contains(v.participation_id)) {
      box.x = std::min(box.x, v.x);
      box.y = std::min(box.y, v.y);
      right = std::max(right, v.x + v.width);
      bottom = std::max(bottom, v.y + v.height);
    }
  box.width = std::clamp(right - box.x, std::int64_t{80}, std::int64_t{20000});
  box.height = std::clamp(bottom - box.y, std::int64_t{64}, std::int64_t{4000});
  validate(box);
  insert_visual(db, s, box);
}
} // namespace contextual_detail
ContextualSnapshot ContextualPlanningService::save_visual(
    const ContextualSnapshot &expected,
    const std::vector<ContextualVisualItem> &items) {
  if (items.size() > 2400)
    throw std::runtime_error(
        "Limite de 2.400 elementos visuais por composição");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Compor visualmente: disposição local sem inferências narrativas");
  const auto s = check(db, p, expected);
  std::set<std::string> ids, parts;
  if (std::count_if(items.begin(), items.end(),
                    [](const auto &v) { return v.expanded; }) > 8)
    throw std::runtime_error(
        "Recolha um interior antes de expandir outro: limite de oito prévias "
        "locais, sem expansão recursiva");
  for (const auto &v : items) {
    validate(v);
    if (!ids.insert(v.id).second)
      throw std::runtime_error("Elemento visual repetido");
    if (!v.participation_id.empty()) {
      participation(s, v.participation_id);
      if (!parts.insert(v.participation_id).second)
        throw std::runtime_error("Participação visual repetida");
    }
    auto owner = db.prepare("SELECT plan_id,coalesce(participation_id,''),kind "
                            "FROM contextual_visual_items WHERE id=?");
    owner.bind(1, v.id);
    if (owner.step() && (owner.column_text(0) != s.plan_id ||
                         owner.column_text(1) != v.participation_id ||
                         owner.column_text(2) != v.kind))
      throw std::runtime_error(
          "Identidade visual pertence a outro uso; nada foi alterado");
  }
  for (const auto &old : s.visual)
    if (!ids.contains(old.id)) {
      auto q = db.prepare("DELETE FROM contextual_visual_items WHERE id=?");
      q.bind(1, old.id);
      q.run();
    }
  for (const auto &v : items) {
    const auto old = std::find_if(s.visual.begin(), s.visual.end(),
                                  [&](const auto &x) { return x.id == v.id; });
    if (old == s.visual.end() || *old != v)
      write(db, s, v);
  }
  budget(db, s.plan_id);
  const auto result =
      read(db, p, s.plan_id); // Exact aggregate captured before commit.
  tx.commit();
  return result;
}
} // namespace inde::application
