#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <set>
#include <stdexcept>
namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
std::string contextual_kind_label(const std::string &v) {
  for (const auto &[id, name] :
       std::initializer_list<std::pair<const char *, const char *>>{
           {"fact", "Fato declarado"},
           {"intention", "Intenção"},
           {"knowledge", "Conhecimento"},
           {"belief", "Crença"},
           {"report", "Relato"},
           {"succession", "Sucessão"},
           {"cause", "Causa"},
           {"motivation", "Motivação"},
           {"condition", "Condição"},
           {"context", "Contexto recebido"}})
    if (v == id)
      return name;
  return v;
}
namespace {
template <class T, class F> const T &find(const std::vector<T> &rows, F f) {
  const auto it = std::find_if(rows.begin(), rows.end(), f);
  if (it == rows.end())
    throw std::runtime_error("Origem contextual ausente desta composição");
  return *it;
}
void name(const std::string &v) {
  text(v, 200);
  if (blank(v))
    throw std::runtime_error("Informe um nome curto");
}
bool kind(const std::string &v, std::initializer_list<const char *> values) {
  return std::any_of(values.begin(), values.end(),
                     [&](const auto *x) { return v == x; });
}
void owner(SqliteStatement &q, const ContextualSnapshot &s,
           const std::string &id) {
  q.bind(1, id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, s.plan_id);
}
void erase(SqliteDatabase &db, const std::string &table,
           const std::string &id) {
  auto q = db.prepare("DELETE FROM " + table + " WHERE id=?");
  q.bind(1, id);
  q.run();
}
} // namespace
namespace contextual_detail {
void append_extended_snapshot(SqliteDatabase &db, ContextualSnapshot &s,
                              std::string &proof) {
  auto capture = [&](const std::string &sql, int columns, auto append) {
    auto q = db.prepare(sql);
    q.bind(1, s.plan_id);
    std::size_t count{};
    while (q.step()) {
      if (++count > 4000)
        throw std::runtime_error(
            "Coleção contextual excede 4.000 registros; nada foi truncado");
      std::vector<std::string> row;
      for (int c = 0; c < columns; ++c) {
        row.push_back(q.column_is_null(c) ? "" : q.column_text(c));
        text(row.back(), 4096);
        evidence(proof, row.back());
      }
      append(row);
    }
  };
  evidence(proof, "slots");
  capture("SELECT id,title,selected_option_id FROM contextual_slots WHERE "
          "plan_id=? ORDER BY id",
          3, [&](auto &r) { s.slots.push_back({r[0], r[1], r[2]}); });
  evidence(proof, "options");
  capture("SELECT id,slot_id,title FROM contextual_options WHERE plan_id=? "
          "ORDER BY id",
          3, [&](auto &r) { s.options.push_back({r[0], r[1], r[2]}); });
  evidence(proof, "members");
  capture("SELECT participation_id,option_id FROM contextual_option_members "
          "WHERE plan_id=? ORDER BY participation_id",
          2, [&](auto &r) { s.memberships.push_back({r[0], r[1]}); });
  evidence(proof, "declarations");
  capture("SELECT id,participation_id,kind,label,value FROM "
          "contextual_declarations WHERE plan_id=? ORDER BY id",
          5, [&](auto &r) {
            s.declarations.push_back({r[0], r[1], r[2], r[3], r[4]});
          });
  evidence(proof, "dependencies");
  capture("SELECT id,source_id,target_id,kind,note FROM "
          "contextual_dependencies WHERE plan_id=? ORDER BY id",
          5, [&](auto &r) {
            s.dependencies.push_back({r[0], r[1], r[2], r[3], r[4]});
          });
  evidence(proof, "text_links");
  capture("SELECT "
          "x.id,x.participation_id,x.document_id,d.title,x.observed_sha,x.note "
          "FROM contextual_text_links x JOIN documents d ON d.id=x.document_id "
          "WHERE x.plan_id=? ORDER BY x.id",
          6, [&](auto &r) {
            s.text_links.push_back({r[0], r[1], r[2], r[3], r[4], r[5]});
          });
  evidence(proof, "text_targets");
  capture("SELECT "
          "x.id,x.participation_id,coalesce(x.document_id,''),coalesce(d.title,"
          "c.name),x.observed_sha,x.note,coalesce(x.anchor_id,''),coalesce(x."
          "composition_id,''),coalesce(x.occurrence_id,'') "
          "FROM contextual_text_targets x LEFT JOIN documents d ON "
          "d.id=x.document_id LEFT JOIN compositions c ON "
          "c.id=x.composition_id WHERE x.plan_id=? ORDER BY x.id",
          9, [&](auto &r) {
            s.text_links.push_back(
                {r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]});
          });
  if (s.text_links.size() > 4000)
    throw std::runtime_error("Mais de 4.000 vínculos textuais; nada truncado");
  evidence(proof, "references");
  capture(
      "SELECT id,participation_id,CASE WHEN entity_id IS NOT NULL THEN "
      "'entity' WHEN relation_id IS NOT NULL THEN 'relation' WHEN unit_id IS "
      "NOT NULL THEN 'unit' WHEN line_id IS NOT NULL THEN 'line' WHEN "
      "reference_id IS NOT NULL THEN 'time' WHEN point_id IS NOT NULL THEN "
      "'point' ELSE 'map' "
      "END,coalesce(entity_id,relation_id,unit_id,line_id,reference_id,point_"
      "id,map_id),note FROM contextual_references WHERE plan_id=? ORDER BY id",
      5,
      [&](auto &r) { s.references.push_back({r[0], r[1], r[2], r[3], r[4]}); });
  evidence(proof, "bridges");
  capture("SELECT id,source_plan_id,source_id,target_id,kind,note FROM "
          "contextual_bridges WHERE plan_id=? ORDER BY id",
          6, [&](auto &r) {
            s.bridges.push_back({r[0], r[1], r[2], r[3], r[4], r[5]});
          });
}
std::int64_t extended_budget(SqliteDatabase &db, const std::string &plan) {
  std::int64_t bytes{};
  auto links = db.prepare("SELECT (SELECT count(*) FROM contextual_text_links "
                          "WHERE plan_id=?1)+(SELECT count(*) FROM "
                          "contextual_text_targets WHERE plan_id=?1)");
  links.bind(1, plan);
  links.step();
  if (links.column_integer(0) > 4000)
    throw std::runtime_error(
        "Mais de 4.000 vínculos textuais; nenhuma alteração confirmada");
  for (const auto &[table, expression] :
       std::initializer_list<std::pair<const char *, const char *>>{
           {"contextual_slots", "length(CAST(title AS BLOB))+300"},
           {"contextual_options", "length(CAST(title AS BLOB))+300"},
           {"contextual_option_members", "300"},
           {"contextual_declarations",
            "length(CAST(label AS BLOB))+length(CAST(value AS BLOB))+400"},
           {"contextual_dependencies", "length(CAST(note AS BLOB))+400"},
           {"contextual_references", "length(CAST(note AS BLOB))+500"},
           {"contextual_bridges", "length(CAST(note AS BLOB))+500"},
           {"contextual_text_targets", "length(CAST(note AS BLOB))+1000"},
           {"contextual_text_links x JOIN documents d ON d.id=x.document_id",
            "length(CAST(x.note AS BLOB))+length(CAST(d.title AS "
            "BLOB))+500"}}) {
    auto q = db.prepare(
        "SELECT count(*),coalesce(sum(" + std::string(expression) +
        "),0) FROM " + table + " WHERE " +
        (std::string(table).starts_with("contextual_text_links") ? "x." : "") +
        "plan_id=?");
    q.bind(1, plan);
    q.step();
    if (q.column_integer(0) > 4000)
      throw std::runtime_error(
          "Coleção contextual excederia 4.000 registros; nada foi confirmado");
    bytes += q.column_integer(1);
  }
  return bytes;
}
} // namespace contextual_detail
std::string ContextualPlanningService::create_slot(const ContextualSnapshot &s,
                                                   const std::string &title) {
  name(title);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Criar encaixe contextual sem escolher opção");
  const auto actual = check(db, p, s);
  const auto id = project::new_uuid();
  auto q = db.prepare(
      "INSERT INTO contextual_slots(id,project_id,work_id,plan_id,title) "
      "VALUES(?,?,?,?,?)");
  owner(q, actual, id);
  q.bind(5, title);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
  return id;
}
std::string
ContextualPlanningService::create_option(const ContextualSnapshot &s,
                                         const std::string &slot,
                                         const std::string &title) {
  name(title);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Acrescentar opção ao encaixe, sem escolhê-la");
  const auto actual = check(db, p, s);
  find(actual.slots, [&](auto &x) { return x.id == slot; });
  const auto id = project::new_uuid();
  auto q = db.prepare("INSERT INTO "
                      "contextual_options(id,project_id,work_id,plan_id,slot_"
                      "id,title) VALUES(?,?,?,?,?,?)");
  owner(q, actual, id);
  q.bind(5, slot);
  q.bind(6, title);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
  return id;
}
void ContextualPlanningService::choose_option(const ContextualSnapshot &s,
                                              const std::string &slot,
                                              const std::string &option) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Escolher opção contextual (sem alterar texto ou cronologia)");
  const auto actual = check(db, p, s);
  find(actual.slots, [&](auto &x) { return x.id == slot; });
  if (!option.empty())
    find(actual.options,
         [&](auto &x) { return x.id == option && x.slot_id == slot; });
  auto q =
      db.prepare("UPDATE contextual_slots SET selected_option_id=? WHERE id=?");
  if (option.empty())
    q.bind_null(1);
  else
    q.bind(1, option);
  q.bind(2, slot);
  q.run();
  tx.commit();
}
void ContextualPlanningService::assign_option(const ContextualSnapshot &s,
                                              const std::string &id,
                                              const std::string &option) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, option.empty()
              ? "Tornar participação comum às opções"
              : "Incluir participação na opção (participação conjunta)");
  const auto actual = check(db, p, s);
  participation(actual, id);
  if (option.empty()) {
    auto q = db.prepare(
        "DELETE FROM contextual_option_members WHERE participation_id=?");
    q.bind(1, id);
    q.run();
  } else {
    find(actual.options, [&](auto &x) { return x.id == option; });
    auto q = db.prepare(
        "INSERT INTO "
        "contextual_option_members(participation_id,project_id,work_id,plan_id,"
        "option_id) VALUES(?,?,?,?,?) ON CONFLICT(participation_id) DO UPDATE "
        "SET option_id=excluded.option_id");
    owner(q, actual, id);
    q.bind(5, option);
    q.run();
  }
  budget(db, actual.plan_id);
  tx.commit();
}
void ContextualPlanningService::remove_option(const ContextualSnapshot &s,
                                              const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Remover opção vazia e não escolhida");
  const auto actual = check(db, p, s);
  find(actual.options, [&](auto &x) { return x.id == id; });
  if (std::any_of(actual.slots.begin(), actual.slots.end(),
                  [&](auto &x) { return x.selected_option == id; }) ||
      std::any_of(actual.memberships.begin(), actual.memberships.end(),
                  [&](auto &x) { return x.option_id == id; }))
    throw std::runtime_error(
        "Retire a escolha e os participantes antes de remover esta opção");
  erase(db, "contextual_options", id);
  tx.commit();
}
void ContextualPlanningService::remove_slot(const ContextualSnapshot &s,
                                            const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Remover encaixe vazio");
  const auto actual = check(db, p, s);
  find(actual.slots, [&](auto &x) { return x.id == id; });
  if (std::any_of(actual.options.begin(), actual.options.end(),
                  [&](auto &x) { return x.slot_id == id; }))
    throw std::runtime_error(
        "Remova explicitamente as opções antes do encaixe");
  erase(db, "contextual_slots", id);
  tx.commit();
}
std::string ContextualPlanningService::declare(const ContextualSnapshot &s,
                                               const std::string &part,
                                               const std::string &type,
                                               const std::string &label,
                                               const std::string &value) {
  name(label);
  text(value, 4096);
  if (!kind(type, {"fact", "intention", "knowledge", "belief", "report"}))
    throw std::runtime_error("Tipo de declaração inválido");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Declarar informação contextual (sem interpretação da prosa)");
  const auto actual = check(db, p, s);
  participation(actual, part);
  const auto id = project::new_uuid();
  auto q =
      db.prepare("INSERT INTO "
                 "contextual_declarations(id,project_id,work_id,plan_id,"
                 "participation_id,kind,label,value) VALUES(?,?,?,?,?,?,?,?)");
  owner(q, actual, id);
  q.bind(5, part);
  q.bind(6, type);
  q.bind(7, label);
  q.bind(8, value);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
  return id;
}
void ContextualPlanningService::update_declaration(
    const ContextualSnapshot &s, const ContextualDeclaration &d) {
  name(d.label);
  text(d.value, 4096);
  if (!kind(d.kind, {"fact", "intention", "knowledge", "belief", "report"}))
    throw std::runtime_error("Tipo de declaração inválido");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Alterar uma declaração na origem contextual");
  const auto actual = check(db, p, s);
  find(actual.declarations, [&](auto &x) {
    return x.id == d.id && x.participation_id == d.participation_id;
  });
  auto q = db.prepare(
      "UPDATE contextual_declarations SET kind=?,label=?,value=? WHERE id=?");
  q.bind(1, d.kind);
  q.bind(2, d.label);
  q.bind(3, d.value);
  q.bind(4, d.id);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
}
void ContextualPlanningService::remove_declaration(const ContextualSnapshot &s,
                                                   const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Retirar declaração contextual (origens não são copiadas)");
  const auto actual = check(db, p, s);
  find(actual.declarations, [&](auto &x) { return x.id == id; });
  erase(db, "contextual_declarations", id);
  tx.commit();
}
std::string ContextualPlanningService::add_dependency(
    const ContextualSnapshot &s, const std::string &source,
    const std::string &target, const std::string &type,
    const std::string &note) {
  text(note, 2048);
  if (!kind(type,
            {"succession", "cause", "motivation", "condition", "context"}))
    throw std::runtime_error("Tipo de dependência inválido");
  if (source == target)
    throw std::runtime_error("Escolha outra participação como origem");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Declarar dependência contextual com origem e tipo explícitos");
  const auto actual = check(db, p, s);
  participation(actual, source);
  participation(actual, target);
  if (std::any_of(
          actual.dependencies.begin(), actual.dependencies.end(), [&](auto &x) {
            return x.source == source && x.target == target && x.kind == type;
          }))
    throw std::runtime_error(
        "Dependência deste tipo já existe entre estas participações");
  const auto id = project::new_uuid();
  auto q = db.prepare("INSERT INTO "
                      "contextual_dependencies(id,project_id,work_id,plan_id,"
                      "source_id,target_id,kind,note) VALUES(?,?,?,?,?,?,?,?)");
  owner(q, actual, id);
  q.bind(5, source);
  q.bind(6, target);
  q.bind(7, type);
  q.bind(8, note);
  q.run();
  budget(db, actual.plan_id);
  tx.commit();
  return id;
}
void ContextualPlanningService::sequence_selection(
    const ContextualSnapshot &expected, const std::vector<std::string> &ids,
    bool reorder, bool declare_succession) {
  if (ids.size() < 2 || ids.size() > 2000 || (!reorder && !declare_succession))
    throw std::runtime_error("Selecione ao menos dois trechos e uma ação explícita");
  const std::set<std::string> chosen(ids.begin(), ids.end());
  if (chosen.size() != ids.size())
    throw std::runtime_error("A seleção contém trechos repetidos");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Revisar sequência selecionada: ordem local e sucessão explícitas");
  const auto actual = check(db, p, expected);
  std::map<std::string, std::int64_t> old_positions;
  for (const auto &part : actual.participations)
    old_positions.emplace(part.id, part.position);
  for (const auto &id : ids)
    if (!old_positions.contains(id))
      throw std::runtime_error("Trecho ausente desta composição");
  if (reorder) {
    std::vector<std::int64_t> positions;
    for (const auto &part : actual.participations)
      if (chosen.contains(part.id))
        positions.push_back(part.position);
    if (std::adjacent_find(positions.begin(), positions.end()) != positions.end())
      throw std::runtime_error("Posições locais ambíguas; nada foi reordenado");
    auto q = db.prepare("UPDATE contextual_participations SET position=? WHERE id=?");
    for (std::size_t i = 0; i < ids.size(); ++i) {
      if (old_positions.at(ids[i]) == positions[i])
        continue;
      q.bind(1, positions[i]);
      q.bind(2, ids[i]);
      q.run();
      q.reset();
    }
  }
  if (declare_succession) {
    std::set<std::pair<std::string, std::string>> existing;
    for (const auto &edge : actual.dependencies)
      if (edge.kind == "succession")
        existing.emplace(edge.source, edge.target);
    auto q = db.prepare("INSERT INTO contextual_dependencies"
                        "(id,project_id,work_id,plan_id,source_id,target_id,kind,note) "
                        "VALUES(?,?,?,?,?,?,'succession','')");
    for (std::size_t i = 1; i < ids.size(); ++i) {
      if (existing.contains({ids[i - 1], ids[i]}))
        continue;
      owner(q, actual, project::new_uuid());
      q.bind(5, ids[i - 1]);
      q.bind(6, ids[i]);
      q.run();
      q.reset();
    }
  }
  budget(db, actual.plan_id);
  // Reading before commit also checks collection limits; failures roll back
  // both order and links, rather than leaving an unreadable composition.
  (void)read(db, p, actual.plan_id);
  tx.commit();
}
void ContextualPlanningService::remove_dependency(const ContextualSnapshot &s,
                                                  const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Retirar dependência contextual declarada");
  const auto actual = check(db, p, s);
  find(actual.dependencies, [&](auto &x) { return x.id == id; });
  erase(db, "contextual_dependencies", id);
  tx.commit();
}
} // namespace inde::application
