#include "inde/application/document_alternatives.hpp"
#include "inde/project/document_alternatives.hpp"
#include "inde/project/project.hpp"
#include <algorithm>
#include <glib.h>
#include <stdexcept>
namespace inde::application {
DocumentEditState paste_leaf_fragment(const DocumentEditState &before,
                                      std::size_t start, std::size_t end,
                                      const TextFragment &fragment, bool styles,
                                      const std::string &owner) {
  auto after = paste_fragment(before, start, end, fragment, styles);
  if (after.document.content != before.document.content)
    after.document.resmas = project::edit_alternatives(
        before.document.resmas,
        project::utf8_character_count(before.document.content), start, end,
        project::utf8_character_count(fragment.text), owner);
  project::validate(after.document);
  return after;
}
namespace {
auto locate(project::Document &d, const std::string &id) {
  auto it = std::find_if(d.resmas.begin(), d.resmas.end(),
                         [&](const auto &r) { return r.id == id; });
  if (it == d.resmas.end())
    throw std::runtime_error("Resma não encontrada");
  return it;
}
void safe_range(const project::Document &d, std::size_t start,
                std::size_t end) {
  if (start > end || end > project::utf8_character_count(d.content))
    throw std::runtime_error("Trecho fora do Documento");
  for (const auto &a : d.anchors)
    if ((a.start_offset < end && start < a.end_offset) ||
        (a.start_offset == a.end_offset && start <= a.start_offset &&
         a.start_offset <= end) ||
        (start == end && a.start_offset <= start && start <= a.end_offset))
      throw std::runtime_error(
          "Este trecho contém marcações ou vínculos. A troca de folhas não "
          "pode transferi-los por posição; conserve-os até o protocolo de "
          "vínculos entre folhas (P04).");
}
std::shared_ptr<const project::DocumentLeafContent>
capture(const project::Document &d, std::size_t start, std::size_t end) {
  auto p = std::make_shared<project::DocumentLeafContent>();
  const auto *a = g_utf8_offset_to_pointer(d.content.c_str(), start),
             *b = g_utf8_offset_to_pointer(d.content.c_str(), end);
  p->text.assign(a, b);
  for (auto f : d.formatting) {
    f.start_offset = std::max(f.start_offset, start);
    f.end_offset = std::min(f.end_offset, end);
    if (f.start_offset < f.end_offset) {
      f.start_offset -= start;
      f.end_offset -= start;
      p->formatting.push_back(std::move(f));
    }
  }
  return p;
}
DocumentEditState replace_leaf(const DocumentEditState &before,
                               const project::DocumentResma &r,
                               const project::DocumentLeafContent &p) {
  auto after = replace_selection(before, r.start, r.end, p.text, r.id);
  const auto end = r.start + project::utf8_character_count(p.text);
  std::vector<project::DocumentFormatSpan> styles;
  // Keep only the exterior pieces of inherited styles, then install exactly
  // this leaf's local styles. Exterior text is never reformatted by switching.
  for (auto f : after.document.formatting) {
    auto left = f;
    left.end_offset = std::min(left.end_offset, r.start);
    if (left.start_offset < left.end_offset)
      styles.push_back(std::move(left));
    auto right = f;
    right.start_offset = std::max(right.start_offset, end);
    if (right.start_offset < right.end_offset)
      styles.push_back(std::move(right));
  }
  for (auto f : p.formatting) {
    f.start_offset += r.start;
    f.end_offset += r.start;
    styles.push_back(std::move(f));
  }
  after.document.formatting = std::move(styles);
  after.selection = {r.start, r.start};
  return after;
}
} // namespace
DocumentEditState create_alternative(const DocumentEditState &before,
                                     std::size_t start, std::size_t end,
                                     const std::string &id) {
  project::validate(before.document);
  auto d = before.document;
  project::DocumentResma r;
  if (id.empty()) {
    safe_range(d, start, end);
    if (d.resmas.size() >= project::document_resma_limit)
      throw std::runtime_error("Limite de resmas atingido");
    for (const auto &x : d.resmas)
      if ((start < x.end && x.start < end) ||
          (x.start == x.end && start <= x.start && x.start <= end) ||
          (start == end && x.start <= start && start <= x.end))
        throw std::runtime_error("Escolha um trecho fora das resmas "
                                 "existentes; não há resmas aninhadas");
    r = {project::new_uuid(),
         "Trecho " + std::to_string(d.resmas.size() + 1),
         {},
         start,
         end,
         {}};
    r.leaves.push_back({project::new_uuid(), "Original", {}});
    r.top_id = r.leaves.front().id;
  } else {
    r = *locate(d, id);
    start = r.start;
    end = r.end;
    safe_range(d, start, end);
  }
  if (r.leaves.size() >= project::resma_leaf_limit)
    throw std::runtime_error("Limite de folhas desta resma atingido");
  auto current = capture(d, start, end);
  if (id.empty())
    d.resmas.push_back(r);
  auto pending = locate(d, r.id);
  const auto next_id = project::new_uuid();
  pending->leaves.push_back(
      {next_id, "Alternativa " + std::to_string(pending->leaves.size()),
       std::make_shared<const project::DocumentLeafContent>()});
  auto after = replace_leaf({d, before.selection}, r, {});
  auto at = locate(after.document, r.id);
  for (auto &l : at->leaves) {
    if (l.id == at->top_id)
      l.covered = current;
    if (l.id == next_id)
      l.covered.reset();
  }
  at->top_id = next_id;
  project::validate(after.document);
  return after;
}
DocumentEditState select_document_leaf(const DocumentEditState &before,
                                       const std::string &id,
                                       const std::string &leaf_id) {
  project::validate(before.document);
  auto d = before.document;
  const auto r = *locate(d, id);
  const auto leaf =
      std::find_if(r.leaves.begin(), r.leaves.end(),
                   [&](const auto &l) { return l.id == leaf_id; });
  if (leaf == r.leaves.end())
    throw std::runtime_error("Folha não encontrada");
  if (leaf_id == r.top_id)
    return before;
  safe_range(d, r.start, r.end);
  const auto current = capture(d, r.start, r.end), incoming = leaf->covered;
  auto after = replace_leaf(before, r, *incoming);
  auto at = locate(after.document, id);
  for (auto &l : at->leaves) {
    if (l.id == at->top_id)
      l.covered = current;
    if (l.id == leaf_id)
      l.covered.reset();
  }
  at->top_id = leaf_id;
  project::validate(after.document);
  return after;
}
DocumentEditState rename_document_leaf(const DocumentEditState &before,
                                       const std::string &id,
                                       const std::string &leaf_id,
                                       const std::string &label) {
  auto after = before;
  auto at = locate(after.document, id);
  auto l = std::find_if(at->leaves.begin(), at->leaves.end(),
                        [&](const auto &x) { return x.id == leaf_id; });
  if (l == at->leaves.end())
    throw std::runtime_error("Folha não encontrada");
  l->label = label;
  project::validate(after.document);
  return after;
}
} // namespace inde::application
