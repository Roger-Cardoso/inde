#include "../persistence/contextual_containment.hpp"
#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <set>
#include <stdexcept>

namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
namespace contextual_detail {
void validate_containment(SqliteDatabase &db, const std::string &work_id) {
  persistence::validate_contextual_containment(db, work_id);
}
} // namespace contextual_detail
namespace {
std::string plan(SqliteDatabase &db, const ContextualSnapshot &s,
                 const std::string &title) {
  auto count =
      db.prepare("SELECT count(*) FROM contextual_plans WHERE work_id=?");
  count.bind(1, s.work_id);
  count.step();
  if (count.column_integer(0) >= 200)
    throw std::runtime_error("Limite de 200 composições/interiores por Obra");
  auto q =
      db.prepare("INSERT INTO contextual_plans(id,project_id,work_id,title) "
                 "VALUES(?,?,?,?)");
  const auto id = project::new_uuid();
  q.bind(1, id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, title.empty() ? std::string("Interior do trecho") : title);
  q.run();
  return id;
}
void module(SqliteDatabase &db, const ContextualMoment &m,
            const std::string &interior, const std::string &scale) {
  auto q = db.prepare(
      "INSERT INTO "
      "contextual_modules(moment_id,project_id,work_id,contents_plan_id,scale) "
      "VALUES(?,?,?,?,?) ON CONFLICT(moment_id) DO UPDATE SET "
      "contents_plan_id=excluded.contents_plan_id,scale=excluded.scale");
  q.bind(1, m.id);
  q.bind(2, m.project_id);
  q.bind(3, m.work_id);
  if (interior.empty())
    q.bind_null(4);
  else
    q.bind(4, interior);
  q.bind(5, scale);
  q.run();
}
std::string identity(SqliteDatabase &db, const ContextualSnapshot &s,
                     const std::string &title) {
  auto q = db.prepare("INSERT INTO "
                      "contextual_moments(id,project_id,work_id,title,"
                      "description,token) VALUES(?,?,?,?,'',?)");
  const auto id = project::new_uuid();
  q.bind(1, id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, title);
  q.bind(5, project::new_uuid());
  q.run();
  return id;
}
void budgets(SqliteDatabase &db, const ContextualMoment &m) {
  std::set<std::string> seen;
  for (const auto &use : m.uses)
    if (seen.insert(use.plan_id).second)
      budget(db, use.plan_id);
}
} // namespace
void ContextualPlanningService::set_scale(const ContextualMoment &expected,
                                          const std::string &scale) {
  text(scale, 80);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Nomear escala opcional de trecho compartilhado");
  const auto m = check_moment(db, p, expected);
  if (scale != m.scale)
    module(db, m, m.contents_plan_id, scale);
  budgets(db, m);
  tx.commit();
}
void ContextualPlanningService::set_role(const ContextualSnapshot &expected,
                                         const std::string &part,
                                         const std::string &category,
                                         bool parallel) {
  text(category, 80);
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Editar papel somente neste uso do trecho");
  const auto s = check(db, p, expected);
  participation(s, part);
  if (category.empty() && !parallel) {
    auto q =
        db.prepare("DELETE FROM contextual_roles WHERE participation_id=?");
    q.bind(1, part);
    q.run();
  } else {
    auto q = db.prepare(
        "INSERT INTO "
        "contextual_roles(participation_id,project_id,work_id,plan_id,category,"
        "parallel) "
        "VALUES(?,?,?,?,?,?) ON CONFLICT(participation_id) DO UPDATE SET "
        "category=excluded.category,parallel=excluded.parallel");
    q.bind(1, part);
    q.bind(2, s.project_id);
    q.bind(3, s.work_id);
    q.bind(4, s.plan_id);
    q.bind(5, category);
    q.bind(6, parallel ? 1 : 0);
    q.run();
  }
  budget(db, s.plan_id);
  tx.commit();
}
std::string
ContextualPlanningService::develop(const ContextualSnapshot &expected,
                                   const std::string &part) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Desenvolver interior de trecho sem classificar ou copiar");
  const auto s = check(db, p, expected);
  const auto &x = participation(s, part);
  const auto m = read_moment(db, p, x.moment_id);
  if (!m.contents_plan_id.empty()) {
    tx.commit();
    return m.contents_plan_id;
  }
  const auto id = plan(db, s, m.title);
  module(db, m, id, m.scale);
  validate_containment(db, s.work_id);
  budgets(db, m);
  tx.commit();
  return id;
}
std::string
ContextualPlanningService::compose_plan(const ContextualSnapshot &target,
                                        const ContextualSnapshot &source) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Usar composição existente como trecho, sem cópia");
  const auto s = check(db, p, target), inner = check(db, p, source);
  if (s.work_id != inner.work_id)
    throw std::runtime_error("Trechos devem pertencer à mesma Obra");
  auto q = db.prepare(
      "SELECT moment_id FROM contextual_modules WHERE contents_plan_id=?");
  q.bind(1, inner.plan_id);
  std::string id;
  if (q.step())
    id = q.column_text(0);
  else {
    id = identity(db, s, inner.title);
    module(db, read_moment(db, p, id), inner.plan_id, "");
  }
  const auto m = read_moment(db, p, id);
  if (m.uses.size() >= 2000)
    throw std::runtime_error("Limite de 2.000 usos compartilhados");
  const auto result = insert(db, s, id);
  validate_containment(db, s.work_id);
  budget(db, s.plan_id);
  tx.commit();
  return result;
}
std::string
ContextualPlanningService::group(const ContextualSnapshot &expected,
                                 const std::vector<std::string> &parts,
                                 const std::string &title) {
  text(title, 200);
  if (blank(title))
    throw std::runtime_error("Dê um nome ao trecho agrupado");
  const std::set<std::string> chosen(parts.begin(), parts.end());
  if (chosen.size() < 2 || chosen.size() != parts.size())
    throw std::runtime_error("Escolha pelo menos dois trechos diferentes");
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Agrupar trechos preservando identidades, notas e vínculos");
  const auto s = check(db, p, expected);
  for (const auto &id : chosen)
    participation(s, id);
  for (const auto &x : s.memberships)
    if (chosen.contains(x.participation_id))
      throw std::runtime_error(
          "O grupo contém membros de opções. Use a composição inteira como "
          "trecho ou retire explicitamente os encaixes antes de agrupar. Nada "
          "foi alterado");
  // One interior owns the original participations. No duplicated declaration,
  // note, text association, role or reference is manufactured.
  const auto inner = plan(db, s, title), mid = identity(db, s, title);
  module(db, read_moment(db, p, mid), inner, "");
  std::int64_t first = -1, position{};
  for (const auto &x : s.participations)
    if (chosen.contains(x.id)) {
      if (first < 0)
        first = x.position;
      auto move = db.prepare("UPDATE contextual_participations SET "
                             "plan_id=?,position=? WHERE id=?");
      move.bind(1, inner);
      move.bind(2, position++);
      move.bind(3, x.id);
      move.run();
      for (const auto *table :
           {"contextual_visual_items", "contextual_roles", "contextual_declarations",
            "contextual_references", "contextual_text_links",
            "contextual_text_targets"}) {
        auto q = db.prepare("UPDATE " + std::string(table) +
                            " SET plan_id=? WHERE participation_id=?");
        q.bind(1, inner);
        q.bind(2, x.id);
        q.run();
      }
      auto target = db.prepare(
          "UPDATE contextual_bridges SET plan_id=? WHERE target_id=?");
      target.bind(1, inner);
      target.bind(2, x.id);
      target.run();
      auto source = db.prepare(
          "UPDATE contextual_bridges SET source_plan_id=? WHERE source_id=?");
      source.bind(1, inner);
      source.bind(2, x.id);
      source.run();
    }
  for (const auto &edge : s.dependencies) {
    const bool from = chosen.contains(edge.source),
               to = chosen.contains(edge.target);
    if (!from && !to)
      continue;
    if (from && to) {
      auto q =
          db.prepare("UPDATE contextual_dependencies SET plan_id=? WHERE id=?");
      q.bind(1, inner);
      q.bind(2, edge.id);
      q.run();
    } else {
      // The author already declared this edge. Only its owner representation
      // changes when its endpoints move across the newly explicit boundary.
      auto q = db.prepare(
          "INSERT INTO "
          "contextual_bridges(id,project_id,work_id,plan_id,target_id,source_"
          "plan_id,source_id,kind,note) VALUES(?,?,?,?,?,?,?,?,?)");
      q.bind(1, edge.id);
      q.bind(2, s.project_id);
      q.bind(3, s.work_id);
      q.bind(4, to ? inner : s.plan_id);
      q.bind(5, edge.target);
      q.bind(6, from ? inner : s.plan_id);
      q.bind(7, edge.source);
      q.bind(8, edge.kind);
      q.bind(9, edge.note);
      q.run();
      auto del = db.prepare("DELETE FROM contextual_dependencies WHERE id=?");
      del.bind(1, edge.id);
      del.run();
    }
  }
  // All selected rows moved away; placing the group at the first selected
  // position leaves unselected rows in their original relative order.
  auto remaining = read(db, p, s.plan_id);
  const auto result = insert(db, remaining, mid);
  auto place =
      db.prepare("UPDATE contextual_participations SET position=? WHERE id=?");
  place.bind(1, first);
  place.bind(2, result);
  place.run();
  group_visual(db, s, parts, result);
  validate_containment(db, s.work_id);
  budget(db, inner);
  budget(db, s.plan_id);
  // Outgoing edges can change foreign aggregates, too; cap each destination.
  auto affected = db.prepare(
      "SELECT DISTINCT plan_id FROM contextual_bridges WHERE source_plan_id=?");
  affected.bind(1, inner);
  while (affected.step())
    budget(db, affected.column_text(0));
  tx.commit();
  return result;
}
} // namespace inde::application
