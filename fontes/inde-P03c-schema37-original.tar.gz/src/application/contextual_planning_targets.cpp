#include "contextual_planning_support.hpp"
#include "inde/application/project_service.hpp"
#include "inde/persistence/composition_store.hpp"
#include "inde/persistence/sqlite_writing_repository.hpp"
#include "inde/project/document_state.hpp"
#include <algorithm>
#include <glib.h>
#include <stdexcept>
namespace inde::application {
using namespace persistence;
using namespace contextual_detail;
namespace {
const ContextualTextLink &find_link(const ContextualSnapshot &s,
                                    const std::string &id) {
  auto it = std::find_if(s.text_links.begin(), s.text_links.end(),
                         [&](auto &x) { return x.id == id; });
  if (it == s.text_links.end())
    throw std::runtime_error("Alvo textual ausente do contexto");
  return *it;
}
project::Document load_document(SqliteDatabase &db, const project::Project &p,
                                const std::string &id) {
  auto q = db.prepare("SELECT length(CAST(content AS BLOB)) FROM documents "
                      "WHERE id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error(
        "Documento ausente; associação preservada para conferência");
  if (q.column_integer(0) > 32 * 1024 * 1024)
    throw std::runtime_error("Documento excede 32 MiB; consulta interrompida");
  auto d = SqliteWritingRepository::load_in_transaction(
      db, p.manifest().project_id, id);
  if (!d)
    throw std::runtime_error("Documento ausente");
  return *d;
}
std::string anchor_text(const project::Document &d, const std::string &id,
                        BuilderRealization &out) {
  auto at = std::find_if(d.anchors.begin(), d.anchors.end(),
                         [&](auto &a) { return a.id == id; });
  if (at == d.anchors.end() || at->start_offset >= at->end_offset ||
      at->end_offset > project::utf8_character_count(d.content))
    throw std::runtime_error("Trecho removido ou vazio; escolha outro alvo ou "
                             "desvincule sem apagar a prosa");
  for (const auto &a : d.semantics.anchors)
    if (a.anchor_id == id && a.state != project::AnchorResolution::Resolved)
      throw std::runtime_error(
          "Âncora não reconciliada; nenhuma correspondência foi inferida");
  out.start = at->start_offset;
  out.end = at->end_offset;
  out.title = d.title + " · " + at->label;
  return std::string(
      g_utf8_offset_to_pointer(d.content.c_str(), at->start_offset),
      g_utf8_offset_to_pointer(d.content.c_str(), at->end_offset));
}
project::StoredComposition load_composition(SqliteDatabase &db,
                                            const project::Project &p,
                                            const std::string &id) {
  auto q = db.prepare("SELECT payload,sha256,revision FROM compositions WHERE "
                      "id=? AND project_id=?");
  q.bind(1, id);
  q.bind(2, p.manifest().project_id);
  if (!q.step())
    throw std::runtime_error("Montagem ausente");
  return {decode_composition(q.column_text(0), q.column_text(1)),
          p.manifest().project_id,
          q.column_text(1),
          {},
          q.column_integer(2)};
}
BuilderRealization resolve(SqliteDatabase &db, const project::Project &p,
                           const ContextualTextLink &x, bool observe) {
  BuilderRealization r;
  r.id = x.id;
  r.unit_id = x.participation_id;
  r.document_id = x.document_id;
  r.anchor_id = x.anchor_id;
  r.composition_id = x.composition_id;
  r.occurrence_id = x.occurrence_id;
  r.observed_sha = x.observed_sha;
  r.note = x.note;
  r.title = x.title;
  r.table = x.anchor_id.empty() && x.composition_id.empty()
                ? "contextual_text_links"
                : "contextual_text_targets";
  if (!x.composition_id.empty()) {
    const auto c = load_composition(db, p, x.composition_id);
    const auto &o = c.value.blocks.occurrence(x.occurrence_id);
    if (o.mode == experimental::PlacementMode::ReferenceOnly)
      throw std::runtime_error(
          "Ocorrência de navegação não é prosa; confira o alvo");
    const auto &v = c.value.blocks.revision(o);
    const bool draft = c.value.drafts.contains(o.block_id);
    if (observe && draft)
      throw std::runtime_error(
          "Há rascunho não aplicado neste bloco; aplique ou retire o rascunho "
          "antes de observar/conferir a versão aplicada. Nenhuma fidelidade "
          "foi inferida");
    if (v.text.empty())
      throw std::runtime_error("Ocorrência vazia; associação preservada");
    r.title = c.value.name + " · " + c.value.blocks.block(o.block_id).label;
    r.status = draft                                        ? "draft"
               : c.value.blocks.visible(o, c.value.profile) ? "current"
                                                            : "hidden";
    if (observe)
      r.current_sha = composition_checksum(v.text);
  } else if (!x.anchor_id.empty()) {
    const auto d = load_document(db, p, x.document_id);
    const auto v = anchor_text(d, x.anchor_id, r);
    if (observe)
      r.current_sha = composition_checksum(v);
  } else {
    auto q =
        db.prepare("SELECT title FROM documents WHERE id=? AND project_id=?");
    q.bind(1, x.document_id);
    q.bind(2, p.manifest().project_id);
    if (!q.step())
      throw std::runtime_error("Documento ausente");
    r.title = q.column_text(0);
    if (observe)
      r.current_sha =
          composition_checksum(load_document(db, p, x.document_id).content);
  }
  return r;
}
std::string insert_target(SqliteDatabase &db, const ContextualSnapshot &s,
                          const std::string &part, const std::string &doc,
                          const std::string &anchor,
                          const std::string &composition,
                          const std::string &occurrence,
                          const std::string &sha) {
  participation(s, part);
  const auto id = project::new_uuid();
  auto q =
      db.prepare("INSERT INTO "
                 "contextual_text_targets(id,project_id,work_id,plan_id,"
                 "participation_id,document_id,anchor_id,composition_id,"
                 "occurrence_id,observed_sha) VALUES(?,?,?,?,?,?,?,?,?,?)");
  q.bind(1, id);
  q.bind(2, s.project_id);
  q.bind(3, s.work_id);
  q.bind(4, s.plan_id);
  q.bind(5, part);
  auto optional = [&](int n, const std::string &v) {
    if (v.empty())
      q.bind_null(n);
    else
      q.bind(n, v);
  };
  optional(6, doc);
  optional(7, anchor);
  optional(8, composition);
  optional(9, occurrence);
  q.bind(10, sha);
  q.run();
  budget(db, s.plan_id);
  return id;
}
} // namespace
namespace contextual_detail {
BuilderRealization resolve_text(SqliteDatabase &db, const project::Project &p,
                                const ContextualTextLink &x, bool observe) {
  return resolve(db, p, x, observe);
}
} // namespace contextual_detail
BuilderRealization ContextualPlanningService::text_destination(
    const ContextualSnapshot &s, const std::string &id, bool observe) const {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, SqliteTransaction::Mode::Deferred);
  const auto actual = check(db, p, s);
  auto r = resolve(db, p, find_link(actual, id), observe);
  tx.commit();
  return r;
}
std::string ContextualPlanningService::associate_anchor(
    const ContextualSnapshot &s, const std::string &part,
    const project::Document &expected, const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(db, "Associar trecho ao contexto sem copiar texto");
  const auto actual = check(db, p, s);
  const auto d = load_document(db, p, expected.id);
  if (!project::same_document_state(d, expected))
    throw std::runtime_error(
        "Documento mudou; consulte novamente antes de associar");
  BuilderRealization r;
  const auto v = anchor_text(d, id, r);
  const auto result = insert_target(db, actual, part, d.id, id, "", "",
                                    composition_checksum(v));
  tx.commit();
  return result;
}
std::string ContextualPlanningService::associate_occurrence(
    const ContextualSnapshot &s, const std::string &part,
    const project::StoredComposition &expected, const std::string &id) {
  const auto &p = current(service_);
  auto db = open(p);
  SqliteTransaction tx(
      db, "Associar ocorrência ao contexto sem materializar prosa");
  const auto actual = check(db, p, s);
  const auto c =
      load_composition(db, p, expected.value.blocks.composition_id());
  if (expected.project_id != c.project_id || expected.revision != c.revision ||
      expected.sha256 != c.sha256 ||
      composition_checksum(encode_composition(expected.value)) != c.sha256)
    throw std::runtime_error(
        "Montagem mudou; consulte novamente antes de associar");
  const auto &o = c.value.blocks.occurrence(id);
  if (c.value.drafts.contains(o.block_id))
    throw std::runtime_error(
        "Há rascunho não aplicado; aplique ou retire o rascunho antes de "
        "associar a versão aplicada desta ocorrência");
  const auto &v = c.value.blocks.revision(o);
  if (o.mode == experimental::PlacementMode::ReferenceOnly || v.text.empty())
    throw std::runtime_error(
        "Escolha ocorrência com prosa, não referência ou trecho vazio");
  const auto result =
      insert_target(db, actual, part, "", "", c.value.blocks.composition_id(),
                    id, composition_checksum(v.text));
  tx.commit();
  return result;
}
std::string ContextualPlanningService::associate_range(
    const ContextualSnapshot &s, const std::string &part,
    const project::Document &expected, std::size_t start, std::size_t end,
    const std::string &label) {
  text(label, 200);
  if (blank(label))
    throw std::runtime_error("Identifique o trecho marcado");
  const auto &p = current(service_);
  auto next = expected;
  project::DocumentAnchor a{project::new_uuid(), label, start, end};
  next.anchors.push_back(a);
  next.updated_at = project::utc_now();
  project::validate(next);
  BuilderRealization r;
  const auto sha = composition_checksum(anchor_text(next, a.id, r));
  std::string result;
  SqliteWritingRepository{}.save_with_context(
      p.path(), next, &expected, s.project_id,
      "Marcar seleção e associar contexto atomicamente",
      [&](SqliteDatabase &db) {
        const auto actual = check(db, p, s);
        result =
            insert_target(db, actual, part, expected.id, a.id, "", "", sha);
      });
  return result;
}
} // namespace inde::application
