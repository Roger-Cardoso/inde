#include "inde/project/document_visibility.hpp"
#include "inde/project/project.hpp"
#include "inde/project/writing.hpp"
#include <glib.h>
#include <map>
#include <set>
#include <stdexcept>
#include <uuid/uuid.h>
namespace inde::project {
std::string to_string(VisibilityRuleKind k) {
  switch (k) {
  case VisibilityRuleKind::Paragraph:
    return "paragraph";
  case VisibilityRuleKind::Resma:
    return "resma";
  case VisibilityRuleKind::Anchor:
    return "anchor";
  case VisibilityRuleKind::SemanticType:
    return "semantic-type";
  case VisibilityRuleKind::Annotation:
    return "annotation";
  case VisibilityRuleKind::Style:
    return "style";
  }
  throw std::runtime_error("Critério de visibilidade desconhecido");
}
VisibilityRuleKind visibility_rule_kind(const std::string &s) {
  for (auto k : {VisibilityRuleKind::Paragraph, VisibilityRuleKind::Resma,
                 VisibilityRuleKind::Anchor, VisibilityRuleKind::SemanticType,
                 VisibilityRuleKind::Annotation, VisibilityRuleKind::Style})
    if (to_string(k) == s)
      return k;
  throw std::runtime_error("Critério de visibilidade incompatível");
}
std::string display_name(VisibilityRuleKind k) {
  switch (k) {
  case VisibilityRuleKind::Paragraph:
    return "Parágrafos";
  case VisibilityRuleKind::Resma:
    return "Resmas";
  case VisibilityRuleKind::Anchor:
    return "Trechos marcados";
  case VisibilityRuleKind::SemanticType:
    return "Tipos de marcação semântica";
  case VisibilityRuleKind::Annotation:
    return "Marcações individuais";
  case VisibilityRuleKind::Style:
    return "Estilos de texto";
  }
  return {};
}
void validate_visibility_profiles(
    const std::vector<VisibilityProfile> &profiles) {
  if (profiles.size() > visibility_profile_limit)
    throw std::runtime_error("Limite de32perfis atingido");
  std::set<std::string> ids;
  for (const auto &p : profiles) {
    uuid_t u;
    if (uuid_parse(p.id.c_str(), u) || p.id.size() != 36 ||
        !ids.insert(p.id).second)
      throw std::runtime_error("Identidade de perfil inválida/repetida");
    if (p.name.find_first_not_of(" \t\r\n") == std::string::npos ||
        p.name.size() > 256 || p.name.find('\0') != std::string::npos ||
        !g_utf8_validate(p.name.data(), p.name.size(), nullptr))
      throw std::runtime_error("Informe um nome curto e válido para o perfil");
    if (p.include.size() + p.exclude.size() > visibility_rule_limit)
      throw std::runtime_error("Limite de256critérios por perfil atingido");
    for (const auto *rules : {&p.include, &p.exclude}) {
      std::set<std::pair<VisibilityRuleKind, std::string>> seen;
      for (const auto &r : *rules) {
        (void)to_string(r.kind);
        if (!seen.emplace(r.kind, r.key).second)
          throw std::runtime_error("Critério de perfil repetido");
        if (r.kind == VisibilityRuleKind::SemanticType)
          validate_semantic_key(r.key);
        else if (r.kind == VisibilityRuleKind::Style)
          (void)document_text_style_from_string(r.key);
        else if (r.key.size() != 36 || uuid_parse(r.key.c_str(), u))
          throw std::runtime_error("Identidade inválida no critério de perfil");
      }
    }
  }
}
std::size_t visibility_retained_bytes(const Document &d) {
  std::size_t n = d.visibility_profiles.capacity() * sizeof(VisibilityProfile);
  for (const auto &p : d.visibility_profiles) {
    n += p.id.capacity() + p.name.capacity();
    for (const auto *v : {&p.include, &p.exclude}) {
      n += v->capacity() * sizeof(VisibilityRule);
      for (const auto &r : *v)
        n += r.key.capacity();
    }
  }
  return n;
}
void copy_visibility_profiles(const Document &source, Document &copy) {
  if (source.content != copy.content)
    throw std::runtime_error(
        "Perfis só podem ser conservados nesta cópia integral exata");
  copy.visibility_profiles = source.visibility_profiles;
  std::map<std::string, std::string> paragraphs, resmas;
  if (source.paragraphs.rows.size() == copy.paragraphs.rows.size())
    for (std::size_t i = 0; i < source.paragraphs.rows.size(); ++i)
      paragraphs[source.paragraphs.rows[i].id] = copy.paragraphs.rows[i].id;
  if (source.resmas.size() == copy.resmas.size())
    for (std::size_t i = 0; i < source.resmas.size(); ++i)
      resmas[source.resmas[i].id] = copy.resmas[i].id;
  for (auto &p : copy.visibility_profiles) {
    p.id = new_uuid();
    for (auto *rules : {&p.include, &p.exclude})
      for (auto &r : *rules) {
        const auto *map = r.kind == VisibilityRuleKind::Paragraph ? &paragraphs
                          : r.kind == VisibilityRuleKind::Resma   ? &resmas
                                                                  : nullptr;
        if (map)
          if (auto i = map->find(r.key); i != map->end())
            r.key = i->second;
      }
  }
}
} // namespace inde::project
