#include "inde/project/document_alternatives.hpp"
#include "inde/project/project.hpp"
#include <algorithm>
#include <glib.h>
#include <limits>
#include <set>
#include <stdexcept>
#include <uuid/uuid.h>
namespace inde::project {
void validate_alternatives(const Document &d) {
  if (d.resmas.size() > document_resma_limit)
    throw std::runtime_error("Limite de resmas excedido");
  if (d.resmas.empty())
    return;
  if (d.content.find('\0') != std::string::npos ||
      !g_utf8_validate(d.content.data(), d.content.size(), nullptr))
    throw std::runtime_error("Corpo inválido para resmas");
  const auto length = utf8_character_count(d.content);
  std::set<std::string> ids;
  std::size_t bytes{};
  auto identity = [&](const std::string &id) {
    uuid_t u;
    if (id.size() != 36 || uuid_parse(id.c_str(), u) || !ids.insert(id).second)
      throw std::runtime_error(
          "Identidade repetida/inválida de resma ou folha");
  };
  auto label = [](const std::string &s) {
    if (s.empty() || s.size() > 512 || s.find('\0') != std::string::npos ||
        !g_utf8_validate(s.data(), s.size(), nullptr))
      throw std::runtime_error("Nome de folha/resma inválido");
  };
  for (const auto &r : d.resmas) {
    identity(r.id);
    label(r.label);
    if (r.start > r.end || r.end > length || r.leaves.size() < 2 ||
        r.leaves.size() > resma_leaf_limit)
      throw std::runtime_error("Intervalo/coleção de folhas incompatível");
    std::size_t tops{};
    for (const auto &l : r.leaves) {
      identity(l.id);
      label(l.label);
      if (l.id == r.top_id) {
        ++tops;
        if (l.covered)
          throw std::runtime_error("Folha de topo não pode duplicar texto");
      } else {
        if (!l.covered)
          throw std::runtime_error("Folha encoberta sem conteúdo");
        const auto &p = *l.covered;
        bytes += p.text.size();
        if (bytes > covered_leaf_text_limit ||
            p.text.find('\0') != std::string::npos ||
            !g_utf8_validate(p.text.data(), p.text.size(), nullptr))
          throw std::runtime_error("Conteúdo encoberto inválido/excedido");
        const auto n = utf8_character_count(p.text);
        if (p.formatting.size() > 100000)
          throw std::runtime_error("Formatação encoberta excedida");
        for (const auto &f : p.formatting) {
          validate_format_span(f);
          if (f.start_offset >= f.end_offset || f.end_offset > n)
            throw std::runtime_error("Estilo fora da folha encoberta");
        }
      }
    }
    if (tops != 1)
      throw std::runtime_error("Topo da resma inexistente");
  }
  for (std::size_t a = 0; a < d.resmas.size(); ++a)
    for (std::size_t b = a + 1; b < d.resmas.size(); ++b) {
      const auto &x = d.resmas[a], &y = d.resmas[b];
      if (x.start < y.end && y.start < x.end)
        throw std::runtime_error("Resmas sobrepostas não são permitidas");
    }
}
std::string resma_at(const std::vector<DocumentResma> &rows, std::size_t p,
                     std::string_view preferred) {
  for (const auto &r : rows)
    if (r.id == preferred && r.start <= p && p <= r.end)
      return r.id;
  for (const auto &r : rows)
    if (r.start == p && r.end == p)
      return r.id;
  for (const auto &r : rows)
    if (r.start <= p && p < r.end)
      return r.id;
  for (const auto &r : rows)
    if (r.end == p)
      return r.id;
  return {};
}
std::vector<DocumentResma>
edit_alternatives(const std::vector<DocumentResma> &before, std::size_t length,
                  std::size_t start, std::size_t end, std::size_t added,
                  std::string_view preferred) {
  if (start > end || end > length ||
      added >
          std::numeric_limits<std::size_t>::max() - (length - (end - start)))
    throw std::runtime_error("Edição fora das resmas");
  auto rows = before;
  auto owner = resma_at(before, start, preferred);
  if(preferred==outside_resma_owner)owner.clear();
  const bool explicit_owner =
      std::any_of(before.begin(), before.end(), [&](const auto &r) {
        return r.id == preferred && r.start <= start && start <= r.end;
      });
  if (start < end && !explicit_owner) {
    // A replacement consumes existing text: a coincident empty slot must not
    // steal the identity of the positive-width leaf containing that text.
    owner.clear();
    for (const auto &r : before)
      if (r.start <= start && start < r.end) {
        owner = r.id;
        break;
      }
  }
  const auto owner_row =
      std::find_if(before.begin(), before.end(),
                   [&](const auto &r) { return r.id == owner; });
  const bool positive_owner_at_start = owner_row != before.end() &&
                                       owner_row->start == start &&
                                       owner_row->end > start;
  for (auto &r : rows) {
    if (start == end) {
      if (r.id == owner) {
        r.end += added;
      } else if (r.start >= start) {
        r.start += added;
        r.end += added;
      } else if (r.end > start)
        r.end += added;
    } else {
      auto shift = [&](std::size_t p) { return start + added + (p - end); };
      if (r.start >= start && r.end <= end && r.id != owner) {
        // A zero-width neighbour before the owning leaf stays on its left
        // boundary, not in the interior of a partially replaced leaf.
        const bool left_slot =
            r.start == r.end && r.start == start && positive_owner_at_start;
        r.start = r.end = left_slot ? start : start + added;
        continue;
      }
      const auto old_start = r.start, old_end = r.end;
      r.start = old_start < start  ? old_start
                : old_start >= end ? shift(old_start)
                                   : start + (r.id == owner ? 0 : added);
      r.end = old_end <= start
                  ? old_end + (r.id == owner && old_end == start ? added : 0)
              : old_end >= end ? shift(old_end)
                               : start + (r.id == owner ? added : 0);
      if (r.end < r.start)
        r.end = r.start;
    }
  }
  return rows;
}
std::size_t alternatives_retained_bytes(const Document &d) {
  std::size_t n = d.resmas.capacity() * sizeof(DocumentResma);
  for (const auto &r : d.resmas) {
    n += r.id.capacity() + r.label.capacity() + r.top_id.capacity() +
         r.leaves.capacity() * sizeof(DocumentLeaf);
    for (const auto &l : r.leaves) {
      n += l.id.capacity() + l.label.capacity();
      if (l.covered) {
        n += sizeof(DocumentLeafContent) + l.covered->text.capacity() +
             l.covered->formatting.capacity() * sizeof(DocumentFormatSpan);
        for (const auto &f : l.covered->formatting)
          n += f.value.capacity();
      }
    }
  }
  return n;
}
void renew_alternative_identities(Document &d) {
  for (auto &r : d.resmas) {
    r.id = new_uuid();
    for (auto &l : r.leaves) {
      const auto old = l.id;
      l.id = new_uuid();
      if (old == r.top_id)
        r.top_id = l.id;
    }
  }
}
} // namespace inde::project
