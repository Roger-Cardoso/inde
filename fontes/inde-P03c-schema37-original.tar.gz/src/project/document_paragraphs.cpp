#include "inde/project/document_paragraphs.hpp"
#include "inde/project/project.hpp"
#include <algorithm>
#include <glib.h>
#include <limits>
#include <set>
#include <stdexcept>
#include <unordered_map>
#include <uuid/uuid.h>
namespace inde::project {
namespace {
std::vector<std::size_t> separators(const std::string &s, std::size_t &length) {
  if (s.find('\0') != std::string::npos ||
      !g_utf8_validate(s.data(), s.size(), nullptr))
    throw std::runtime_error("Parágrafos exigem texto UTF-8 válido");
  std::vector<std::size_t> out;
  length = 0;
  for (const char *p = s.data(), *end = p + s.size(); p < end;
       p = g_utf8_next_char(p), ++length)
    if (*p == '\n')
      out.push_back(length);
  return out;
}
void validate_shape(const DocumentParagraphs &s) {
  if (!s.enabled) {
    if (!s.rows.empty() || !s.retired.empty())
      throw std::runtime_error("Estrutura desativada contém identidades");
    return;
  }
  if (s.rows.empty() ||
      s.rows.size() + s.retired.size() > paragraph_identity_limit)
    throw std::runtime_error("Limite de identidades de parágrafos excedido");
  std::set<std::string> ids;
  auto identity = [&](const auto &id) {
    uuid_t parsed;
    if (id.size() != 36 || uuid_parse(id.c_str(), parsed) ||
        !ids.insert(id).second)
      throw std::runtime_error("Identidade de parágrafo inválida/repetida");
  };
  std::size_t next{};
  for (const auto &r : s.rows) {
    identity(r.id);
    if (r.start != next || r.end < r.start ||
        r.end == std::numeric_limits<std::size_t>::max())
      throw std::runtime_error("Partição de parágrafos inválida");
    next = r.end + 1;
  }
  for (const auto &id : s.retired)
    identity(id);
}
DocumentParagraphs partition(const std::vector<std::size_t> &breaks,
                             std::size_t length) {
  DocumentParagraphs out;
  out.enabled = true;
  std::size_t start{};
  for (const auto end : breaks) {
    out.rows.push_back({{}, start, end});
    start = end + 1;
  }
  out.rows.push_back({{}, start, length});
  return out;
}
} // namespace
DocumentParagraphs identify_paragraphs(const std::string &text) {
  std::size_t length;
  const auto breaks = separators(text, length);
  auto result = partition(breaks, length);
  for (auto &r : result.rows)
    r.id = new_uuid();
  validate_shape(result);
  consolidate_paragraphs(result, text);
  return result;
}
bool canonical_paragraphs(const DocumentParagraphs &s) {
  return s.enabled && !s.rows.empty() && bool(s.rows.front().content);
}
std::string render_paragraphs(const DocumentParagraphs &s) {
  if (!canonical_paragraphs(s))
    throw std::runtime_error("Blocos ainda não consolidados");
  std::string out;
  for (const auto &r : s.rows) {
    if (!r.content)
      throw std::runtime_error("Bloco sem conteúdo identificado");
    if (&r != &s.rows.front())
      out += '\n';
    out += *r.content;
  }
  return out;
}
void position_paragraphs(DocumentParagraphs &s) {
  if (!canonical_paragraphs(s))
    throw std::runtime_error("Ordem sem blocos consolidados");
  std::size_t offset = 0;
  for (auto &r : s.rows) {
    if (!r.content || r.content->find('\n') != std::string::npos)
      throw std::runtime_error("Conteúdo de bloco inválido");
    std::size_t length;
    (void)separators(*r.content, length);
    r.start = offset;
    r.end = offset + length;
    offset = r.end + 1;
  }
  validate_shape(s);
}
void consolidate_paragraphs(DocumentParagraphs &s, const std::string &text) {
  validate_paragraphs(s, text);
  if (!s.enabled || canonical_paragraphs(s))
    return;
  std::size_t byte = 0;
  for (auto &r : s.rows) {
    auto end = text.find('\n', byte);
    if (end == std::string::npos)
      end = text.size();
    r.content =
        std::make_shared<const std::string>(text.substr(byte, end - byte));
    byte = end + 1;
  }
}
void validate_paragraphs(const DocumentParagraphs &s, const std::string &text) {
  validate_shape(s);
  if (!s.enabled)
    return;
  const bool canonical = canonical_paragraphs(s);
  for (const auto &r : s.rows)
    if (bool(r.content) != canonical)
      throw std::runtime_error(
          "Mistura de blocos consolidados e offsets legados");
  if (canonical) {
    std::size_t offset = 0;
    for (const auto &r : s.rows) {
      std::size_t n;
      if (!separators(*r.content, n).empty() || r.start != offset ||
          r.end != offset + n)
        throw std::runtime_error("Coordenadas derivadas divergem dos blocos");
      offset = r.end + 1;
    }
    if (render_paragraphs(s) != text)
      throw std::runtime_error(
          "Representação linear diverge dos blocos identificados");
  }
  std::size_t length;
  const auto breaks = separators(text, length);
  if (s.rows.size() != breaks.size() + 1 || s.rows.back().end != length)
    throw std::runtime_error(
        "Parágrafos não correspondem ao texto do Documento");
  for (std::size_t i = 0; i < breaks.size(); ++i)
    if (s.rows[i].end != breaks[i])
      throw std::runtime_error("Limite de parágrafo não corresponde ao texto");
}
DocumentParagraphs edit_paragraphs(const DocumentParagraphs &before,
                                   std::size_t start, std::size_t end,
                                   const std::string &replacement) {
  if (!before.enabled)
    return before;
  validate_shape(before);
  const auto length = before.rows.back().end;
  if (start > end || end > length)
    throw std::runtime_error("Edição fora dos parágrafos");
  std::size_t added;
  const auto inserted_breaks = separators(replacement, added);
  if (added >
      std::numeric_limits<std::size_t>::max() - (length - (end - start)))
    throw std::runtime_error("Extensão de parágrafo excedida");
  if (start == end && added == 0)
    return before;
  const auto mapped = [&](std::size_t p) {
    return p < start ? p : p >= end ? start + added + (p - end) : start;
  };
  std::vector<std::size_t> breaks;
  for (std::size_t i = 0; i + 1 < before.rows.size(); ++i) {
    const auto p = before.rows[i].end;
    if (p < start || p >= end)
      breaks.push_back(mapped(p));
  }
  for (const auto p : inserted_breaks)
    breaks.push_back(start + p);
  std::sort(breaks.begin(), breaks.end());
  auto result = partition(breaks, length - (end - start) + added);
  result.retired = before.retired;
  for (const auto &old : before.rows) {
    std::size_t point{};
    bool survives = true;
    if (old.start < old.end && old.start < start)
      point = old.start;
    else if (old.end > end)
      point = std::max(old.start, end);
    else if (old.start == old.end && !(start <= old.start && old.start < end))
      point = old.start;
    else if (start >= old.start && end <= old.end)
      point = start; // Same structural paragraph, rewritten body.
    else
      survives = false;
    if (!survives) {
      result.retired.push_back(old.id);
      continue;
    }
    const auto p = mapped(point);
    // A caret on the LF belongs to its preceding paragraph.
    const auto at = static_cast<std::size_t>(
        std::lower_bound(breaks.begin(), breaks.end(), p) - breaks.begin());
    auto &target = result.rows.at(at);
    if (target.id.empty())
      target.id = old.id;
    else
      result.retired.push_back(old.id);
  }
  for (auto &r : result.rows)
    if (r.id.empty())
      r.id = new_uuid();
  validate_shape(result);
  if (canonical_paragraphs(before)) {
    auto text = render_paragraphs(before);
    const auto *a = g_utf8_offset_to_pointer(text.data(), start);
    const auto *b = g_utf8_offset_to_pointer(text.data(), end);
    text.replace(a - text.data(), b - a, replacement);
    consolidate_paragraphs(result, text);
    // Untouched content retains its allocation across edits and history.
    std::unordered_map<std::string, const DocumentParagraph *> old_rows;
    for (const auto &r : before.rows)
      old_rows.emplace(r.id, &r);
    for (auto &r : result.rows)
      if (auto i = old_rows.find(r.id);
          i != old_rows.end() && *r.content == *i->second->content)
        r.content = i->second->content;
  }
  return result;
}
} // namespace inde::project
