#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_30=R"sql(
CREATE UNIQUE INDEX contextual_participation_owner ON contextual_participations(id,project_id,work_id,plan_id);
CREATE TABLE contextual_slots (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,
 title TEXT NOT NULL CHECK(length(trim(title))>0 AND length(title)<=200),selected_option_id TEXT,
 UNIQUE(id,project_id,work_id,plan_id),
 FOREIGN KEY(plan_id,project_id,work_id) REFERENCES contextual_plans(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(selected_option_id,project_id,work_id,plan_id,id) REFERENCES contextual_options(id,project_id,work_id,plan_id,slot_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_options (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,slot_id TEXT NOT NULL,
 title TEXT NOT NULL CHECK(length(trim(title))>0 AND length(title)<=200),
 UNIQUE(id,project_id,work_id,plan_id),UNIQUE(id,project_id,work_id,plan_id,slot_id),
 FOREIGN KEY(slot_id,project_id,work_id,plan_id) REFERENCES contextual_slots(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_option_members (
 participation_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,option_id TEXT NOT NULL,
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(option_id,project_id,work_id,plan_id) REFERENCES contextual_options(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_declarations (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,participation_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN('fact','intention','knowledge','belief','report')),
 label TEXT NOT NULL CHECK(length(trim(label))>0 AND length(label)<=200),value TEXT NOT NULL CHECK(length(value)<=4096),
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_dependencies (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,source_id TEXT NOT NULL,target_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN('succession','cause','motivation','condition','context')),
 note TEXT NOT NULL CHECK(length(note)<=2048),CHECK(source_id<>target_id),UNIQUE(source_id,target_id,kind),
 FOREIGN KEY(source_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(target_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_text_links (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,participation_id TEXT NOT NULL,document_id TEXT NOT NULL,
 observed_sha TEXT NOT NULL CHECK(length(observed_sha)=64),note TEXT NOT NULL DEFAULT '' CHECK(length(note)<=2048),UNIQUE(participation_id,document_id),
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(document_id,project_id) REFERENCES documents(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_slots_plan ON contextual_slots(plan_id,id);
CREATE INDEX contextual_options_plan ON contextual_options(plan_id,slot_id,id);
CREATE INDEX contextual_members_plan ON contextual_option_members(plan_id,option_id);
CREATE INDEX contextual_declarations_plan ON contextual_declarations(plan_id,participation_id,id);
CREATE INDEX contextual_dependencies_plan ON contextual_dependencies(plan_id,target_id,source_id);
CREATE INDEX contextual_dependencies_source ON contextual_dependencies(source_id,target_id);
CREATE INDEX contextual_text_links_plan ON contextual_text_links(plan_id,participation_id,id);
CREATE INDEX contextual_text_links_document ON contextual_text_links(document_id);
)sql";
}
