#include "inde/persistence/paragraph_codec.hpp"
#include "inde/persistence/json.hpp"
#include <limits>
#include <map>
#include <stdexcept>
namespace inde::persistence {
namespace {
std::size_t offset(const json::Value &v) {
  const auto n = v.as_integer();
  if (n < 0)
    throw std::runtime_error("Offset negativo de parágrafo");
  return static_cast<std::size_t>(n);
}
} // namespace
std::string encode_paragraphs(const project::DocumentParagraphs &s,
                              bool legacy) {
  if (s.rows.size() + s.retired.size() > project::paragraph_identity_limit)
    throw std::runtime_error("Estrutura de parágrafos excedida");
  json::Value::Array rows, retired, blocks, order;
  const bool canonical = !legacy && project::canonical_paragraphs(s);
  for (const auto &r : s.rows) {
    if (r.end >
        static_cast<std::size_t>(std::numeric_limits<std::int64_t>::max()))
      throw std::runtime_error("Offset de parágrafo excedido");
    rows.emplace_back(
        json::Value::Object{{"id", r.id},
                            {"start", static_cast<std::int64_t>(r.start)},
                            {"end", static_cast<std::int64_t>(r.end)}});
    if (canonical) {
      if (!r.content)
        throw std::runtime_error("Bloco incompleto na serialização");
      blocks.emplace_back(
          json::Value::Object{{"id", r.id}, {"text", *r.content}});
      order.emplace_back(r.id);
    }
  }
  for (const auto &id : s.retired)
    retired.emplace_back(id);
  auto out = json::serialize(
      canonical
          ? json::Value(json::Value::Object{{"version", 2},
                                            {"enabled", s.enabled},
                                            {"blocks", std::move(blocks)},
                                            {"order", std::move(order)},
                                            {"retired", std::move(retired)}})
          : json::Value(json::Value::Object{{"version", 1},
                                            {"enabled", s.enabled},
                                            {"rows", std::move(rows)},
                                            {"retired", std::move(retired)}}),
      false);
  if (out.size() > 32 * 1024 * 1024)
    throw std::runtime_error("Payload de parágrafos excedido");
  return out;
}
project::DocumentParagraphs decode_paragraphs(const std::string &s) {
  if (s.size() > 32 * 1024 * 1024)
    throw std::runtime_error("Payload de parágrafos excedido");
  bool quoted{}, escaped{};
  int depth{};
  for (const char ch : s) {
    if (quoted) {
      if (escaped)
        escaped = false;
      else if (ch == '\\')
        escaped = true;
      else if (ch == '"')
        quoted = false;
    } else if (ch == '"')
      quoted = true;
    else if (ch == '[' || ch == '{') {
      if (++depth > 3)
        throw std::runtime_error("Estrutura de parágrafos profunda demais");
    } else if (ch == ']' || ch == '}')
      --depth;
  }
  const auto v = json::parse(s);
  const auto version = v.at("version").as_integer();
  if ((version != 1 && version != 2) ||
      v.as_object().size() != (version == 1 ? 4 : 5))
    throw std::runtime_error("Versão/campos de parágrafos incompatíveis");
  project::DocumentParagraphs out;
  out.enabled = v.at("enabled").as_boolean();
  if (version == 1)
    for (const auto &r : v.at("rows").as_array()) {
      if (out.rows.size() >= project::paragraph_identity_limit ||
          r.as_object().size() != 3)
        throw std::runtime_error("Coleção de parágrafos incompatível");
      out.rows.push_back(
          {r.at("id").as_string(), offset(r.at("start")), offset(r.at("end"))});
    }
  if (version == 2) {
    if (!out.enabled)
      throw std::runtime_error("Blocos consolidados desativados");
    std::map<std::string, std::shared_ptr<const std::string>> blocks;
    for (const auto &r : v.at("blocks").as_array()) {
      if (blocks.size() >= project::paragraph_identity_limit ||
          r.as_object().size() != 2 ||
          !blocks
               .emplace(r.at("id").as_string(),
                        std::make_shared<const std::string>(
                            r.at("text").as_string()))
               .second)
        throw std::runtime_error(
            "Identidades/conteúdos de bloco incompatíveis");
    }
    for (const auto &id : v.at("order").as_array()) {
      auto i = blocks.find(id.as_string());
      if (i == blocks.end())
        throw std::runtime_error("Ordem contém bloco ausente ou repetido");
      out.rows.push_back({i->first, 0, 0, i->second});
      blocks.erase(i);
    }
    if (!blocks.empty())
      throw std::runtime_error("Bloco sem posição na sequência");
    project::position_paragraphs(out);
  }
  for (const auto &r : v.at("retired").as_array()) {
    if (out.rows.size() + out.retired.size() >=
        project::paragraph_identity_limit)
      throw std::runtime_error("Coleção de identidades retiradas excedida");
    out.retired.push_back(r.as_string());
  }
  if (version == 2)
    project::validate_paragraphs(out, project::render_paragraphs(out));
  return out;
}
} // namespace inde::persistence
