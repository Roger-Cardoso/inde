#include "inde/persistence/alternatives_codec.hpp"
#include "inde/persistence/json.hpp"
#include "inde/project/document_alternatives.hpp"
#include <limits>
#include <stdexcept>
namespace inde::persistence {
namespace {
using json::Value;
std::int64_t number(std::size_t v) {
  if (v > static_cast<std::size_t>(std::numeric_limits<std::int64_t>::max()))
    throw std::runtime_error("Offset excedido");
  return v;
}
std::size_t offset(const Value &v) {
  auto n = v.as_integer();
  if (n < 0)
    throw std::runtime_error("Offset negativo");
  return n;
}
void bound(const std::string &s) {
  if (s.size() > 32 * 1024 * 1024)
    throw std::runtime_error("Payload de alternativas excedido");
  bool quoted{}, escaped{};
  int depth{};
  for (char c : s) {
    if (quoted) {
      if (escaped)
        escaped = false;
      else if (c == '\\')
        escaped = true;
      else if (c == '"')
        quoted = false;
    } else if (c == '"')
      quoted = true;
    else if (c == '{' || c == '[') {
      if (++depth > 8)
        throw std::runtime_error("Alternativas profundas demais");
    } else if (c == '}' || c == ']')
      --depth;
  }
}
} // namespace
std::string
encode_alternatives(const std::vector<project::DocumentResma> &rows) {
  Value::Array resmas;
  for (const auto &r : rows) {
    Value::Array leaves;
    for (const auto &l : r.leaves) {
      Value payload(nullptr);
      if (l.covered) {
        Value::Array styles;
        for (const auto &f : l.covered->formatting)
          styles.emplace_back(
              Value::Object{{"style", project::to_string(f.style)},
                            {"start", number(f.start_offset)},
                            {"end", number(f.end_offset)},
                            {"value", f.value}});
        payload = Value::Object{{"text", l.covered->text},
                                {"formatting", std::move(styles)}};
      }
      leaves.emplace_back(Value::Object{
          {"id", l.id}, {"label", l.label}, {"covered", std::move(payload)}});
    }
    resmas.emplace_back(Value::Object{{"id", r.id},
                                      {"label", r.label},
                                      {"top", r.top_id},
                                      {"start", number(r.start)},
                                      {"end", number(r.end)},
                                      {"leaves", std::move(leaves)}});
  }
  auto s = json::serialize(
      Value::Object{{"version", 1}, {"resmas", std::move(resmas)}}, false);
  bound(s);
  return s;
}
std::vector<project::DocumentResma> decode_alternatives(const std::string &s) {
  bound(s);
  auto v = json::parse(s);
  if (v.as_object().size() != 2 || v.at("version").as_integer() != 1)
    throw std::runtime_error("Versão/campos de alternativas incompatíveis");
  std::vector<project::DocumentResma> result;
  for (const auto &r : v.at("resmas").as_array()) {
    if (result.size() >= project::document_resma_limit ||
        r.as_object().size() != 6)
      throw std::runtime_error("Coleção de resmas inválida");
    project::DocumentResma row{
        r.at("id").as_string(),  r.at("label").as_string(),
        r.at("top").as_string(), offset(r.at("start")),
        offset(r.at("end")),     {}};
    for (const auto &l : r.at("leaves").as_array()) {
      if (row.leaves.size() >= project::resma_leaf_limit ||
          l.as_object().size() != 3)
        throw std::runtime_error("Coleção de folhas inválida");
      project::DocumentLeaf leaf{
          l.at("id").as_string(), l.at("label").as_string(), {}};
      const auto &p = l.at("covered");
      if (!p.is_null()) {
        if (p.as_object().size() != 2)
          throw std::runtime_error("Campos de folha incompatíveis");
        auto body = std::make_shared<project::DocumentLeafContent>();
        body->text = p.at("text").as_string();
        for (const auto &f : p.at("formatting").as_array()) {
          if (body->formatting.size() >= 100000 || f.as_object().size() != 4)
            throw std::runtime_error(
                "Estilos encobertos excedidos/incompatíveis");
          body->formatting.push_back({project::document_text_style_from_string(
                                          f.at("style").as_string()),
                                      offset(f.at("start")),
                                      offset(f.at("end")),
                                      f.at("value").as_string()});
        }
        leaf.covered = std::move(body);
      }
      row.leaves.push_back(std::move(leaf));
    }
    result.push_back(std::move(row));
  }
  return result;
}
} // namespace inde::persistence
