#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_29 = R"sql(
CREATE TABLE contextual_plans (
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, work_id TEXT NOT NULL,
 title TEXT NOT NULL CHECK(length(trim(title))>0 AND length(title)<=200),
 UNIQUE(id,project_id,work_id),
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(work_id) REFERENCES works(id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_plans_work ON contextual_plans(project_id,work_id,id);
CREATE TABLE contextual_moments (
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, work_id TEXT NOT NULL,
 title TEXT NOT NULL DEFAULT '' CHECK(length(title)<=200),
 description TEXT NOT NULL DEFAULT '' CHECK(length(description)<=4096),
 token TEXT NOT NULL CHECK(length(token)>0),
 CHECK(length(trim(title))>0 OR length(trim(description))>0),
 UNIQUE(id,project_id,work_id),
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(work_id) REFERENCES works(id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_moments_work ON contextual_moments(project_id,work_id,id);
CREATE TABLE contextual_participations (
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, work_id TEXT NOT NULL,
 plan_id TEXT NOT NULL, moment_id TEXT NOT NULL,
 position INTEGER NOT NULL CHECK(position>=0),
 note TEXT NOT NULL DEFAULT '' CHECK(length(note)<=4096),
 FOREIGN KEY(plan_id,project_id,work_id) REFERENCES contextual_plans(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(moment_id,project_id,work_id) REFERENCES contextual_moments(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_participations_plan ON contextual_participations(plan_id,position,id);
CREATE INDEX contextual_participations_moment ON contextual_participations(moment_id,plan_id,id);
)sql";
}
