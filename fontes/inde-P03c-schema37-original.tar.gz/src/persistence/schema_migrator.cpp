#include "inde/persistence/schema_migrator.hpp"

#include "schema_sql_v01_v04.hpp"
#include "schema_sql_v05_v11.hpp"
#include "schema_sql_v12_v15.hpp"
#include "schema_sql_v16.hpp"
#include "schema_sql_v17.hpp"
#include "schema_sql_v18.hpp"
#include "schema_sql_v19.hpp"
#include "schema_sql_v20.hpp"
#include "schema_sql_v21.hpp"
#include "schema_sql_v22.hpp"
#include "schema_sql_v23.hpp"
#include "schema_sql_v24.hpp"
#include "schema_sql_v25.hpp"
#include "schema_sql_v26.hpp"
#include "schema_sql_v27.hpp"
#include "schema_sql_v28.hpp"
#include "schema_sql_v29.hpp"
#include "schema_sql_v30.hpp"
#include "schema_sql_v31.hpp"
#include "schema_sql_v32.hpp"
#include "schema_sql_v33.hpp"
#include "schema_sql_v34.hpp"
#include "schema_sql_v35.hpp"
#include "schema_sql_v36.hpp"

#include "inde/persistence/sqlite_database.hpp"
#include "inde/persistence/paragraph_codec.hpp"

#include <stdexcept>

namespace inde::persistence {
namespace {


constexpr auto create_migration_table = R"sql(
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY CHECK (version > 0),
  applied_at TEXT NOT NULL CHECK (length(applied_at) > 0)
)
)sql";















} // namespace

void SchemaMigrator::migrate(SqliteDatabase &database) const {
  SqliteTransaction transaction(database);
  database.execute(create_migration_table);

  const int version = current_version(database);
  if (version > current_database_schema_version) {
    throw std::runtime_error(
        "O banco do projeto foi criado por uma versão mais nova do INDE");
  }

  if (version < 1) {
    apply_version_1(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{1});
    record.run();
  }

  if (version < 2) {
    apply_version_2(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{2});
    record.run();
  }

  if (version < 3) {
    apply_version_3(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{3});
    record.run();
  }

  if (version < 4) {
    apply_version_4(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{4});
    record.run();
  }

  if (version < 5) {
    apply_version_5(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{5});
    record.run();
  }

  if (version < 6) {
    apply_version_6(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{6});
    record.run();
  }

  if (version < 7) {
    apply_version_7(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{7});
    record.run();
  }

  if (version < 8) {
    apply_version_8(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{8});
    record.run();
  }

  if (version < 9) {
    apply_version_9(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{9});
    record.run();
  }

  if (version < 10) {
    apply_version_10(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{10});
    record.run();
  }

  if (version < 11) {
    apply_version_11(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{11});
    record.run();
  }

  if (version < 12) {
    apply_version_12(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.bind(1, std::int64_t{12});
    record.run();
  }

  if (version < 13) {
    apply_version_13(database);
    auto record =
        database.prepare("INSERT INTO schema_migrations(version, applied_at) "
                         "VALUES (13, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
    record.run();
  }

  if (version < 14) {
    apply_version_14(database);
    database.execute("INSERT INTO schema_migrations(version, applied_at) "
                     "VALUES (14, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
  }

  if (version < 15) {
    apply_version_15(database);
    database.execute("INSERT INTO schema_migrations(version, applied_at) "
                     "VALUES (15, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))");
  }

  if (version < 16) {
    apply_version_16(database);
    auto record=database.prepare("INSERT INTO schema_migrations(version,applied_at) VALUES(16,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
    record.run();
  }
  if (version < 17) {
    apply_version_17(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(17,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 18) {
    apply_version_18(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(18,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 19) {
    apply_version_19(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(19,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 20) {
    apply_version_20(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(20,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 21) {
    apply_version_21(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(21,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 22) {
    apply_version_22(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(22,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if (version < 23) {
    apply_version_23(database);
    database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(23,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
  }
  if(version<24){apply_version_24(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(24,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<25){apply_version_25(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(25,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<26){apply_version_26(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(26,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<27){apply_version_27(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(27,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<28){apply_version_28(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(28,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<29){apply_version_29(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(29,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<30){apply_version_30(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(30,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<31){apply_version_31(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(31,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<32){apply_version_32(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(32,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<33){apply_version_33(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(33,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<34){apply_version_34(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(34,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<35){apply_version_35(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(35,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<36){apply_version_36(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(36,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  if(version<37){apply_version_37(database);database.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(37,strftime('%Y-%m-%dT%H:%M:%fZ','now'))");}
  transaction.commit();
}

void SchemaMigrator::apply_version_37(SqliteDatabase &database) {
  std::vector<std::string> ids;
  {
    auto rows=database.prepare("SELECT document_id FROM document_paragraph_structures ORDER BY document_id");
    while(rows.step())ids.push_back(rows.column_text(0));
  }
  // Keep at most one document payload in memory; the outer migration remains
  // one atomic transaction, including any late validation/trigger failure.
  for (const auto &id : ids) {
    auto row=database.prepare("SELECT p.payload,d.content FROM document_paragraph_structures p JOIN documents d ON d.id=p.document_id AND d.project_id=p.project_id WHERE p.document_id=?");
    row.bind(1,id);
    if(!row.step())throw std::runtime_error("Estrutura de bloco sem Documento na migração37");
    auto structure=decode_paragraphs(row.column_text(0));
    project::consolidate_paragraphs(structure,row.column_text(1));
    const auto payload=encode_paragraphs(structure);
    auto update = database.prepare("UPDATE document_paragraph_structures SET payload=? WHERE document_id=?");
    update.bind(1,payload); update.bind(2,id); update.run();
  }
}

int SchemaMigrator::current_version(SqliteDatabase &database) const {
  auto exists =
      database.prepare("SELECT count(*) FROM sqlite_master "
                       "WHERE type = 'table' AND name = 'schema_migrations'");
  if (!exists.step() || exists.column_integer(0) == 0) {
    return 0;
  }

  return static_cast<int>(database.query_integer(
      "SELECT COALESCE(MAX(version), 0) FROM schema_migrations"));
}

void SchemaMigrator::apply_version_26(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_26);
}
void SchemaMigrator::apply_version_27(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_27);
}
void SchemaMigrator::apply_version_28(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_28);
}
void SchemaMigrator::apply_version_29(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_29);
}
void SchemaMigrator::apply_version_30(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_30);
}
void SchemaMigrator::apply_version_31(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_31);
}
void SchemaMigrator::apply_version_32(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_32);
}
void SchemaMigrator::apply_version_33(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_33);
}
void SchemaMigrator::apply_version_35(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_35);
}
void SchemaMigrator::apply_version_36(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_36);
}
void SchemaMigrator::apply_version_34(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_34);
}

void SchemaMigrator::apply_version_1(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_1);
}

void SchemaMigrator::apply_version_2(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_2);
}

void SchemaMigrator::apply_version_3(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_3);
}

void SchemaMigrator::apply_version_4(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_4);
}

void SchemaMigrator::apply_version_5(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_5);
}

void SchemaMigrator::apply_version_6(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_6);
}

void SchemaMigrator::apply_version_7(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_7);
}

void SchemaMigrator::apply_version_8(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_8);
}

void SchemaMigrator::apply_version_9(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_9);
}

void SchemaMigrator::apply_version_10(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_10);
}

void SchemaMigrator::apply_version_11(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_11);
}

void SchemaMigrator::apply_version_12(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_12);
}

void SchemaMigrator::apply_version_13(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_13);
}

void SchemaMigrator::apply_version_14(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_14);
}

void SchemaMigrator::apply_version_15(SqliteDatabase &database) {
  database.execute(schema_sql::schema_version_15);
}
void SchemaMigrator::apply_version_16(SqliteDatabase &database) { database.execute(schema_sql::schema_version_16); }
void SchemaMigrator::apply_version_17(SqliteDatabase &database) { database.execute(schema_sql::schema_version_17); }
void SchemaMigrator::apply_version_18(SqliteDatabase &database) { database.execute(schema_sql::schema_version_18); }
void SchemaMigrator::apply_version_19(SqliteDatabase &database) { database.execute(schema_sql::schema_version_19); }
void SchemaMigrator::apply_version_20(SqliteDatabase &database) { database.execute(schema_sql::schema_version_20); }
void SchemaMigrator::apply_version_21(SqliteDatabase &database) { database.execute(schema_sql::schema_version_21); }
void SchemaMigrator::apply_version_22(SqliteDatabase &database) { database.execute(schema_sql::schema_version_22); }
void SchemaMigrator::apply_version_23(SqliteDatabase &database) { database.execute(schema_sql::schema_version_23); }
void SchemaMigrator::apply_version_24(SqliteDatabase &database) { database.execute(schema_sql::schema_version_24); }
void SchemaMigrator::apply_version_25(SqliteDatabase &database) { database.execute(schema_sql::schema_version_25); }

} // namespace inde::persistence
