#include "contextual_containment.hpp"
#include "inde/persistence/sqlite_database.hpp"
#include <algorithm>
#include <map>
#include <queue>
#include <stdexcept>
#include <vector>
namespace inde::persistence {
void validate_contextual_containment(SqliteDatabase &db,
                                     const std::string &work) {
  // Bounded DAG traversal. Do not enumerate potentially exponential paths.
  auto q = db.prepare(
      "SELECT x.plan_id,u.contents_plan_id FROM contextual_participations x "
      "JOIN contextual_modules u ON u.moment_id=x.moment_id "
      "WHERE x.work_id=? AND u.contents_plan_id IS NOT NULL");
  q.bind(1, work);
  std::map<std::string, std::vector<std::string>> edges;
  std::map<std::string, std::size_t> incoming, depth;
  std::size_t count{};
  while (q.step()) {
    if (++count > 16000)
      throw std::runtime_error(
          "Contenção excederia 16.000 usos compostos; nada foi confirmado");
    const auto from = q.column_text(0), to = q.column_text(1);
    edges[from].push_back(to);
    incoming.try_emplace(from, 0);
    ++incoming[to];
    if (incoming.size() > 200)
      throw std::runtime_error(
          "Mais de 200 interiores/composições; nada foi confirmado");
  }
  std::queue<std::string> ready;
  for (const auto &[id, n] : incoming)
    if (!n) {
      ready.push(id);
      depth[id] = 0;
    }
  std::size_t seen{};
  while (!ready.empty()) {
    const auto id = ready.front();
    ready.pop();
    ++seen;
    for (const auto &child : edges[id]) {
      depth[child] = std::max(depth[child], depth[id] + 1);
      if (depth[child] > 16)
        throw std::runtime_error(
            "Interior excederia 16 níveis; nada foi confirmado");
      if (--incoming[child] == 0)
        ready.push(child);
    }
  }
  if (seen != incoming.size())
    throw std::runtime_error("Um trecho não pode conter a si mesmo, nem por "
                             "outros trechos. Nada foi confirmado");
}
} // namespace inde::persistence
