#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_31 = R"sql(
CREATE TABLE contextual_references (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,participation_id TEXT NOT NULL,
 entity_id TEXT,relation_id TEXT,unit_id TEXT,line_id TEXT,reference_id TEXT,point_id TEXT,map_id TEXT,
 note TEXT NOT NULL CHECK(length(note)<=2048),
 CHECK((entity_id IS NOT NULL)+(relation_id IS NOT NULL)+(unit_id IS NOT NULL)+(line_id IS NOT NULL)+(reference_id IS NOT NULL)+(point_id IS NOT NULL)+(map_id IS NOT NULL)=1),
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(entity_id,project_id) REFERENCES entities(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(relation_id,project_id) REFERENCES relations(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(unit_id,project_id) REFERENCES narrative_units(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(line_id,project_id) REFERENCES narrative_lines(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(reference_id,project_id) REFERENCES temporal_references(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(point_id,project_id) REFERENCES fictional_time_points(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(map_id,project_id) REFERENCES cartographic_planets(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_references_plan ON contextual_references(plan_id,participation_id,id);
CREATE UNIQUE INDEX contextual_reference_once ON contextual_references(participation_id,coalesce(entity_id,relation_id,unit_id,line_id,reference_id,point_id,map_id));
CREATE INDEX contextual_references_entity ON contextual_references(entity_id,id);
CREATE INDEX contextual_references_relation ON contextual_references(relation_id,id);
CREATE INDEX contextual_references_unit ON contextual_references(unit_id,id);
CREATE INDEX contextual_references_line ON contextual_references(line_id,id);
CREATE INDEX contextual_references_time ON contextual_references(reference_id,id);
CREATE INDEX contextual_references_point ON contextual_references(point_id,id);
CREATE INDEX contextual_references_map ON contextual_references(map_id,id);
CREATE TABLE contextual_bridges (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,target_id TEXT NOT NULL,
 source_plan_id TEXT NOT NULL,source_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN('context','succession','cause','motivation','condition')),
 note TEXT NOT NULL CHECK(length(note)<=2048),CHECK(plan_id<>source_plan_id),UNIQUE(source_id,target_id,kind),
 FOREIGN KEY(target_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(source_id,project_id,work_id,source_plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_bridges_target ON contextual_bridges(plan_id,target_id,id);
CREATE INDEX contextual_bridges_source ON contextual_bridges(source_plan_id,source_id,id);
CREATE TABLE contextual_text_targets (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,participation_id TEXT NOT NULL,
 document_id TEXT,anchor_id TEXT,composition_id TEXT,occurrence_id TEXT,
 observed_sha TEXT NOT NULL CHECK(length(observed_sha)=64),note TEXT NOT NULL DEFAULT '' CHECK(length(note)<=2048),
 CHECK((document_id IS NOT NULL AND anchor_id IS NOT NULL AND composition_id IS NULL AND occurrence_id IS NULL) OR (document_id IS NULL AND anchor_id IS NULL AND composition_id IS NOT NULL AND occurrence_id IS NOT NULL)),
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(document_id,project_id) REFERENCES documents(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(composition_id,project_id) REFERENCES compositions(id,project_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE UNIQUE INDEX contextual_text_anchor ON contextual_text_targets(participation_id,document_id,anchor_id) WHERE document_id IS NOT NULL;
CREATE UNIQUE INDEX contextual_text_occurrence ON contextual_text_targets(participation_id,composition_id,occurrence_id) WHERE composition_id IS NOT NULL;
CREATE INDEX contextual_text_targets_plan ON contextual_text_targets(plan_id,participation_id,id);
CREATE INDEX contextual_text_targets_document ON contextual_text_targets(document_id);
CREATE INDEX contextual_text_targets_composition ON contextual_text_targets(composition_id,occurrence_id);
)sql";
}
