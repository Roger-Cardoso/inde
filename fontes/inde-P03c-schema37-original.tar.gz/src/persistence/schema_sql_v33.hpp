#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_33 = R"sql(
CREATE TABLE contextual_visual_items (
 id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,
 participation_id TEXT UNIQUE,
 kind TEXT NOT NULL CHECK(kind IN('block','lane','marker')),
 label TEXT NOT NULL DEFAULT '' CHECK(length(label)<=200),
 color TEXT NOT NULL CHECK(length(color)=7 AND color GLOB '#[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]'),
 shape TEXT NOT NULL CHECK(shape IN('box','straight','ecg','wavy')),
 x INTEGER NOT NULL CHECK(x BETWEEN -100000 AND 100000),
 y INTEGER NOT NULL CHECK(y BETWEEN -100000 AND 100000),
 width INTEGER NOT NULL CHECK(width BETWEEN 80 AND 20000),
 height INTEGER NOT NULL CHECK(height BETWEEN 64 AND 4000),
 c0 INTEGER NOT NULL CHECK(c0 BETWEEN 0 AND 1000),
 c1 INTEGER NOT NULL CHECK(c1 BETWEEN 0 AND 1000),
 c2 INTEGER NOT NULL CHECK(c2 BETWEEN 0 AND 1000),
 c3 INTEGER NOT NULL CHECK(c3 BETWEEN 0 AND 1000),
 c4 INTEGER NOT NULL CHECK(c4 BETWEEN 0 AND 1000),
 expanded INTEGER NOT NULL DEFAULT 0 CHECK(expanded IN(0,1)),
 CHECK((kind='block' AND participation_id IS NOT NULL) OR (kind!='block' AND participation_id IS NULL)),
 FOREIGN KEY(plan_id,project_id,work_id) REFERENCES contextual_plans(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_visual_plan ON contextual_visual_items(plan_id,id);
)sql";
}
