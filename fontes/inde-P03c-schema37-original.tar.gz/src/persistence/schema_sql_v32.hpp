#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_32 = R"sql(
CREATE TABLE contextual_modules (
 moment_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,
 contents_plan_id TEXT UNIQUE,
 scale TEXT NOT NULL DEFAULT '' CHECK(length(scale)<=80),
 FOREIGN KEY(moment_id,project_id,work_id) REFERENCES contextual_moments(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(contents_plan_id,project_id,work_id) REFERENCES contextual_plans(id,project_id,work_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE contextual_roles (
 participation_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,work_id TEXT NOT NULL,plan_id TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT '' CHECK(length(category)<=80),
 parallel INTEGER NOT NULL DEFAULT 0 CHECK(parallel IN(0,1)),
 FOREIGN KEY(participation_id,project_id,work_id,plan_id) REFERENCES contextual_participations(id,project_id,work_id,plan_id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED
);
CREATE INDEX contextual_roles_plan ON contextual_roles(plan_id,participation_id);
)sql";
}
