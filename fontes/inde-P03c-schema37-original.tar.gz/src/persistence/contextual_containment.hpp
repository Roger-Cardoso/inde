#pragma once
#include <string>
namespace inde::persistence {
class SqliteDatabase;
// Shared by authored commands and history simulation/confirmation.
void validate_contextual_containment(SqliteDatabase &, const std::string &work);
} // namespace inde::persistence
