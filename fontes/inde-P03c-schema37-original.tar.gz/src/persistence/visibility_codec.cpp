#include "inde/persistence/visibility_codec.hpp"
#include "inde/persistence/json.hpp"
#include <stdexcept>
namespace inde::persistence {
namespace {
using json::Value;
void bounded(const std::string &s) {
  if (s.size() > 2 * 1024 * 1024)
    throw std::runtime_error("Perfis excedem2MiB");
  bool quoted{}, escaped{};
  int depth{};
  for (char c : s) {
    if (quoted) {
      if (escaped)
        escaped = false;
      else if (c == '\\')
        escaped = true;
      else if (c == '"')
        quoted = false;
    } else if (c == '"')
      quoted = true;
    else if (c == '{' || c == '[') {
      if (++depth > 6)
        throw std::runtime_error("Perfis profundos demais");
    } else if (c == '}' || c == ']')
      --depth;
  }
}
Value rules(const std::vector<project::VisibilityRule> &v) {
  Value::Array out;
  for (const auto &r : v)
    out.emplace_back(
        Value::Object{{"kind", project::to_string(r.kind)}, {"key", r.key}});
  return out;
}
std::vector<project::VisibilityRule> read_rules(const Value &v) {
  std::vector<project::VisibilityRule> out;
  for (const auto &r : v.as_array()) {
    if (out.size() >= project::visibility_rule_limit ||
        r.as_object().size() != 2)
      throw std::runtime_error("Critérios de perfil excedidos/incompatíveis");
    out.push_back({project::visibility_rule_kind(r.at("kind").as_string()),
                   r.at("key").as_string()});
  }
  return out;
}
} // namespace
std::string
encode_visibility(const std::vector<project::VisibilityProfile> &v) {
  project::validate_visibility_profiles(v);
  Value::Array out;
  for (const auto &p : v)
    out.emplace_back(Value::Object{{"id", p.id},
                                   {"name", p.name},
                                   {"all", p.include_all},
                                   {"include", rules(p.include)},
                                   {"exclude", rules(p.exclude)}});
  auto s = json::serialize(
      Value::Object{{"version", 1}, {"profiles", std::move(out)}}, false);
  bounded(s);
  return s;
}
std::vector<project::VisibilityProfile>
decode_visibility(const std::string &s) {
  bounded(s);
  const auto v = json::parse(s);
  if (v.as_object().size() != 2 || v.at("version").as_integer() != 1)
    throw std::runtime_error("Perfis de visibilidade incompatíveis");
  std::vector<project::VisibilityProfile> out;
  for (const auto &p : v.at("profiles").as_array()) {
    if (out.size() >= project::visibility_profile_limit ||
        p.as_object().size() != 5)
      throw std::runtime_error("Coleção de perfis incompatível");
    out.push_back({p.at("id").as_string(), p.at("name").as_string(),
                   p.at("all").as_boolean(), read_rules(p.at("include")),
                   read_rules(p.at("exclude"))});
  }
  project::validate_visibility_profiles(out);
  return out;
}
} // namespace inde::persistence
