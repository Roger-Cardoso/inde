#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_36=R"sql(
CREATE TABLE document_visibility_profiles (
 document_id TEXT NOT NULL PRIMARY KEY,
 project_id TEXT NOT NULL,
 payload TEXT NOT NULL CHECK(length(CAST(payload AS BLOB))<=2097152),
 FOREIGN KEY(document_id,project_id) REFERENCES documents(id,project_id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);
)sql";
}
