#pragma once
namespace inde::persistence::schema_sql {
inline constexpr auto schema_version_34 = R"sql(
CREATE TABLE document_paragraph_structures (
 document_id TEXT PRIMARY KEY,
 project_id TEXT NOT NULL,
 payload TEXT NOT NULL CHECK(length(CAST(payload AS BLOB))<=33554432),
 FOREIGN KEY(document_id,project_id) REFERENCES documents(id,project_id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);
)sql";
}
