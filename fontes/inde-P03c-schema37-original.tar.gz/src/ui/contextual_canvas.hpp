#pragma once
#include "inde/application/contextual_planning.hpp"
#include <array>
#include <gtkmm.h>
#include <map>
#include <optional>
#include <set>

namespace inde::ui {
class ContextualCanvas final : public Gtk::DrawingArea {
public:
  ContextualCanvas();
  void set_data(const application::ContextualSnapshot &);
  void preview_layout(const std::vector<application::ContextualVisualItem> &v) {
    items_ = v;
    queue_draw();
  }
  void select_lane_contents();
  bool selected_lane() const;
  void context_target(double x, double y, Gdk::ModifierType mods) {
    choose(x, y, (static_cast<unsigned>(mods) & GDK_SHIFT_MASK) != 0);
  }
  void set_included(const std::vector<std::string> &ids) { included_=std::set<std::string>(ids.begin(),ids.end());queue_draw(); }
  void select_part(const std::string &);
  void fit(bool selected_only = false);
  void zoom(double factor);
  std::array<double, 3> camera() const { return {camera_x_, camera_y_, zoom_}; }
  void camera(const std::array<double, 3> &);
  const std::vector<application::ContextualVisualItem> &items() const {
    return items_;
  }
  const std::set<std::string> &selection() const { return selection_; }
  std::vector<std::string> selected_parts() const;
  void set_preview(const std::string &,
                   const application::ContextualSnapshot &);
  std::array<double, 2> insertion() const { return {pointer_x_, pointer_y_}; }
  sigc::signal<void()> selection_changed, capture_requested, open_requested,
      properties_requested, group_requested, expand_requested;
  sigc::signal<void(const std::vector<application::ContextualVisualItem> &)>
      committed;

private:
  void draw(const Cairo::RefPtr<Cairo::Context> &, int, int);
  void choose(double, double, bool);
  std::string hit(double, double) const;
  void begin(double, double, bool, bool);
  void update(double, double);
  void finish();
  bool key(guint, Gdk::ModifierType);
  void notify();
  double wx(double x) const { return x / zoom_ + camera_x_; }
  double wy(double y) const { return y / zoom_ + camera_y_; }
  std::vector<application::ContextualVisualItem> items_, before_;
  std::vector<std::string> tab_order_;
  std::map<std::string, application::ContextualParticipation> parts_;
  std::map<std::string, std::vector<std::string>> previews_;
  std::vector<application::ContextualDependency> edges_;
  std::set<std::string> selection_;
  std::set<std::string> included_;
  std::string plan_, drag_id_, hovered_;
  double camera_x_{}, camera_y_{}, zoom_{1}, start_x_{}, start_y_{},
      old_camera_x_{}, old_camera_y_{}, pointer_x_{40}, pointer_y_{60}, dx_{},
      dy_{};
  bool pan_{}, rubber_{}, resize_{}, changed_{}, dragging_{};
  int handle_{-1};
  std::optional<double> snap_x_, snap_y_;
};
} // namespace inde::ui
