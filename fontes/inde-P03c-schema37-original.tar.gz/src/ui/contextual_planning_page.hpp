#pragma once
#include "inde/application/contextual_planning.hpp"
#include "inde/ui/view_state.hpp"
#include "contextual_canvas.hpp"
#include <functional>
#include <optional>
#include <gtkmm.h>
namespace inde::ui {
class ContextualPlanningPage final : public Gtk::Box {
public:
  explicit ContextualPlanningPage(application::ProjectService &);
  void refresh(const std::string &work);
  void reset();
  ViewState capture_view() const;
  void restore_view(const std::string &work, const ViewState &);
  void reveal(const std::string &work, const std::string &plan,
              const std::string &part = "");
  sigc::signal<void(const std::string &)> &signal_status() { return status_; }
  sigc::signal<void(const std::string &)> &signal_open_document() {
    return open_document_;
  }
  sigc::signal<void(const application::BuilderRealization &)> &
  signal_open_target() {
    return open_target_;
  }

private:
  void render();
  void create_plan();
  void edit_content(bool creating);
  void edit_note();
  void reuse();
  void remove();
  void show_slots();
  void edit_slot(bool option);
  void show_context(const std::string &preview_option = "");
  void edit_declaration(const std::string &id = "");
  void show_dependencies();
  void edit_dependency();
  void show_texts();
  void associate_text();
  void review_text(const std::string &link);
  void open_text();
  void emit_text(const std::string &link);
  void associate_target();
  void show_references();
  void edit_reference();
  void edit_bridge();
  void navigate_context(const std::string &plan, const std::string &part);
  void develop_selected();
  void return_module();
  void edit_scale();
  void edit_role();
  void group_parts();
  void compose_existing();
  void selection_actions();
  void init_visual();
  void visual_selection();
  void visual_properties(const std::string &creating = "");
  void expand_visual();
  void refresh_visual();
  void commit_visual(const application::ContextualSnapshot &,
                     const std::vector<application::ContextualVisualItem> &);
  void undo_visual(bool redo=false);
  void review_sequence();
  void arrange_selection();
  void execute(const std::function<void()> &);
  const application::ContextualParticipation &selected() const;
  application::ProjectService &project_;
  application::ContextualPlanningService service_;
  application::ContextualSnapshot snapshot_;
  std::string project_id_, work_id_, selected_id_;
  std::string selected_slot_, selected_option_;
  std::vector<std::string> context_returns_;
  std::vector<std::string> module_returns_;
  std::size_t offset_{};
  bool loading_{};
  Gtk::ComboBoxText plans_;
  Gtk::FlowBox actions_;
  Gtk::Box navigation_{Gtk::Orientation::HORIZONTAL, 6},
      capture_{Gtk::Orientation::HORIZONTAL, 6},
      selection_{Gtk::Orientation::HORIZONTAL, 6};
  Gtk::Entry quick_;
  Gtk::MenuButton assembly_, more_;
  Gtk::Button develop_{"Desenvolver trecho"}, back_{"Voltar ao conjunto"},
      scale_{"Escala do trecho…"}, role_{"Papel neste conjunto…"},
      group_{"Agrupar trechos…"}, compose_{"Usar composição como trecho…"};
  Gtk::Label focus_;
  Gtk::Button new_plan_{"Nova composição contextual"},
      new_moment_{"Novo trecho"}, reuse_{"Reutilizar acontecimento"},
      edit_{"Editar conteúdo compartilhado"}, note_{"Nota desta participação"},
      detach_{"Retirar participação"}, up_{"Mover antes"},
      down_{"Mover depois"}, refresh_{"Atualizar"};
  Gtk::Button slots_{"Encaixes e opções"},
      context_{"Contexto desta participação"}, text_{"Escrever neste contexto"};
  Gtk::Label help_, page_label_;
  Gtk::ScrolledWindow scroll_;
  Gtk::ListBox rows_;
  ContextualCanvas canvas_;
  Gtk::Stack surface_;
  Gtk::Box visual_bar_{Gtk::Orientation::HORIZONTAL, 6};
  Gtk::ToggleButton list_mode_{"Lista"};
  Gtk::Button fit_{"Panorama"}, zoom_in_{"+"}, zoom_out_{"−"},
      visual_edit_{"Disposição…"}, expand_{"Expandir/recolher"};
  Gtk::MenuButton visual_menu_;
  std::optional<application::ContextualVisualItem> capture_placement_;
  std::string visual_plan_;
  struct VisualUndo {
    std::string revision;
    std::vector<application::ContextualVisualItem> items;
  };
  std::vector<VisualUndo> visual_undo_,visual_redo_;
  Gtk::Box pager_{Gtk::Orientation::HORIZONTAL, 8};
  Gtk::Button previous_{"Anterior"}, next_{"Próxima"};
  sigc::signal<void(const std::string &)> status_;
  sigc::signal<void(const std::string &)> open_document_;
  sigc::signal<void(const application::BuilderRealization &)> open_target_;
};
} // namespace inde::ui
