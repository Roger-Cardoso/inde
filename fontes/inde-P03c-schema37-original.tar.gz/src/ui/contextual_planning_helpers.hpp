#pragma once
#include "inde/application/contextual_planning.hpp"
#include "inde/ui/accessibility.hpp"
#include "inde/ui/bounded_choices.hpp"
#include "inde/ui/overlay_dialog.hpp"
#include <functional>
#include <gtkmm.h>
namespace inde::ui::contextual_ui {
// Commands reread the canonical aggregate under CAS. Retain its immutable
// identity/revision, not another multi-MiB row copy for every modal button.
inline application::ContextualSnapshot
observation(const application::ContextualSnapshot &s) {
  application::ContextualSnapshot out;
  out.project_id = s.project_id;
  out.plan_id = s.plan_id;
  out.work_id = s.work_id;
  out.revision = s.revision;
  return out;
}
inline Gtk::Label *label(const std::string &v) {
  auto *x = Gtk::make_managed<Gtk::Label>(v);
  x->set_xalign(0);
  x->set_wrap(true);
  x->set_max_width_chars(72);
  return x;
}
inline std::string caption(const std::string &v) {
  auto t = Glib::ustring(v);
  return t.substr(0, 100).raw() + (t.size() > 100 ? "…" : "");
}
inline std::string kind(const std::string &v) {
  return application::contextual_kind_label(v);
}
// Hide the old generation and defer both disposal and the tracked next action:
// no nested modal replaces a live emitting control, no dangling page callback.
inline void next(OverlayDialog *d, sigc::slot<void()> action) {
  d->hide();
  Glib::signal_idle().connect_once([d, action] {
    delete d;
    if (action)
      action();
  });
}
inline Gtk::FlowBox *actions(Gtk::Box &body) {
  auto *x = Gtk::make_managed<Gtk::FlowBox>();
  x->set_selection_mode(Gtk::SelectionMode::NONE);
  x->set_min_children_per_line(1);
  x->set_max_children_per_line(3);
  x->set_column_spacing(6);
  x->set_row_spacing(6);
  body.append(*x);
  return x;
}
inline void button(Gtk::FlowBox &box, const std::string &name,
                   sigc::slot<void()> f) {
  auto *x = Gtk::make_managed<Gtk::Button>(name);
  x->signal_clicked().connect(f);
  box.append(*x);
}
class Picker final : public Gtk::Box {
public:
  using Rows = std::vector<std::pair<std::string, std::string>>;
  explicit Picker(const std::string &name)
      : Gtk::Box(Gtk::Orientation::VERTICAL, 6) {
    combo.set_name(name);
    set_accessible_label(combo, name);
    bound_choice_width(combo);
    append(combo);
    page.append(before);
    page.append(count);
    page.append(after);
    append(page);
    before.signal_clicked().connect([this] {
      if (offset >= 50) {
        offset -= 50;
        render();
      }
    });
    after.signal_clicked().connect([this] {
      if (offset + 50 < rows.size()) {
        offset += 50;
        render();
      }
    });
  }
  void set_rows(Rows values, const std::string &wanted = "") {
    const auto selected = wanted;
    rows = std::move(values);
    offset = 0;
    for (std::size_t i = 0; i < rows.size(); ++i)
      if (rows[i].first == selected)
        offset = i / 50 * 50;
    render();
    if (!selected.empty())
      combo.set_active_id(selected);
  }
  std::string selected() const {
    const auto id = combo.get_active_id().raw();
    return id == "__none__" ? "" : id;
  }
  Gtk::ComboBoxText combo;

private:
  void render() {
    combo.remove_all();
    combo.append("__none__", "— sem escolha —");
    for (std::size_t i = offset; i < std::min(offset + 50, rows.size()); ++i)
      combo.append(rows[i].first, caption(rows[i].second)+" · ID "+rows[i].first);
    combo.set_active(0);
    before.set_sensitive(offset > 0);
    after.set_sensitive(offset + 50 < rows.size());
    count.set_text("Página " + std::to_string(offset / 50 + 1) + " · " +
                   std::to_string(rows.size()) + " opções, até 50 por página");
    page.set_visible(rows.size()>50);
  }
  Rows rows;
  std::size_t offset{};
  Gtk::Box page{Gtk::Orientation::HORIZONTAL, 6};
  Gtk::Button before{"Anterior"}, after{"Próxima"};
  Gtk::Label count;
};
class TextPager final : public Gtk::Box {
public:
  explicit TextPager(std::vector<std::string> values)
      : Gtk::Box(Gtk::Orientation::VERTICAL, 6), rows(std::move(values)) {
    text.set_editable(false);
    text.set_wrap_mode(Gtk::WrapMode::WORD_CHAR);
    scroll.set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
    scroll.set_min_content_height(170);
    scroll.set_child(text);
    append(scroll);
    page.append(before);
    page.append(count);
    page.append(after);
    append(page);
    before.signal_clicked().connect([this] {
      if (offset >= 50) {
        offset -= 50;
        render();
      }
    });
    after.signal_clicked().connect([this] {
      if (offset + 50 < rows.size()) {
        offset += 50;
        render();
      }
    });
    render();
  }

private:
  void render() {
    std::string v;
    for (std::size_t i = offset; i < std::min(offset + 50, rows.size()); ++i)
      v += rows[i] + "\n\n";
    text.get_buffer()->set_text(
        v.empty() ? "Nenhuma informação declarada neste recorte." : v);
    before.set_sensitive(offset > 0);
    after.set_sensitive(offset + 50 < rows.size());
    count.set_text(std::to_string(rows.size()) + " registros · página " +
                   std::to_string(offset / 50 + 1) + " (até 50)");
    before.set_visible(rows.size()>50);
    after.set_visible(rows.size()>50);
  }
  std::vector<std::string> rows;
  std::size_t offset{};
  Gtk::TextView text;
  Gtk::ScrolledWindow scroll;
  Gtk::Box page{Gtk::Orientation::HORIZONTAL, 6};
  Gtk::Button before{"Anterior"}, after{"Próxima"};
  Gtk::Label count;
};
} // namespace inde::ui::contextual_ui
