#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <memory>
#include <set>
namespace inde::ui {
using namespace contextual_ui;
void ContextualPlanningPage::selection_actions() {
  const auto at = std::find_if(
      snapshot_.participations.begin(), snapshot_.participations.end(),
      [this](const auto &x) { return x.id == selected_id_; });
  const bool selected = at != snapshot_.participations.end();
  // Reserve the contextual row: showing selection must not move the surface
  // underneath a pointer gesture that has just started.
  selection_.set_visible(true);
  selection_.set_size_request(-1,44);
  const auto count=canvas_.selected_parts().size();
  const bool single=selected&&(list_mode_.get_active()||count<=1);
  develop_.set_visible(selected);text_.set_visible(selected);more_.set_visible(selected);
  more_.set_sensitive(single);
  back_.set_visible(!module_returns_.empty());
  for (auto *b : {&edit_, &note_, &detach_, &up_, &down_, &context_, &text_,
                  &scale_, &role_, &develop_})
    b->set_sensitive(single);
  if (selected) {
    focus_.set_text(count>1?std::to_string(count)+" trechos selecionados":caption(at->title.empty() ? at->description : at->title));
    develop_.set_label(at->contents_plan_id.empty() ? "Desenvolver trecho"
                                                    : "Abrir interior");
  }else focus_.set_text("Selecione trechos para mover ou agrupar; um trecho para desenvolver.");
}
void ContextualPlanningPage::develop_selected() {
  try {
    if(!list_mode_.get_active()&&canvas_.selected_parts().size()!=1)throw std::runtime_error("Selecione um único trecho para desenvolver seu interior.");
    if (!quick_.get_text().empty())
      throw std::runtime_error("Acrescente ou limpe a ideia pendente antes de "
                               "entrar em outro trecho.");
    if (module_returns_.size() >= 16)
      throw std::runtime_error("Limite de 16 retornos de trechos");
    auto fields = capture_view().as_object();
    // Flatten the trail instead of embedding prior trails recursively.
    fields.erase("module_returns");
    const auto frame = serialize_view(ViewState(fields));
    if (frame.size() > 1024)
      throw std::runtime_error(
          "Volte primeiro das consultas de origem antes de abrir outro "
          "interior; o ponto atual foi preservado.");
    const auto id = service_.develop(snapshot_, selected().id);
    auto trail = module_returns_;
    trail.push_back(frame);
    reveal(work_id_, id);
    module_returns_ = std::move(trail);
    selection_actions();
    status_.emit("Interior compartilhado do trecho. Desenvolva apenas o que "
                 "interessa; Voltar ao conjunto conserva seu lugar.");
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::return_module() {
  if (module_returns_.empty())
    return;
  try {
    if (!quick_.get_text().empty())
      throw std::runtime_error(
          "Acrescente ou limpe a ideia pendente antes de voltar.");
    const auto frame = parse_view_state(module_returns_.back());
    auto trail = module_returns_;
    trail.pop_back();
    restore_view(work_id_, frame);
    module_returns_ = std::move(trail);
    selection_actions();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_scale() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto m = service_.moment(selected().moment_id);
    auto *d = new OverlayDialog("Escala do trecho", *owner, true);
    d->set_secondary_text("Nome opcional compartilhado nos " +
                          std::to_string(m.uses.size()) +
                          " usos deste trecho. Não impõe uma hierarquia nem "
                          "desenvolve seu interior.");
    auto *entry = Gtk::make_managed<Gtk::Entry>();
    entry->set_max_length(80);
    entry->set_text(m.scale);
    entry->set_placeholder_text(
        "Ação, decisão, fluxo, bloco, sequência ou outro");
    set_accessible_label(*entry, "Escala opcional compartilhada");
    d->get_content_area()->append(*label("Escala (opcional)"));
    d->get_content_area()->append(*entry);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Salvar", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, entry, error, m](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.set_scale(m, entry->get_text());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_role() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto x = selected();
    auto *d = new OverlayDialog("Papel neste conjunto", *owner, true);
    d->set_secondary_text("Somente este uso em " + snapshot_.title +
                          ". Categoria e paralelo são independentes; não "
                          "declaram simultaneidade nem causalidade.");
    auto *entry = Gtk::make_managed<Gtk::Entry>();
    entry->set_max_length(80);
    entry->set_text(x.category);
    entry->set_placeholder_text("Principal, secundária, fundo ou outra");
    set_accessible_label(*entry, "Categoria opcional neste uso");
    auto *parallel =
        Gtk::make_managed<Gtk::CheckButton>("Desenvolvimento paralelo");
    parallel->set_active(x.parallel);
    d->get_content_area()->append(*label("Categoria (opcional)"));
    d->get_content_area()->append(*entry);
    d->get_content_area()->append(*parallel);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Salvar", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, entry, parallel, error, expected, id = x.id](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.set_role(expected, id, entry->get_text(),
                              parallel->get_active());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::compose_existing() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto count = snapshot_.participations.size();
    auto *d = new OverlayDialog("Usar composição como trecho", *owner, true);
    d->set_secondary_text(
        "A composição continua sendo a mesma origem, com suas escolhas e "
        "vínculos. Será uma peça neste conjunto; não uma cópia.");
    auto *picker = Gtk::make_managed<Picker>("Composição a usar como trecho");
    Picker::Rows rows;
    for (const auto &p : service_.plans(work_id_))
      if (p.id != expected.plan_id)
        rows.push_back({p.id, p.title});
    picker->set_rows(std::move(rows));
    d->get_content_area()->append(*picker);
    auto source = std::make_shared<application::ContextualSnapshot>();
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    picker->combo.signal_changed().connect(sigc::track_obj(
        [this, picker, source, error] {
          *source = {};
          if (picker->selected().empty())
            return;
          try {
            *source = service_.snapshot(picker->selected());
            error->set_text("");
          } catch (const std::exception &e) {
            error->set_text(e.what());
          }
        },
        *this));
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Usar como trecho", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, source, error, expected, count](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            selected_id_ = service_.compose_plan(expected, *source);
            offset_ = (count / 50) * 50;
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::group_parts() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  const auto expected = observation(snapshot_);
  auto *d = new OverlayDialog("Agrupar trechos", *owner, true);
  d->set_secondary_text(
      "Escolha pelo menos dois trechos. O grupo ocupa o primeiro lugar "
      "escolhido; a ordem relativa dos demais permanece. Identidades, notas e "
      "vínculos são conservados, sem herança implícita.");
  auto *title = Gtk::make_managed<Gtk::Entry>();
  title->set_max_length(200);
  title->set_placeholder_text("Por exemplo: Rotina matutina");
  set_accessible_label(*title, "Nome do trecho agrupado");
  d->get_content_area()->append(*label("Nome do conjunto"));
  d->get_content_area()->append(*title);
  auto *list = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 3);
  auto *scroll = Gtk::make_managed<Gtk::ScrolledWindow>();
  scroll->set_policy(Gtk::PolicyType::NEVER, Gtk::PolicyType::AUTOMATIC);
  scroll->set_min_content_height(220);
  scroll->set_child(*list);
  d->get_content_area()->append(*scroll);
  auto *page = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 6);
  auto *before = Gtk::make_managed<Gtk::Button>("Anterior"),
       *after = Gtk::make_managed<Gtk::Button>("Próxima");
  auto *hint = label("");
  page->append(*before);
  page->append(*hint);
  page->append(*after);
  d->get_content_area()->append(*page);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  struct State {
    std::size_t offset{};
    std::set<std::string> chosen;
    std::vector<application::ContextualParticipation> rows;
  };
  auto state = std::make_shared<State>();
  state->rows = snapshot_.participations;
  if (!list_mode_.get_active()) {
    const auto chosen=canvas_.selected_parts();
    state->chosen.insert(chosen.begin(),chosen.end());
  }
  auto load = std::make_shared<std::function<void()>>();
  *load = [state, list, before, after, hint] {
    while (auto *child = list->get_first_child())
      list->remove(*child);
    for (std::size_t i = state->offset;
         i < std::min(state->offset + 50, state->rows.size()); ++i) {
      const auto &x = state->rows[i];
      auto *check = Gtk::make_managed<Gtk::CheckButton>(
          caption(x.title.empty() ? x.description : x.title));
      check->set_active(state->chosen.contains(x.id));
      check->signal_toggled().connect([check, state, id = x.id, hint] {
        if (check->get_active())
          state->chosen.insert(id);
        else
          state->chosen.erase(id);
        hint->set_text(std::to_string(state->chosen.size()) +
                       " escolhidos · página " +
                       std::to_string(state->offset / 50 + 1));
      });
      list->append(*check);
    }
    before->set_visible(state->rows.size() > 50);
    after->set_visible(state->rows.size() > 50);
    before->set_sensitive(state->offset > 0);
    after->set_sensitive(state->offset + 50 < state->rows.size());
    hint->set_text(std::to_string(state->chosen.size()) +
                   " escolhidos · página " +
                   std::to_string(state->offset / 50 + 1));
  };
  before->signal_clicked().connect([state, load] {
    if (state->offset >= 50)
      state->offset -= 50;
    (*load)();
  });
  after->signal_clicked().connect([state, load] {
    if (state->offset + 50 < state->rows.size())
      state->offset += 50;
    (*load)();
  });
  (*load)();
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Agrupar", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj(
      [this, d, title, error, expected, state](int r) {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        try {
          const std::vector<std::string> ids(state->chosen.begin(),
                                             state->chosen.end());
          selected_id_ = service_.group(expected, ids, title->get_text());
          const auto now = service_.snapshot(expected.plan_id);
          const auto at = std::find_if(
              now.participations.begin(), now.participations.end(),
              [this](const auto &x) { return x.id == selected_id_; });
          offset_ = static_cast<std::size_t>(at - now.participations.begin()) /
                    50 * 50;
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work_id_);
      },
      *this));
  d->present();
}
} // namespace inde::ui
