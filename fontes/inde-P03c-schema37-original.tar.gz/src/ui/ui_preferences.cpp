#include "inde/ui/ui_preferences.hpp"
#include <glib.h>
#include <filesystem>
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
namespace inde::ui {
namespace {
std::filesystem::path preference_path() {
  return std::filesystem::path(g_get_user_config_dir()) / "inde" / "interface.ini";
}
GKeyFile *load() {
  auto *file = g_key_file_new();
  GError *error{};
  static bool warned{};
  if(!g_key_file_load_from_file(file, preference_path().c_str(),
      static_cast<GKeyFileFlags>(G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS), &error) &&
      !g_error_matches(error,G_FILE_ERROR,G_FILE_ERROR_NOENT)) {
    if(!warned)g_warning("Interface preferences unreadable; original file retained: %s",error->message);
    warned=true;g_clear_error(&error);g_key_file_unref(file);return nullptr;
  }
  warned=false;g_clear_error(&error);
  return file;
}
}
UiPreferences ui_preferences(const std::string &group,
                             const std::vector<std::string> &keys) {
  UiPreferences values;
  auto *file = load();
  for (const auto &key : keys) {
    auto *value = file ? g_key_file_get_string(file, group.c_str(), key.c_str(), nullptr) : nullptr;
    values.emplace(key, value ? value : "");
    g_free(value);
  }
  if (file) g_key_file_unref(file);
  return values;
}
std::string ui_preference(const std::string &group, const std::string &key,
                          const std::string &fallback) {
  auto *file = load();
  if(!file)return fallback;
  auto *value = g_key_file_get_string(file, group.c_str(), key.c_str(), nullptr);
  const std::string result = value ? value : fallback;
  g_free(value); g_key_file_unref(file);
  return result;
}
void set_ui_preference(const std::string &group, const std::string &key,
                       const std::string &value) noexcept {
  (void)set_ui_preferences(group, {{key, value}});
}
bool set_ui_preferences(const std::string &group,
                        const UiPreferences &values) noexcept {
  if (values.empty()) return true;
  try {
    const auto path = preference_path();
    if (g_mkdir_with_parents(path.parent_path().c_str(), 0700) != 0) return false;
    struct Lock {
      int fd;
      ~Lock() { if (fd >= 0) { flock(fd, LOCK_UN); close(fd); } }
    } lock{open((path.string() + ".lock").c_str(), O_CREAT | O_RDWR | O_CLOEXEC, 0600)};
    if (lock.fd < 0 || flock(lock.fd, LOCK_EX | LOCK_NB) != 0) return false;
    auto *file = load();
    if (!file) return false;
    bool changed = false;
    for (const auto &[key, value] : values) {
      auto *old = g_key_file_get_string(file, group.c_str(), key.c_str(), nullptr);
      changed |= !old || value != old;
      g_free(old);
      g_key_file_set_string(file, group.c_str(), key.c_str(), value.c_str());
    }
    if (!changed) { g_key_file_unref(file); return true; }
    gsize size{};
    auto *data = g_key_file_to_data(file, &size, nullptr);
    g_key_file_unref(file);
    GError *error{};
    const bool saved = g_file_set_contents_full(path.c_str(), data,
        static_cast<gssize>(size), G_FILE_SET_CONTENTS_CONSISTENT, 0600, &error);
    g_free(data);
    if (!saved) {
      g_warning("Unable to save interface preferences: %s", error ? error->message : "unknown error");
      g_clear_error(&error);
      return false;
    }
    auto *confirmed = load();
    if (!confirmed) return false;
    bool equal = true;
    for (const auto &[key, value] : values) {
      auto *actual = g_key_file_get_string(confirmed, group.c_str(), key.c_str(), nullptr);
      equal &= actual && value == actual;
      g_free(actual);
    }
    g_key_file_unref(confirmed);
    return equal;
  } catch (...) { return false; }
}
std::string project_preference_group(const std::string &id) {
  auto *digest = g_compute_checksum_for_string(G_CHECKSUM_SHA256, id.c_str(), -1);
  const auto result = std::string("project-") + digest;
  g_free(digest); return result;
}
}
