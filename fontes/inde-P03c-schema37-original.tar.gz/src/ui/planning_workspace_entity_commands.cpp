#include "inde/ui/planning_workspace.hpp"
#include "inde/ui/project_operations.hpp"
#include "inde/ui/accessibility.hpp"
#include "inde/ui/overlay_dialog.hpp"
#include "inde/ui/author_diagnostics.hpp"

#include <algorithm>

namespace inde::ui {

void PlanningWorkspace::create_entity() {
  auto *owner = owner_window();
  if (types_.empty() && service_.current())
    refresh_types();
  if (!owner || types_.empty())
    return;
  auto *dialog = new OverlayDialog("Novo elemento da história", *owner, true);
  dialog->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  dialog->add_button("Criar", Gtk::ResponseType::ACCEPT);
  dialog->allow_primary_shortcut();
  auto *form = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 8);
  auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
  for (const auto &value : types_)
    type->append(value.id, value.name);
  type->set_active(0);
  auto *name = Gtk::make_managed<Gtk::Entry>();
  name->set_placeholder_text("Nome (obrigatório)");
  auto *summary = Gtk::make_managed<Gtk::Entry>();
  summary->set_placeholder_text("Resumo");
  form->set_margin(16);
  append_labeled_form_field(*form, "Categoria do elemento", *type,
                            "Escolha a categoria narrativa do elemento da história.");
  append_labeled_form_field(*form, "Nome do elemento da história", *name,
                            "Campo obrigatório.");
  append_labeled_form_field(*form, "Resumo", *summary,
                            "Breve descrição do elemento da história.");
  dialog->get_content_area()->append(*form);
  const auto project_id = service_.current()->manifest().project_id;
  dialog->signal_response().connect([this, dialog, type, name,
                                     summary, project_id](int response) {
    if (response == Gtk::ResponseType::ACCEPT) {
      try {
        if (!service_.current() || service_.current()->manifest().project_id != project_id)
          throw std::runtime_error("O Projeto mudou; feche este formulário e escolha novamente.");
        const auto created = service_.narrative().create_entity(
            type->get_active_id().raw(), name->get_text(), summary->get_text());
        // Creation is already durable. Retire its form before refreshing so
        // a presentation failure cannot invite a duplicate retry.
        dialog->hide();
        selected_entity_id_ = created.id;
        offset_ = 0;
        try {
          refresh_entities();
          if (std::none_of(page_.begin(), page_.end(), [&](const auto &value) {
                return value.id == created.id;
              }))
            page_.push_back(created);
          refresh_details();
          show_entity_detail_page();
          signal_status_message_.emit("Elemento da história criado e salvo");
        }
        catch (const std::exception &error) {
          signal_status_message_.emit("Elemento criado e salvo; resultados não atualizados: " + author::diagnostic(error.what()));
          return;
        }
      } catch (const std::exception &error) {
        dialog->set_secondary_text(author::diagnostic(error.what()));
        dialog->keep_open_on_response();
        return;
      }
    }
    dialog->hide();
  });
  dialog->present();
}

void PlanningWorkspace::edit_selected_entity() {
  if (!selected_entity_id_)
    return;
  const auto found =
      std::find_if(page_.begin(), page_.end(), [&](const auto &value) {
        return value.id == *selected_entity_id_;
      });
  auto *owner = owner_window();
  if (!owner || found == page_.end())
    return;
  auto original = *found;
  auto *dialog = new OverlayDialog("Editar elemento da história", *owner, true);
  dialog->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  dialog->add_button("Salvar", Gtk::ResponseType::ACCEPT);
  dialog->allow_primary_shortcut();
  auto *form = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 8);
  auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
  for (const auto &value : types_)
    type->append(value.id, value.name);
  type->set_active_id(original.entity_type_id);
  auto *name = Gtk::make_managed<Gtk::Entry>();
  name->set_text(original.name);
  auto *summary = Gtk::make_managed<Gtk::Entry>();
  summary->set_text(original.summary);
  form->set_margin(16);
  append_labeled_form_field(*form, "Categoria do elemento", *type,
                            "Escolha a categoria narrativa do elemento da história.");
  append_labeled_form_field(*form, "Nome do elemento da história", *name,
                            "Campo obrigatório.");
  append_labeled_form_field(*form, "Resumo", *summary,
                            "Breve descrição do elemento da história.");
  dialog->get_content_area()->append(*form);
  const auto project_id = service_.current()->manifest().project_id;
  dialog->signal_response().connect([this, dialog, original, type, name,
                                     summary, project_id](int response) {
    if (response == Gtk::ResponseType::ACCEPT) {
      try {
        if (!service_.current() || service_.current()->manifest().project_id != project_id)
          throw std::runtime_error("O Projeto mudou; feche este formulário e escolha novamente.");
        auto edited = original;
        edited.entity_type_id = type->get_active_id().raw();
        edited.name = name->get_text();
        edited.summary = summary->get_text();
        static_cast<void>(service_.narrative().update_entity(edited, original));
        dialog->hide();
        try {
          refresh_entities();
          signal_status_message_.emit("Elemento da história atualizado e salvo");
        } catch (const std::exception &error) {
          signal_status_message_.emit("Elemento atualizado e salvo; resultados não atualizados: " + author::diagnostic(error.what()));
        }
      } catch (const std::exception &error) {
        dialog->set_secondary_text(author::diagnostic(error.what()));
        dialog->keep_open_on_response();
        return;
      }
    }
    dialog->hide();
  });
  dialog->present();
}

void PlanningWorkspace::delete_selected_entity() {
  if(!selected_entity_id_ || !owner_window())return;
  confirm_project_removal(*owner_window(),service_,project::RemovalKind::Entity,*selected_entity_id_,[this]{
    selected_entity_id_.reset();refresh_entities();show_explorer_page();
    signal_status_message_.emit("Elemento da história removida; operação registrada no histórico do Projeto");
  });
}

} // namespace inde::ui
