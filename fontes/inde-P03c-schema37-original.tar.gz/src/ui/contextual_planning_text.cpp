#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <memory>
namespace inde::ui {
using namespace contextual_ui;
void ContextualPlanningPage::emit_text(const std::string &id) {
  const auto r = service_.text_destination(snapshot_, id);
  if (r.anchor_id.empty() && r.composition_id.empty())
    open_document_.emit(r.document_id);
  else
    open_target_.emit(r);
}
void ContextualPlanningPage::open_text() {
  try {
    const auto part = selected().id;
    std::vector<application::ContextualTextLink> links;
    for (const auto &x : snapshot_.text_links)
      if (x.participation_id == part)
        links.push_back(x);
    if (links.empty())
      associate_text();
    else if (links.size() == 1) {
      emit_text(links.front().id);
    } else
      show_texts();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::show_texts() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto part = selected().id;
    const auto expected = observation(snapshot_);
    auto links =
        std::make_shared<std::vector<application::ContextualTextLink>>();
    for (const auto &x : snapshot_.text_links)
      if (x.participation_id == part)
        links->push_back(x);
    auto *d = new OverlayDialog("Textos associados ao contexto", *owner, true);
    d->set_secondary_text(
        "Vínculos muitos-para-muitos. Abrir não confirma realização; observar "
        "mudança técnica não julga fidelidade narrativa. Desvincular preserva "
        "Documento e planejamento.");
    auto *pick = Gtk::make_managed<Picker>("Texto associado");
    Picker::Rows rows;
    for (const auto &x : *links)
      if (x.participation_id == part)
        rows.push_back({x.id, (x.anchor_id.empty()
                                   ? (x.composition_id.empty()
                                          ? std::string("Documento inteiro")
                                          : "Ocorrência · " + x.occurrence_id)
                                   : "Trecho marcado · " + x.anchor_id) +
                                  " · " + x.title});
    pick->set_rows(rows);
    d->get_content_area()->append(*pick);
    auto *error = label("");
    error->add_css_class("error");
    auto *bar = actions(*d->get_content_area());
    d->get_content_area()->append(*error);
    button(*bar, "Associar outro texto",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { associate_text(); }, *this));
               },
               *this));
    button(*bar, "Associar trecho ou ocorrência",
           sigc::track_obj(
               [this, d] {
                 next(d,
                      sigc::track_obj([this] { associate_target(); }, *this));
               },
               *this));
    auto chosen = [links, pick] {
      const auto id = pick->selected();
      const auto it = std::find_if(links->begin(), links->end(),
                                   [&](auto &x) { return x.id == id; });
      if (it == links->end())
        throw std::runtime_error("Escolha um texto associado");
      return *it;
    };
    button(*bar, "Abrir texto",
           sigc::track_obj(
               [this, d, chosen, error, expected] {
                 try {
                   const auto x = chosen();
                   const auto target =
                       service_.text_destination(expected, x.id);
                   next(d, sigc::track_obj(
                               [this, target] {
                                 if (target.anchor_id.empty() &&
                                     target.composition_id.empty())
                                   open_document_.emit(target.document_id);
                                 else
                                   open_target_.emit(target);
                               },
                               *this));
                 } catch (const std::exception &e) {
                   error->set_text(e.what());
                 }
               },
               *this));
    button(*bar, "Observar / conferir",
           sigc::track_obj(
               [this, d, chosen, error] {
                 try {
                   const auto x = chosen();
                   next(d, sigc::track_obj(
                               [this, id = x.id] { review_text(id); }, *this));
                 } catch (const std::exception &e) {
                   error->set_text(e.what());
                 }
               },
               *this));
    button(*bar, "Desvincular texto",
           sigc::track_obj(
               [this, d, chosen, error, expected] {
                 try {
                   service_.remove_text_link(expected, chosen().id);
                 } catch (const std::exception &e) {
                   error->set_text(e.what());
                   return;
                 }
                 refresh(work_id_);
                 next(d, sigc::track_obj([this] { show_texts(); }, *this));
               },
               *this));
    button(*bar, "Voltar ao contexto",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { show_context(); }, *this));
               },
               *this));
    d->add_button("Fechar", Gtk::ResponseType::CLOSE);
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::associate_text() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto part = selected().id;
    auto *d = new OverlayDialog("Associar texto e escrever", *owner, true);
    d->set_secondary_text("Escolha um Documento do Projeto ou crie um vazio. "
                          "Não impõe um Documento por acontecimento e não "
                          "escreve prosa nem confirma realização.");
    auto *search = Gtk::make_managed<Gtk::Entry>();
    search->set_max_length(200);
    set_accessible_label(*search, "Buscar Documento do Projeto");
    auto *find = Gtk::make_managed<Gtk::Button>("Buscar Documentos");
    auto *pick = Gtk::make_managed<Picker>("Documento do Projeto");
    auto *previous = Gtk::make_managed<Gtk::Button>("Documentos anteriores"),
         *after = Gtk::make_managed<Gtk::Button>("Mais Documentos");
    auto *count = label("");
    auto *paging = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 6);
    paging->append(*previous);
    paging->append(*count);
    paging->append(*after);
    d->get_content_area()->append(*label("Documento existente"));
    d->get_content_area()->append(*search);
    d->get_content_area()->append(*find);
    d->get_content_area()->append(*pick);
    d->get_content_area()->append(*paging);
    auto *name = Gtk::make_managed<Gtk::Entry>();
    name->set_max_length(200);
    set_accessible_label(*name, "Título do novo Documento");
    d->get_content_area()->append(
        *label("Ou título para criar um Documento vazio"));
    d->get_content_area()->append(*name);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    struct Query {
      std::size_t offset{};
      std::string search;
      bool more{};
      std::map<std::string, std::string> shown;
    };
    auto state = std::make_shared<Query>();
    auto load = [this, state, pick, previous, after, count, error] {
      try {
        persistence::DocumentQuery query;
        query.limit = 51;
        query.offset = state->offset;
        query.search = state->search;
        auto docs = project_.writing().document_summaries(query);
        state->more = docs.size() > 50;
        if (state->more)
          docs.resize(50);
        Picker::Rows rows;
        state->shown.clear();
        for (const auto &x : docs) {
          state->shown[x.id] = x.title;
          rows.push_back({x.id, x.title + " · " +
                                    std::to_string(x.character_count) +
                                    " caracteres · " + x.id});
        }
        pick->set_rows(rows);
        previous->set_sensitive(state->offset > 0);
        after->set_sensitive(state->more);
        count->set_text("Página " + std::to_string(state->offset / 50 + 1));
        error->set_text("");
      } catch (const std::exception &e) {
        pick->set_rows({});
        previous->set_sensitive(false);
        after->set_sensitive(false);
        error->set_text(e.what());
      }
    };
    find->signal_clicked().connect(sigc::track_obj(
        [search, state, load] {
          state->offset = 0;
          state->search = search->get_text();
          load();
        },
        *this));
    search->signal_activate().connect(sigc::track_obj(
        [search, state, load] {
          state->offset = 0;
          state->search = search->get_text();
          load();
        },
        *this));
    previous->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->offset >= 50)
            state->offset -= 50;
          load();
        },
        *this));
    after->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->more)
            state->offset += 50;
          load();
        },
        *this));
    load();
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Associar existente e abrir", Gtk::ResponseType::ACCEPT);
    d->add_button("Criar vazio e abrir", Gtk::ResponseType::APPLY);
    d->signal_response().connect(sigc::track_obj(
        [this, d, pick, name, error, expected, part, state](int r) {
          if (r != Gtk::ResponseType::ACCEPT && r != Gtk::ResponseType::APPLY)
            return;
          std::string id;
          try {
            if (r == Gtk::ResponseType::APPLY)
              id = service_.create_text(expected, part, name->get_text());
            else {
              id = pick->selected();
              const auto doc = service_.text_document(id);
              if (!state->shown.contains(id) ||
                  doc.title != state->shown.at(id))
                throw std::runtime_error("O Documento mudou desde a lista; "
                                         "busque novamente antes de associar");
              service_.associate_text(expected, part, doc);
            }
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(
              sigc::track_obj([this, id] { open_document_.emit(id); }, *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::review_text(const std::string &id) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto review = service_.observe_text(expected, id);
    auto *d = new OverlayDialog("Observação técnica / conferência opcional",
                                *owner, true);
    d->set_secondary_text(
        review.changed ? "Conteúdo textual mudou desde a última observação. "
                         "Isto NÃO indica divergência narrativa."
                       : "Conteúdo textual igual ao observado. Isto NÃO "
                         "certifica realização ou fidelidade narrativa.");
    d->get_content_area()->append(*label(
        "Alvo textual: " + review.current.title + "\nSHA observado: " +
        review.link.observed_sha + "\nSHA atual: " + review.current.sha));
    auto *note = Gtk::make_managed<Gtk::Entry>();
    note->set_max_length(2048);
    note->set_text(review.link.note);
    set_accessible_label(*note, "Nota humana opcional de conferência");
    d->get_content_area()->append(
        *label("Nota humana opcional (não exige resumo paralelo)"));
    d->get_content_area()->append(*note);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Fechar sem registrar", Gtk::ResponseType::CANCEL);
    d->add_button("Registrar conferência", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, note, error, review, expected](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.review_text(expected, review, note->get_text());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
} // namespace inde::ui
