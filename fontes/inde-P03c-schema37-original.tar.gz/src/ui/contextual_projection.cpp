#include "contextual_projection.hpp"
#include "contextual_planning_helpers.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <memory>
namespace inde::ui {
using namespace contextual_ui;
namespace {
void contribution(Gtk::Window &owner, application::ProjectService &p,
                  const application::ContextualProjectionRow &row) try {
  application::ContextualPlanningService service(p);
  const auto snapshot = service.snapshot(row.plan_id);
  const auto view = service.context(snapshot, row.participation_id);
  auto *d =
      new OverlayDialog("Contribuição contextual — origem única", owner, true);
  d->set_secondary_text(
      row.plan_title + " / " + row.title +
      ". Referência não promove informação a ficha, data, presença ou relação "
      "canônica. Consulta atual, sem sincronização manual.");
  std::vector<std::string> rows;
  Picker::Rows choices;
  auto origins =
      std::make_shared<std::map<std::string, application::ContextualOrigin>>();
  for (const auto &x : view.declarations) {
    rows.push_back(kind(x.declaration.kind) + " · " + x.declaration.label +
                   "\n" + x.declaration.value + "\nOrigem: " + x.plan_title +
                   " / " + x.origin_title + " · " + x.declaration.id);
    choices.push_back({x.declaration.id, x.plan_title + " / " + x.origin_title +
                                             " · " + x.declaration.label});
    origins->emplace(x.declaration.id, x);
  }
  d->get_content_area()->append(*Gtk::make_managed<TextPager>(rows));
  if (!view.notices.empty())
    d->get_content_area()->append(*Gtk::make_managed<TextPager>(view.notices));
  auto *pick = Gtk::make_managed<Picker>("Declaração de origem a editar");
  pick->set_rows(choices);
  d->get_content_area()->append(*pick);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  auto *bar = actions(*d->get_content_area());
  button(*bar, "Editar declaração na origem",
         sigc::track_obj(
             [&owner, &p, d, pick, error, origins, row] {
               try {
                 const auto x = origins->at(pick->selected());
                 application::ContextualPlanningService service(p);
                 const auto expected = service.snapshot(x.plan_id);
                 auto at = std::find_if(
                     expected.declarations.begin(), expected.declarations.end(),
                     [&](auto &v) { return v.id == x.declaration.id; });
                 if (at == expected.declarations.end() ||
                     at->value != x.declaration.value ||
                     at->label != x.declaration.label ||
                     at->kind != x.declaration.kind)
                   throw std::runtime_error(
                       "Origem mudou; feche e consulte novamente");
                 const auto token = observation(expected);
                 next(d,
                      sigc::track_obj(
                          [&owner, &p, x, token, row] {
                            auto *edit = new OverlayDialog(
                                "Editar declaração contextual na origem", owner,
                                true);
                            edit->set_secondary_text(
                                x.plan_title + " / " + x.origin_title + " · " +
                                kind(x.declaration.kind) +
                                ". Altera esta origem uma vez; outras vistas a "
                                "consultam, não recebem cópias.");
                            auto *name = Gtk::make_managed<Gtk::Entry>();
                            name->set_text(x.declaration.label);
                            name->set_max_length(200);
                            set_accessible_label(
                                *name, "Assunto da declaração na origem");
                            auto *value = Gtk::make_managed<Gtk::Entry>();
                            value->set_text(x.declaration.value);
                            value->set_max_length(4096);
                            set_accessible_label(*value,
                                                 "Valor declarado na origem");
                            edit->get_content_area()->append(*label("Assunto"));
                            edit->get_content_area()->append(*name);
                            edit->get_content_area()->append(*label("Valor"));
                            edit->get_content_area()->append(*value);
                            auto *error = label("");
                            error->add_css_class("error");
                            edit->get_content_area()->append(*error);
                            edit->add_button("Cancelar",
                                             Gtk::ResponseType::CANCEL);
                            edit->add_button("Salvar origem",
                                             Gtk::ResponseType::ACCEPT);
                            edit->signal_response().connect(sigc::track_obj(
                                [&owner, &p, edit, name, value, error, x, token,
                                 row](int response) {
                                  if (response != Gtk::ResponseType::ACCEPT)
                                    return;
                                  try {
                                    auto v = x.declaration;
                                    v.label = name->get_text();
                                    v.value = value->get_text();
                                    application::ContextualPlanningService(p)
                                        .update_declaration(token, v);
                                  } catch (const std::exception &e) {
                                    error->set_text(e.what());
                                    edit->keep_open_on_response();
                                    return;
                                  }
                                  Glib::signal_idle().connect_once(
                                      sigc::track_obj(
                                          [&owner, &p, row] {
                                            contribution(owner, p, row);
                                          },
                                          owner));
                                },
                                owner));
                            edit->present();
                          },
                          owner));
               } catch (const std::exception &e) {
                 error->set_text(pick->selected().empty()
                                     ? "Escolha uma declaração de origem"
                                     : e.what());
               }
             },
             owner));
  d->add_button("Fechar", Gtk::ResponseType::CLOSE);
  d->present();
} catch (const std::exception &e) {
  auto *d = new OverlayDialog("Origem contextual indisponível", owner, true);
  d->set_secondary_text(e.what());
  d->add_button("Fechar", Gtk::ResponseType::CLOSE);
  d->present();
}
} // namespace
void show_contextual_projection(Gtk::Window &owner,
                                application::ProjectService &p,
                                const std::string &type, const std::string &id,
                                std::size_t offset) {
  auto *d =
      new OverlayDialog("Composições que referenciam esta origem", owner, true);
  auto *error = label("");
  error->add_css_class("error");
  try {
    const auto page =
        application::ContextualPlanningService(p).projection(type, id, offset);
    d->set_secondary_text(
        "Vista derivada das referências declaradas. Não altera dados canônicos "
        "nem exige reentrada. Até 50 por página; fontes fora da escolha atual "
        "continuam identificáveis.");
    std::vector<std::string> rows;
    Picker::Rows options;
    auto found = std::make_shared<
        std::map<std::string, application::ContextualProjectionRow>>();
    for (const auto &r : page.rows) {
      found->emplace(r.reference_id, r);
      options.push_back({r.reference_id, r.plan_title + " / " + r.title});
      rows.push_back(r.plan_title + " / " + r.title + "\n" +
                     (r.included ? "Na escolha atual"
                                 : "Fora da escolha atual ou não resolvida") +
                     "\n" + r.note + "\nParticipação: " + r.participation_id);
    }
    d->get_content_area()->append(*Gtk::make_managed<TextPager>(rows));
    auto *pick = Gtk::make_managed<Picker>("Participação de origem");
    pick->set_rows(options);
    d->get_content_area()->append(*pick);
    d->get_content_area()->append(
        *label("Página " + std::to_string(offset / 50 + 1) +
               (page.more ? " · há mais resultados" : " · fim deste recorte")));
    auto *bar = actions(*d->get_content_area());
    button(*bar, "Consultar contribuição",
           sigc::track_obj(
               [&owner, &p, d, pick, error, found] {
                 try {
                   const auto row = found->at(pick->selected());
                   next(d,
                        sigc::track_obj(
                            [&owner, &p, row] { contribution(owner, p, row); },
                            owner));
                 } catch (const std::exception &e) {
                   error->set_text(pick->selected().empty()
                                       ? "Escolha uma participação"
                                       : e.what());
                 }
               },
               owner));
    if (offset)
      button(*bar, "Página anterior de referências",
             sigc::track_obj(
                 [&owner, &p, d, type, id, offset] {
                   next(d, sigc::track_obj(
                               [&owner, &p, type, id, offset] {
                                 show_contextual_projection(owner, p, type, id,
                                                            offset - 50);
                               },
                               owner));
                 },
                 owner));
    if (page.more)
      button(*bar, "Mais referências",
             sigc::track_obj(
                 [&owner, &p, d, type, id, offset] {
                   next(d, sigc::track_obj(
                               [&owner, &p, type, id, offset] {
                                 show_contextual_projection(owner, p, type, id,
                                                            offset + 50);
                               },
                               owner));
                 },
                 owner));
  } catch (const std::exception &e) {
    error->set_text(e.what());
  }
  d->get_content_area()->append(*error);
  d->add_button("Fechar", Gtk::ResponseType::CLOSE);
  d->present();
}
} // namespace inde::ui
