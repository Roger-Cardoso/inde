#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <memory>
#include <optional>
#include <set>
namespace inde::ui {
using namespace contextual_ui;
namespace {
std::vector<std::string> origin_rows(const application::ContextualView &v) {
  std::vector<std::string> rows;
  for (const auto &x : v.declarations)
    rows.push_back(
        kind(x.declaration.kind) + " · " + x.declaration.label + "\n" +
        x.declaration.value + "\n" + (x.local ? "Local" : "Recebida") +
        " · origem: " + x.plan_title + " / " + x.origin_title + " [" +
        x.declaration.participation_id + "] · declaração " + x.declaration.id);
  return rows;
}
} // namespace
void ContextualPlanningPage::show_slots() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto state =
        std::make_shared<const application::ContextualSnapshot>(snapshot_);
    const auto expected = observation(*state);
    auto *d = new OverlayDialog("Encaixes e opções", *owner, true);
    d->set_secondary_text(
        "Escolha uma opção explicitamente. Vários participantes na mesma opção "
        "trabalham juntos; participações comuns não são copiadas. Posição não "
        "cria dependência.");
    auto *slots = Gtk::make_managed<Picker>("Encaixe contextual"),
         *options = Gtk::make_managed<Picker>("Opção contextual");
    Picker::Rows rows;
    for (const auto &x : state->slots)
      rows.push_back({x.id, x.title});
    slots->set_rows(rows, selected_slot_);
    d->get_content_area()->append(*label("Encaixe"));
    d->get_content_area()->append(*slots);
    d->get_content_area()->append(*label(
        "Opção a consultar/escolher (não é escolhida só por aparecer aqui)"));
    d->get_content_area()->append(*options);
    auto *current = label("");
    d->get_content_area()->append(*current);
    auto load = [this, state, slots, options, current] {
      selected_slot_ = slots->selected();
      Picker::Rows values;
      std::string chosen;
      for (const auto &x : state->options)
        if (x.slot_id == selected_slot_)
          values.push_back({x.id, x.title});
      for (const auto &x : state->slots)
        if (x.id == selected_slot_)
          chosen = x.selected_option;
      options->set_rows(values, selected_option_);
      std::string name = "não resolvida";
      for (const auto &x : state->options)
        if (x.id == chosen)
          name = x.title;
      current->set_text(
          "Escolha salva: " + name +
          ". Incluir na opção altera só a participação selecionada.");
    };
    slots->combo.signal_changed().connect(sigc::track_obj(load, *this));
    load();
    options->combo.signal_changed().connect(sigc::track_obj(
        [this, options] { selected_option_ = options->selected(); }, *this));
    auto *error = label("");
    error->add_css_class("error");
    auto *bar = actions(*d->get_content_area());
    d->get_content_area()->append(*error);
    auto command = [this, d, error, expected](auto f) {
      return sigc::track_obj(
          [this, d, error, expected, f] {
            try {
              f();
            } catch (const std::exception &e) {
              error->set_text(e.what());
              return;
            }
            refresh(work_id_);
            next(d, sigc::track_obj([this] { show_slots(); }, *this));
          },
          *this);
    };
    button(*bar, "Novo encaixe",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { edit_slot(false); }, *this));
               },
               *this));
    button(*bar, "Nova opção",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { edit_slot(true); }, *this));
               },
               *this));
    button(*bar, "Escolher opção", command([this, expected, slots, options] {
      service_.choose_option(expected, slots->selected(), options->selected());
    }));
    button(*bar, "Incluir na opção", command([this, expected, options] {
      const auto option = options->selected();
      if (option.empty())
        throw std::runtime_error(
            "Escolha uma opção para incluir a participação");
      service_.assign_option(expected, selected().id, option);
    }));
    button(*bar, "Tornar participação comum", command([this, expected] {
      service_.assign_option(expected, selected().id, "");
    }));
    button(*bar, "Comparar contexto da opção",
           sigc::track_obj(
               [this, d, options, error] {
                 if (selected_id_.empty() || options->selected().empty()) {
                   error->set_text(
                       "Selecione uma participação e uma opção para comparar");
                   return;
                 }
                 const auto option = options->selected();
                 next(d, sigc::track_obj(
                             [this, option] { show_context(option); }, *this));
               },
               *this));
    button(*bar, "Remover opção vazia", command([this, expected, options] {
      service_.remove_option(expected, options->selected());
      selected_option_.clear();
    }));
    button(*bar, "Remover encaixe vazio", command([this, expected, slots] {
      service_.remove_slot(expected, slots->selected());
      selected_slot_.clear();
      selected_option_.clear();
    }));
    d->add_button("Fechar", Gtk::ResponseType::CLOSE);
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_slot(bool option) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  const auto expected = observation(snapshot_);
  const auto slot = selected_slot_;
  auto *d =
      new OverlayDialog(option ? "Nova opção" : "Novo encaixe", *owner, true);
  d->set_secondary_text(
      option ? "Criar não escolhe esta opção nem duplica acontecimentos. "
               "Inclua participações depois."
             : "Encaixe é opcional; criar não muda participações comuns.");
  auto *name = Gtk::make_managed<Gtk::Entry>();
  name->set_max_length(200);
  set_accessible_label(*name, option ? "Nome da opção" : "Nome do encaixe");
  d->get_content_area()->append(*label("Nome"));
  d->get_content_area()->append(*name);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Criar", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj(
      [this, d, name, error, option, slot, expected](int r) {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        try {
          if (option)
            selected_option_ =
                service_.create_option(expected, slot, name->get_text());
          else {
            selected_slot_ = service_.create_slot(expected, name->get_text());
            selected_option_.clear();
          }
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work_id_);
        Glib::signal_idle().connect_once(
            sigc::track_obj([this] { show_slots(); }, *this));
      },
      *this));
  d->present();
}
void ContextualPlanningPage::show_context(const std::string &preview) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto part = selected();
    const auto view = service_.context(
        snapshot_, part.id, preview.empty() ? "" : selected_slot_, preview);
    std::optional<application::ContextualView> saved;
    if (!preview.empty())
      saved = service_.context(snapshot_, part.id);
    auto *d =
        new OverlayDialog(preview.empty() ? "Contexto desta participação"
                                          : "Comparação temporária de contexto",
                          *owner, true);
    d->set_secondary_text(
        "Origem: " +
        caption(part.title.empty() ? part.description : part.title) + " · " +
        part.id + ". " +
        (view.included ? "Participação na escolha consultada."
                       : "Fora da escolha consultada.") +
        " Não interpreta o texto.");
    if (!preview.empty()) {
      d->get_content_area()->append(
          *label("Prévia da opção: " + preview +
                 ". Nenhuma escolha foi gravada. Abaixo, origens da prévia e "
                 "avisos; consulte a escolha salva novamente ao fechar."));
      d->get_content_area()->append(*label(
          "Escolha salva: " + std::to_string(saved->declarations.size()) +
          " declarações disponíveis · prévia: " +
          std::to_string(view.declarations.size())));
      d->get_content_area()->append(
          *label("Escolha salva — valores e origens"));
      d->get_content_area()->append(
          *Gtk::make_managed<TextPager>(origin_rows(*saved)));
      if (!saved->notices.empty())
        d->get_content_area()->append(
            *Gtk::make_managed<TextPager>(saved->notices));
      d->get_content_area()->append(
          *label("Prévia — valores e origens (somente leitura)"));
    }
    d->get_content_area()->append(
        *label("Declarações consultadas com origem (valores diferentes não são "
               "resolvidos automaticamente)"));
    d->get_content_area()->append(
        *Gtk::make_managed<TextPager>(origin_rows(view)));
    if (!view.notices.empty()) {
      d->get_content_area()->append(
          *label(std::to_string(view.notices.size()) +
                 " avisos de dependência/ciclo/valores diferentes"));
      d->get_content_area()->append(
          *Gtk::make_managed<TextPager>(view.notices));
    }
    if (!preview.empty()) {
      d->add_button("Fechar", Gtk::ResponseType::CLOSE);
      d->present();
      return;
    }
    auto *pick = Gtk::make_managed<Picker>("Declaração local");
    Picker::Rows local;
    for (const auto &x : snapshot_.declarations)
      if (x.participation_id == part.id)
        local.push_back({x.id, kind(x.kind) + " · " + x.label});
    pick->set_rows(local);
    auto *local_label =
        label("Editar na origem: declarações locais desta participação");
    d->get_content_area()->append(*local_label);
    d->get_content_area()->append(*pick);
    local_label->set_visible(!local.empty());
    pick->set_visible(!local.empty());
    auto *bar = actions(*d->get_content_area());
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    Picker::Rows origins;
    auto origin_plans = std::make_shared<std::map<std::string, std::string>>();
    std::set<std::string> seen;
    for (const auto &x : view.declarations)
      if (!x.local && seen.insert(x.declaration.participation_id).second) {
        (*origin_plans)[x.declaration.participation_id] = x.plan_id;
        origins.push_back({x.declaration.participation_id,
                           x.plan_title + " / " + x.origin_title + " · " +
                               x.declaration.participation_id});
      }
    if (!origins.empty()) {
      auto *origin = Gtk::make_managed<Picker>("Origem da declaração");
      origin->set_rows(origins);
      d->get_content_area()->append(
          *label("Consultar/editar na origem, com retorno a este contexto"));
      d->get_content_area()->append(*origin);
      button(
          *bar, "Consultar origem",
          sigc::track_obj(
              [this, d, origin, error, part, origin_plans] {
                const auto id = origin->selected();
                if (!origin_plans->contains(id)) {
                  error->set_text("Escolha uma origem consultada");
                  return;
                }
                if (context_returns_.size() >= 16) {
                  error->set_text("Volte a um contexto anterior antes de "
                                  "consultar outra origem");
                  return;
                }
                try {
                  const auto back = serialize_view(ViewState::Object{
                      {"plan", snapshot_.plan_id},
                      {"participation", part.id},
                      {"slot", selected_slot_},
                      {"option", selected_option_},
                      {"scroll",
                       scroll_state(scroll_.get_vadjustment()->get_value())}});
                  navigate_context(origin_plans->at(id), id);
                  context_returns_.push_back(back);
                } catch (const std::exception &e) {
                  error->set_text(e.what());
                  return;
                }
                next(d, sigc::track_obj([this] { show_context(); }, *this));
              },
              *this));
    }
    if (!context_returns_.empty())
      button(*bar, "Voltar ao contexto consultado",
             sigc::track_obj(
                 [this, d, error] {
                   const auto id = context_returns_.back();
                   const auto separator = id.find('/');
                   try {
                     if (id.starts_with("{")) {
                       const auto frame = parse_view_state(id);
                       const auto scroll = view_scroll(frame.at("scroll"));
                       const auto slot = frame.at("slot").as_string(),
                                  option = frame.at("option").as_string();
                       if (slot.size() > 128 || option.size() > 128)
                         throw std::runtime_error(
                             "Encaixe de retorno inválido");
                       navigate_context(frame.at("plan").as_string(),
                                        frame.at("participation").as_string());
                       selected_slot_ = slot;
                       selected_option_ = option;
                       Glib::signal_idle().connect_once(sigc::track_obj(
                           [this, scroll] {
                             scroll_.get_vadjustment()->set_value(scroll);
                           },
                           *this));
                     } else
                       navigate_context(separator == std::string::npos
                                            ? snapshot_.plan_id
                                            : id.substr(0, separator),
                                        separator == std::string::npos
                                            ? id
                                            : id.substr(separator + 1));
                   } catch (const std::exception &e) {
                     error->set_text(e.what());
                     return;
                   }
                   context_returns_.pop_back();
                   next(d, sigc::track_obj([this] { show_context(); }, *this));
                 },
                 *this));
    button(*bar, "Nova declaração",
           sigc::track_obj(
               [this, d] {
                 next(d,
                      sigc::track_obj([this] { edit_declaration(); }, *this));
               },
               *this));
    if (!local.empty())
      button(*bar, "Editar declaração",
             sigc::track_obj(
                 [this, d, pick, error] {
                   const auto id = pick->selected();
                   if (id.empty()) {
                     error->set_text("Escolha uma declaração local");
                     return;
                   }
                   next(d, sigc::track_obj([this, id] { edit_declaration(id); },
                                           *this));
                 },
                 *this));
    const auto expected = observation(snapshot_);
    if (!local.empty())
      button(*bar, "Retirar declaração",
             sigc::track_obj(
                 [this, d, pick, error, expected] {
                   try {
                     service_.remove_declaration(expected, pick->selected());
                   } catch (const std::exception &e) {
                     error->set_text(e.what());
                     return;
                   }
                   refresh(work_id_);
                   next(d, sigc::track_obj([this] { show_context(); }, *this));
                 },
                 *this));
    button(*bar, "Dependências declaradas",
           sigc::track_obj(
               [this, d] {
                 next(d,
                      sigc::track_obj([this] { show_dependencies(); }, *this));
               },
               *this));
    button(*bar, "Textos associados",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { show_texts(); }, *this));
               },
               *this));
    button(*bar, "Referências desta participação",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { show_references(); }, *this));
               },
               *this));
    if (auto *last = d->get_content_area()->get_last_child(); last != bar)
      d->get_content_area()->reorder_child_after(*bar, *last);
    d->add_button("Fechar", Gtk::ResponseType::CLOSE);
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_declaration(const std::string &id) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    application::ContextualDeclaration value;
    value.participation_id = selected().id;
    if (!id.empty()) {
      const auto it = std::find_if(
          snapshot_.declarations.begin(), snapshot_.declarations.end(),
          [&](auto &x) {
            return x.id == id && x.participation_id == value.participation_id;
          });
      if (it == snapshot_.declarations.end())
        throw std::runtime_error("Declaração local ausente");
      value = *it;
    }
    auto *d = new OverlayDialog(id.empty() ? "Nova declaração"
                                           : "Editar declaração na origem",
                                *owner, true);
    d->set_secondary_text("Só esta participação; dependentes de contexto "
                          "consultam esta mesma origem. Não promove "
                          "crença/relato a fato. Valor pode ficar incompleto.");
    auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
    for (const auto *v : {"fact", "intention", "knowledge", "belief", "report"})
      type->append(v, kind(v));
    set_accessible_label(*type, "Tipo declarado pelo autor");
    if (!value.kind.empty())
      type->set_active_id(value.kind);
    auto *name = Gtk::make_managed<Gtk::Entry>();
    name->set_max_length(200);
    name->set_text(value.label);
    set_accessible_label(*name, "Assunto da declaração");
    auto *body = Gtk::make_managed<Gtk::TextView>();
    body->set_wrap_mode(Gtk::WrapMode::WORD_CHAR);
    body->get_buffer()->set_text(value.value);
    set_accessible_label(*body, "Valor declarado");
    auto *scroll = Gtk::make_managed<Gtk::ScrolledWindow>();
    scroll->set_min_content_height(160);
    scroll->set_child(*body);
    d->get_content_area()->append(*label("Tipo (escolha explícita)"));
    d->get_content_area()->append(*type);
    d->get_content_area()->append(*label("Assunto curto"));
    d->get_content_area()->append(*name);
    d->get_content_area()->append(
        *label("Informação/valor (pode ser incompleto)"));
    d->get_content_area()->append(*scroll);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Salvar declaração", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, type, name, body, error, value, expected](int r) mutable {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          value.kind = type->get_active_id();
          value.label = name->get_text();
          value.value = body->get_buffer()->get_text();
          try {
            if (value.id.empty())
              service_.declare(expected, value.participation_id, value.kind,
                               value.label, value.value);
            else
              service_.update_declaration(expected, value);
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(
              sigc::track_obj([this] { show_context(); }, *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::show_dependencies() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto part = selected();
    const auto expected = observation(snapshot_);
    auto *d = new OverlayDialog("Dependências declaradas", *owner, true);
    d->set_secondary_text("Contexto traz declarações de uma origem disponível. "
                          "Sucessão, causa, motivação e condição não herdam "
                          "estado. Nenhum vínculo é inferido pela posição.");
    Picker::Rows options;
    std::vector<std::string> rows;
    auto title = [&](const std::string &id) {
      for (const auto &x : snapshot_.participations)
        if (x.id == id)
          return caption(x.title.empty() ? x.description : x.title);
      return id;
    };
    for (const auto &x : snapshot_.dependencies)
      if (x.source == part.id || x.target == part.id) {
        options.push_back({x.id, kind(x.kind) + " · " + title(x.source) +
                                     " → " + title(x.target)});
        rows.push_back(options.back().second + "\n" + x.note + "\n" + x.id);
      }
    std::set<std::string> bridges;
    for (const auto &x : snapshot_.bridges)
      if (x.target == part.id) {
        bridges.insert(x.id);
        options.push_back({x.id, kind(x.kind) + " · outra composição / " +
                                     x.source + " → " + title(x.target)});
        rows.push_back(options.back().second + "\nComposição de origem: " +
                       x.source_plan + "\n" + x.note);
      }
    d->get_content_area()->append(*Gtk::make_managed<TextPager>(rows));
    auto *pick = Gtk::make_managed<Picker>("Dependência a retirar");
    pick->set_rows(options);
    d->get_content_area()->append(*pick);
    auto *bar = actions(*d->get_content_area());
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    button(*bar, "Nova dependência",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { edit_dependency(); }, *this));
               },
               *this));
    button(*bar, "Retirar dependência",
           sigc::track_obj(
               [this, d, pick, error, expected, bridges] {
                 try {
                   if (bridges.contains(pick->selected()))
                     service_.remove_bridge(expected, pick->selected());
                   else
                     service_.remove_dependency(expected, pick->selected());
                 } catch (const std::exception &e) {
                   error->set_text(e.what());
                   return;
                 }
                 refresh(work_id_);
                 next(d,
                      sigc::track_obj([this] { show_dependencies(); }, *this));
               },
               *this));
    button(*bar, "Receber de outra composição",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { edit_bridge(); }, *this));
               },
               *this));
    button(*bar, "Voltar ao contexto",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { show_context(); }, *this));
               },
               *this));
    d->add_button("Fechar", Gtk::ResponseType::CLOSE);
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_dependency() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto target = selected().id;
    auto *d = new OverlayDialog("Nova dependência", *owner, true);
    d->set_secondary_text("A origem escolhida aponta para esta participação. "
                          "Só Contexto recebido transmite declarações; "
                          "Condição não é avaliada como verdade pelo INDE.");
    auto *origin = Gtk::make_managed<Picker>("Origem da dependência");
    Picker::Rows rows;
    for (const auto &x : snapshot_.participations)
      if (x.id != target)
        rows.push_back(
            {x.id, caption(x.title.empty() ? x.description : x.title) + " · " +
                       x.id});
    origin->set_rows(rows);
    auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
    for (const auto *v :
         {"succession", "cause", "motivation", "condition", "context"})
      type->append(v, kind(v));
    set_accessible_label(*type, "Tipo da dependência");
    auto *note = Gtk::make_managed<Gtk::Entry>();
    note->set_max_length(2048);
    set_accessible_label(*note, "Nota da dependência (opcional)");
    d->get_content_area()->append(*label("Origem"));
    d->get_content_area()->append(*origin);
    d->get_content_area()->append(*label("Tipo (escolha explícita)"));
    d->get_content_area()->append(*type);
    d->get_content_area()->append(*label("Nota opcional"));
    d->get_content_area()->append(*note);
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Declarar dependência", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, origin, type, note, error, expected, target](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.add_dependency(expected, origin->selected(), target,
                                    type->get_active_id(), note->get_text());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(
              sigc::track_obj([this] { show_dependencies(); }, *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
} // namespace inde::ui
