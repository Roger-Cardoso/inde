#pragma once
#include <gtkmm.h>
#include <string>
namespace inde::application {
class ProjectService;
}
namespace inde::ui {
void show_contextual_projection(Gtk::Window &, application::ProjectService &,
                                const std::string &kind, const std::string &id,
                                std::size_t offset = 0);
}
