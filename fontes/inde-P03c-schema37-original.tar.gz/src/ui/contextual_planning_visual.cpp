#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "inde/project/project.hpp"
#include "inde/ui/context_menu.hpp"
#include <algorithm>
#include <cmath>
#include <memory>

namespace inde::ui {
using namespace contextual_ui;
void ContextualPlanningPage::init_visual() {
  visual_menu_.set_label("Superfície");
  const std::vector<ContextMenuAction> actions = {
      {"Anotar aqui", [this] { canvas_.capture_requested.emit(); }, "", true,
       false, false, [this] { return !snapshot_.plan_id.empty(); }},
      {"Desfazer disposição", [this] { undo_visual(); }, "", true, false, false,
       [this] { return !visual_undo_.empty(); }},
      {"Refazer disposição", [this] { undo_visual(true); }, "", true, false,
       false, [this] { return !visual_redo_.empty(); }},
      {"Disposição e aparência…", [this] { visual_properties(); }, "", true,
       false, false, [this] { return canvas_.selection().size() == 1; }},
      {"Nova faixa visual…", [this] { visual_properties("lane"); }, "", true,
       false, false, [this] { return !snapshot_.plan_id.empty(); }},
      {"Novo marco visual…", [this] { visual_properties("marker"); }, "", true,
       false, false, [this] { return !snapshot_.plan_id.empty(); }},
      {"Agrupar seleção…", [this] { group_parts(); }, "", true, false, true,
       [this] { return canvas_.selected_parts().size() > 1; }},
      {"Revisar sequência selecionada…", [this] { review_sequence(); }, "", true,
       false, false, [this] { return canvas_.selected_parts().size() > 1; }},
      {"Organizar trechos selecionados…", [this] { arrange_selection(); }, "", true,
       false, false, [this] { return canvas_.selected_parts().size() > 1; }},
      {"Selecionar faixa e trechos inteiramente contidos",
       [this] { canvas_.select_lane_contents(); }, "", true, false, false,
       [this] { return canvas_.selected_lane(); }},
      {"Desenvolver / abrir interior", [this] { develop_selected(); }, "", true,
       false, false, [this] { return canvas_.selected_parts().size() == 1; }},
      {"Expandir/recolher interior na superfície", [this] { expand_visual(); },
       "", true, false, false,
       [this] {
         return canvas_.selected_parts().size() == 1 &&
                !selected().contents_plan_id.empty();
       }},
      {"Editar conteúdo compartilhado", [this] { edit_content(false); }, "",
       true, false, false,
       [this] { return canvas_.selected_parts().size() == 1; }},
      {"Papel neste conjunto…", [this] { edit_role(); }, "", true, false, false,
       [this] { return canvas_.selected_parts().size() == 1; }},
      {"Declarar ligação…", [this] { edit_dependency(); }, "", true, false,
       false, [this] { return canvas_.selected_parts().size() == 1; }},
      {"Focalizar seleção", [this] { canvas_.fit(true); }},
      {"Remover faixa ou marco visual",
       [this] {
         const auto ids = canvas_.selection();
         auto values = canvas_.items();
         std::erase_if(values, [&](const auto &v) {
           return v.kind != "block" && ids.contains(v.id);
         });
         execute([&] { commit_visual(snapshot_, values); });
       },
       "", true, true, true,
       [this] {
         return std::any_of(canvas_.items().begin(), canvas_.items().end(),
                            [this](const auto &v) {
                              return v.kind != "block" &&
                                     canvas_.selection().contains(v.id);
                            });
       }}};
  visual_menu_.set_popover(*create_action_popover(actions));
  attach_context_menu(canvas_, actions, [this](double x, double y, Gdk::ModifierType mods) {
    canvas_.context_target(x, y, mods);
  });
  visual_bar_.append(list_mode_);
  visual_bar_.append(fit_);
  visual_bar_.append(zoom_out_);
  visual_bar_.append(zoom_in_);
  visual_bar_.append(visual_menu_);
  visual_bar_.append(visual_edit_);
  visual_bar_.append(expand_);
  append(visual_bar_);
  surface_.add(canvas_, "visual");
  surface_.add(scroll_, "list");
  surface_.set_vexpand(true);
  surface_.set_visible_child("visual");
  append(surface_);
  list_mode_.set_tooltip_text("Alternar para a lista com os mesmos trechos e "
                              "comandos; não converte dados");
  set_accessible_label(zoom_in_, "Aproximar composição visual");
  set_accessible_label(zoom_out_, "Afastar composição visual");
  list_mode_.signal_toggled().connect([this] {
    surface_.set_visible_child(list_mode_.get_active() ? "list" : "visual");
    pager_.set_visible(list_mode_.get_active() &&
                       snapshot_.participations.size() > 50);
    if (list_mode_.get_active())
      render();
  });
  fit_.signal_clicked().connect([this] { canvas_.fit(); });
  zoom_in_.signal_clicked().connect([this] { canvas_.zoom(1.2); });
  zoom_out_.signal_clicked().connect([this] { canvas_.zoom(1 / 1.2); });
  visual_edit_.signal_clicked().connect([this] { visual_properties(); });
  expand_.signal_clicked().connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::expand_visual));
  canvas_.selection_changed.connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::visual_selection));
  canvas_.committed.connect([this](const auto &items) {
    const auto values =
        items; // Widget refresh replaces its vector after commit.
    try {
      commit_visual(snapshot_, values);
      status_.emit("Disposição visual gravada; reversão disponível no "
                   "histórico do Projeto.");
    } catch (const std::exception &e) {
      status_.emit(e.what());
    }
    // On success or conflict refresh once; discard any uncommitted preview.
    refresh(work_id_);
  });
  canvas_.capture_requested.connect([this] {
    if (snapshot_.plan_id.empty())
      return;
    const auto xy = canvas_.insertion();
    application::ContextualVisualItem v;
    v.x = std::clamp<std::int64_t>(std::llround(xy[0]), -100000, 100000);
    v.y = std::clamp<std::int64_t>(std::llround(xy[1]), -100000, 100000);
    capture_placement_ = v;
    quick_.grab_focus();
    status_.emit("Escreva a ideia acima e pressione Enter: será criada neste "
                 "ponto. Sem classificação obrigatória.");
  });
  canvas_.open_requested.connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::develop_selected));
  canvas_.properties_requested.connect([this] { visual_properties(); });
  canvas_.group_requested.connect(
      sigc::mem_fun(*this, &ContextualPlanningPage::group_parts));
  auto undo_keys = Gtk::EventControllerKey::create();
  undo_keys->signal_key_pressed().connect(
      [this](guint key, guint, Gdk::ModifierType mods) {
        const auto mask = static_cast<unsigned>(mods) &
                          (GDK_CONTROL_MASK | GDK_SHIFT_MASK | GDK_ALT_MASK |
                           GDK_SUPER_MASK | GDK_META_MASK);
        if ((key == GDK_KEY_z || key == GDK_KEY_Z) &&
            (mask == GDK_CONTROL_MASK ||
             mask == (GDK_CONTROL_MASK | GDK_SHIFT_MASK))) {
          undo_visual(mask != GDK_CONTROL_MASK);
          return true;
        }
        if ((key == GDK_KEY_y || key == GDK_KEY_Y) &&
            mask == GDK_CONTROL_MASK) {
          undo_visual(true);
          return true;
        }
        return false;
      },
      false);
  canvas_.add_controller(undo_keys);
}
void ContextualPlanningPage::commit_visual(
    const application::ContextualSnapshot &expected,
    const std::vector<application::ContextualVisualItem> &items) {
  const auto before = service_.snapshot(expected.plan_id);
  if (before.revision != expected.revision ||
      before.project_id != expected.project_id)
    throw std::runtime_error(
        "Composição mudou; atualize antes de confirmar. Nada foi alterado");
  const auto after = service_.save_visual(expected, items);
  if (after.revision == before.revision)
    return;
  visual_redo_.clear();
  visual_undo_.push_back({after.revision, before.visual});
  if (visual_undo_.size() > 16)
    visual_undo_.erase(visual_undo_.begin());
}
void ContextualPlanningPage::undo_visual(bool redo) {
  auto &from = redo ? visual_redo_ : visual_undo_;
  auto &to = redo ? visual_undo_ : visual_redo_;
  if (from.empty())
    return;
  try {
    const auto now = service_.snapshot(snapshot_.plan_id);
    if (now.revision != from.back().revision)
      throw std::runtime_error("O conjunto mudou após a disposição. Nada foi "
                               "desfeito; consulte o histórico do Projeto.");
    const auto next = service_.save_visual(now, from.back().items);
    from.pop_back();
    to.push_back({next.revision, now.visual});
    if (to.size() > 16)
      to.erase(to.begin());
    refresh(work_id_);
    status_.emit(
        redo ? "Disposição refeita, sem alterar conteúdo ou relações."
             : "Disposição desfeita, sem alterar conteúdo ou relações.");
  } catch (const std::exception &e) {
    visual_undo_.clear();
    visual_redo_.clear();
    refresh(work_id_);
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::visual_selection() {
  if (loading_)
    return;
  const auto parts = canvas_.selected_parts();
  selected_id_ = parts.empty() ? "" : parts.front();
  if (!selected_id_.empty()) {
    const auto at = std::find_if(
        snapshot_.participations.begin(), snapshot_.participations.end(),
        [this](const auto &p) { return p.id == selected_id_; });
    const auto index =
        static_cast<std::size_t>(at - snapshot_.participations.begin());
    if (index / 50 * 50 != offset_) {
      offset_ = index / 50 * 50;
      render();
      return;
    }
    loading_ = true;
    rows_.select_row(*rows_.get_row_at_index(index - offset_));
    loading_ = false;
  } else {
    loading_ = true;
    rows_.unselect_all();
    loading_ = false;
  }
  selection_actions();
  visual_edit_.set_sensitive(canvas_.selection().size() == 1);
  expand_.set_visible(!selected_id_.empty() &&
                      canvas_.selected_parts().size() == 1 &&
                      !selected().contents_plan_id.empty());
}
void ContextualPlanningPage::refresh_visual() {
  if (visual_plan_ != snapshot_.plan_id) {
    capture_placement_.reset();
    visual_plan_ = snapshot_.plan_id;
    visual_undo_.clear();
    visual_redo_.clear();
  }
  if (!visual_undo_.empty() &&
      visual_undo_.back().revision != snapshot_.revision)
    visual_undo_.clear();
  if (!visual_redo_.empty() &&
      visual_redo_.back().revision != snapshot_.revision)
    visual_redo_.clear();
  canvas_.set_data(snapshot_);
  canvas_.set_included(service_.included_participations(snapshot_));
  const auto chosen = canvas_.selected_parts();
  if (!selected_id_.empty() &&
      std::find(chosen.begin(), chosen.end(), selected_id_) == chosen.end())
    canvas_.select_part(selected_id_);
  visual_edit_.set_sensitive(canvas_.selection().size() == 1);
  expand_.set_visible(!selected_id_.empty() &&
                      canvas_.selected_parts().size() == 1 &&
                      !selected().contents_plan_id.empty());
  visual_menu_.set_sensitive(!snapshot_.plan_id.empty());
  // Bounded one-level preview, never recursively expand shared paths.
  std::size_t loaded{};
  std::map<std::string, std::vector<std::string>> previews;
  for (const auto &v : canvas_.items())
    if (v.expanded && ++loaded <= 8) {
      const auto p = std::find_if(
          snapshot_.participations.begin(), snapshot_.participations.end(),
          [&](const auto &p) { return p.id == v.participation_id; });
      if (p != snapshot_.participations.end() && !p->contents_plan_id.empty())
        previews[p->contents_plan_id].push_back(p->id);
    }
  // Reused interiors are read once per refresh, not once per representation.
  // Keep just one child snapshot live, rather than caching up to eight 8-MiB aggregates.
  for (const auto &[plan, parts] : previews)
    try {
      const auto child = service_.snapshot(plan);
      for (const auto &part : parts)
        canvas_.set_preview(part, child);
    } catch (const std::exception &e) {
      status_.emit(e.what());
    }
  selection_actions();
}
void ContextualPlanningPage::expand_visual() {
  if (selected_id_.empty() || canvas_.selected_parts().size() != 1)
    return;
  auto items = canvas_.items();
  for (auto &v : items)
    if (v.participation_id == selected_id_) {
      if (selected().contents_plan_id.empty()) {
        status_.emit("Desenvolva o interior antes de expandi-lo.");
        return;
      }
      v.expanded = !v.expanded;
      if (v.expanded) {
        v.width = std::max<std::int64_t>(v.width, 480);
        v.height = std::max<std::int64_t>(v.height, 200);
      }
    }
  execute([&] { commit_visual(snapshot_, items); });
}
void ContextualPlanningPage::visual_properties(const std::string &creating) {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner || snapshot_.plan_id.empty())
    return;
  application::ContextualVisualItem value;
  if (creating.empty()) {
    if (canvas_.selection().size() != 1) {
      status_.emit("Selecione um elemento para ajustar sua disposição.");
      return;
    }
    const auto at = std::find_if(
        canvas_.items().begin(), canvas_.items().end(),
        [this](const auto &v) { return canvas_.selection().contains(v.id); });
    if (at == canvas_.items().end())
      return;
    value = *at;
  } else {
    value.id = project::new_uuid();
    value.kind = creating;
    const auto pos = canvas_.insertion();
    value.x = std::clamp<std::int64_t>(std::llround(pos[0]), -100000, 100000);
    value.y = std::clamp<std::int64_t>(std::llround(pos[1]), -100000, 100000);
    value.width = creating == "lane" ? 1200 : 180;
    value.height = creating == "lane" ? 220 : 500;
    value.label = creating == "lane" ? "Nova faixa" : "Novo marco";
  }
  const auto expected = observation(snapshot_);
  const auto original = canvas_.items();
  auto *d = new OverlayDialog(creating == "lane"     ? "Nova faixa visual"
                              : creating == "marker" ? "Novo marco visual"
                                                     : "Disposição visual",
                              *owner, true);
  d->set_secondary_text(
      "Somente esta composição. Posição, extensão e curva são organização "
      "visual; não alteram ordem, datas, conteúdo compartilhado ou relações. "
      "Há reversão no histórico.");
  auto *name = Gtk::make_managed<Gtk::Entry>();
  name->set_max_length(200);
  name->set_text(value.label);
  auto *colour = Gtk::make_managed<Gtk::Entry>();
  colour->set_max_length(7);
  colour->set_text(value.color);
  set_accessible_label(*name, "Legenda visual local");
  set_accessible_label(*colour, "Cor visual hexadecimal");
  auto *shape = Gtk::make_managed<Gtk::ComboBoxText>();
  shape->append("box", "Bloco");
  shape->append("straight", "Percurso reto");
  shape->append("ecg", "Percurso quebrado");
  shape->append("wavy", "Percurso curvo");
  shape->set_active_id(value.shape);
  shape->set_sensitive(value.kind == "block");
  set_accessible_label(*shape, "Forma visual sem significado inferido");
  d->get_content_area()->append(*label("Legenda visual (opcional)"));
  d->get_content_area()->append(*name);
  auto *palette = Gtk::make_managed<Gtk::FlowBox>();
  palette->set_selection_mode(Gtk::SelectionMode::NONE);
  palette->set_max_children_per_line(6);
  palette->set_min_children_per_line(3);
  for (const auto &[caption, hex] :
       std::initializer_list<std::pair<const char *, const char *>>{
           {"Azul", "#4589b2"},
           {"Verde", "#38866d"},
           {"Violeta", "#8d61ac"},
           {"Âmbar", "#9a7030"},
           {"Vermelho", "#ad4c58"},
           {"Cinza", "#697887"}}) {
    auto *button = Gtk::make_managed<Gtk::Button>();
    auto *row = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 4);
    auto *swatch = Gtk::make_managed<Gtk::DrawingArea>();
    swatch->set_content_width(14);
    swatch->set_content_height(14);
    swatch->set_draw_func([rgba = Gdk::RGBA(hex)](const auto &cr, int, int) {
      cr->set_source_rgba(rgba.get_red(), rgba.get_green(), rgba.get_blue(), 1);
      cr->paint();
    });
    row->append(*swatch);
    row->append(*label(caption));
    button->set_child(*row);
    set_accessible_label(*button, std::string("Cor ") + caption);
    button->signal_clicked().connect(
        [colour, value = std::string(hex)] { colour->set_text(value); });
    palette->append(*button);
  }
  d->get_content_area()->append(*palette);
  d->get_content_area()->append(*label("Cor (#RRGGBB)"));
  d->get_content_area()->append(*colour);
  d->get_content_area()->append(*shape);
  auto *grid = Gtk::make_managed<Gtk::Grid>();
  grid->set_column_spacing(10);
  grid->set_row_spacing(5);
  std::array<Gtk::SpinButton *, 4> numbers{};
  const std::array<std::int64_t, 4> initial = {value.x, value.y, value.width,
                                               value.height};
  const std::array<std::string, 4> names = {
      "Posição horizontal", "Posição vertical", "Extensão horizontal",
      "Altura visual"};
  for (int i = 0; i < 4; ++i) {
    numbers[i] = Gtk::make_managed<Gtk::SpinButton>();
    numbers[i]->set_range(i < 2    ? -100000
                          : i == 2 ? 80
                                   : 64,
                          i < 2    ? 100000
                          : i == 2 ? 20000
                                   : 4000);
    numbers[i]->set_increments(10, 100);
    numbers[i]->set_size_request(200, -1);
    numbers[i]->set_value(initial[i]);
    numbers[i]->set_name(names[i]);
    set_accessible_label(*numbers[i], names[i]);
    grid->attach(*label(names[i]), 0, i);
    grid->attach(*numbers[i], 1, i);
  }
  d->get_content_area()->append(*grid);
  auto *curve = Gtk::make_managed<Gtk::Expander>(
      "Alturas dos cinco pontos — ajuste opcional por teclado");
  auto *pointbox = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 3);
  std::array<Gtk::SpinButton *, 5> points{};
  for (int i = 0; i < 5; ++i) {
    auto *row = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 6);
    points[i] = Gtk::make_managed<Gtk::SpinButton>();
    points[i]->set_range(0, 1000);
    points[i]->set_increments(10, 100);
    points[i]->set_size_request(200, -1);
    points[i]->set_value(value.curve[i]);
    const auto title = "Altura visual do ponto " + std::to_string(i + 1);
    set_accessible_label(*points[i], title);
    row->append(*label(title));
    row->append(*points[i]);
    pointbox->append(*row);
  }
  curve->set_child(*pointbox);
  d->get_content_area()->append(*curve);
  auto *error = label("");
  error->add_css_class("error");
  d->get_content_area()->append(*error);
  d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
  d->add_button("Salvar disposição", Gtk::ResponseType::ACCEPT);
  d->signal_response().connect(sigc::track_obj(
      [this, d, name, colour, shape, numbers, points, error, value, expected,
       original, creating](int r) mutable {
        if (r != Gtk::ResponseType::ACCEPT)
          return;
        try {
          value.label = name->get_text();
          value.color = colour->get_text();
          value.shape = shape->get_active_id();
          value.x = numbers[0]->get_value_as_int();
          value.y = numbers[1]->get_value_as_int();
          value.width = numbers[2]->get_value_as_int();
          value.height = numbers[3]->get_value_as_int();
          for (int i = 0; i < 5; ++i)
            value.curve[i] = points[i]->get_value_as_int();
          auto items = original;
          if (creating.empty()) {
            for (auto &v : items)
              if (v.id == value.id)
                v = value;
          } else
            items.push_back(value);
          commit_visual(expected, items);
        } catch (const std::exception &e) {
          error->set_text(e.what());
          d->keep_open_on_response();
          return;
        }
        refresh(work_id_);
      },
      *this));
  d->present();
}
} // namespace inde::ui
