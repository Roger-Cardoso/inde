#include "inde/ui/visibility_lens_page.hpp"
#include "inde/application/text_clipboard.hpp"
#include "inde/project/document_state.hpp"
#include "inde/ui/accessibility.hpp"
#include <algorithm>
#include <stdexcept>
namespace inde::ui {
namespace {
struct LensClipboardRead {
  Glib::RefPtr<Gio::InputStream> stream;
  Glib::RefPtr<Gio::Cancellable> cancel;
  std::string text;
  std::function<void(std::string, std::string)> done;
};
void read_lens_clipboard_chunk(const std::shared_ptr<LensClipboardRead> &s) {
  s->stream->read_bytes_async(
      64 * 1024,
      [s](const Glib::RefPtr<Gio::AsyncResult> &r) {
        try {
          auto chunk = s->stream->read_bytes_finish(r);
          if (s->cancel->is_cancelled())
            return;
          gsize n{};
          const auto *bytes = static_cast<const char *>(chunk->get_data(n));
          if (s->text.size() + n > application::clipboard_limit) {
            s->done({}, "Colagem excede 16 MiB; nenhum texto foi recortado");
            return;
          }
          if (!n) {
            s->done(std::move(s->text), {});
            return;
          }
          s->text.append(bytes, n);
          read_lens_clipboard_chunk(s);
        } catch (const Glib::Error &e) {
          if (!s->cancel->is_cancelled())
            s->done({}, e.what());
        }
      },
      s->cancel);
}
} // namespace
VisibilityLensPage::VisibilityLensPage()
    : Gtk::Box(Gtk::Orientation::VERTICAL, 8) {
  set_hexpand(true);
  set_vexpand(true);
  set_name("visibility-lens-page");
  toolbar_.add_css_class("toolbar-surface");
  toolbar_.append(back_);
  toolbar_.append(title_);
  title_.set_hexpand(true);
  title_.set_xalign(0);
  title_.set_ellipsize(Pango::EllipsizeMode::END);
  toolbar_.append(undo_);
  toolbar_.append(redo_);
  toolbar_.append(save_);
  append(toolbar_);
  explanation_.set_xalign(0);
  explanation_.set_wrap(true);
  explanation_.set_text(
      "Lente de trabalho: somente os trechos exibidos são editados. Na junção, "
      "inserir pertence ao próximo trecho; no fim, ao anterior. "
      "Separadores junto ao omitido são preservados para não fundir blocos "
      "ocultos. "
      "Marcações, alternativas, arrasto e ferramentas completas ficam no "
      "Documento integral. Este perfil não escolhe a saída editorial.");
  explanation_.add_css_class("dim-label");
  append(explanation_);
  editor_.set_name("visibility-lens-editor");
  editor_.set_wrap_mode(Gtk::WrapMode::WORD_CHAR);
  editor_.set_left_margin(28);
  editor_.set_right_margin(28);
  editor_.set_top_margin(20);
  editor_.set_bottom_margin(28);
  editor_.add_css_class("writing-editor");
  set_accessible_label(editor_, "Texto da lente de trabalho");
  scroll_.set_child(editor_);
  scroll_.set_hexpand(true);
  scroll_.set_vexpand(true);
  scroll_.add_css_class("writing-paper");
  append(scroll_);
  status_.set_xalign(0);
  status_.set_wrap(true);
  append(status_);
  discard_draft_.set_visible(false);
  append(discard_draft_);
  discard_draft_.signal_clicked().connect([this] {
    if (!read_source)
      return;
    try {
      pending_.clear();
      refresh(read_source());
      discard_draft_.set_visible(false);
    } catch (const std::exception &e) {
      status_.set_text(e.what());
    }
  });
  auto buffer = editor_.get_buffer();
  buffer->set_enable_undo(false);
  const std::weak_ptr<int> alive = lifetime_;
  buffer->signal_insert().connect(
      [this, alive](const Gtk::TextBuffer::iterator &at, const Glib::ustring &s,
                    int) {
        if (alive.expired() || restoring_)
          return;
        if (s.bytes() > 16 * 1024 * 1024 ||
            s.raw().find('\0') != std::string::npos) {
          g_signal_stop_emission_by_name(editor_.get_buffer()->gobj(),
                                         "insert-text");
          status_.set_text("Texto excedido/inválido; nada aplicado.");
          return;
        }
        queue_edit(at.get_offset(), at.get_offset(), s.raw());
      },
      false);
  buffer->signal_erase().connect(
      [this, alive](const Gtk::TextBuffer::iterator &a,
                    const Gtk::TextBuffer::iterator &b) {
        if (!alive.expired() && !restoring_)
          queue_edit(a.get_offset(), b.get_offset(), "");
      },
      false);
  g_signal_connect(editor_.gobj(), "preedit-changed",
                   G_CALLBACK(+[](GtkTextView *, const char *s, gpointer p) {
                     static_cast<VisibilityLensPage *>(p)->preedit_ = s && *s;
                   }),
                   this);
  g_signal_connect(editor_.gobj(), "paste-clipboard",
                   G_CALLBACK(+[](GtkTextView *v, gpointer p) {
                     g_signal_stop_emission_by_name(v, "paste-clipboard");
                     static_cast<VisibilityLensPage *>(p)->paste();
                   }),
                   this);
  auto keys = Gtk::EventControllerKey::create();
  keys->set_propagation_phase(Gtk::PropagationPhase::CAPTURE);
  keys->signal_key_pressed().connect(
      [this](guint k, guint, Gdk::ModifierType mods) {
        if (preedit_)
          return false;
        const auto m =
            static_cast<unsigned>(mods) &
            (GDK_CONTROL_MASK | GDK_SHIFT_MASK | GDK_ALT_MASK | GDK_SUPER_MASK);
        if (m == GDK_CONTROL_MASK || m == (GDK_CONTROL_MASK | GDK_SHIFT_MASK)) {
          if (k == GDK_KEY_z || k == GDK_KEY_Z) {
            run_history(m & GDK_SHIFT_MASK);
            return true;
          }
          if (k == GDK_KEY_v || k == GDK_KEY_V) {
            paste();
            return true;
          }
          if (k == GDK_KEY_s || k == GDK_KEY_S) {
            try {
              flush();
              if (save)
                save();
              status_.set_text("Documento integral salvo.");
            } catch (const std::exception &e) {
              status_.set_text(e.what());
            }
            return true;
          }
        }
        return false;
      },
      false);
  editor_.add_controller(keys);
  // Primary-selection and native text DnD have asynchronous context semantics
  // not shared with our checked clipboard. Keep them out of this bounded lens.
  auto middle = Gtk::GestureClick::create();
  middle->set_button(2);
  middle->set_propagation_phase(Gtk::PropagationPhase::CAPTURE);
  middle->signal_pressed().connect(
      [gesture = middle.get()](int, double, double) {
        gesture->set_state(Gtk::EventSequenceState::CLAIMED);
      });
  editor_.add_controller(middle);
  auto *controllers =
      gtk_widget_observe_controllers(GTK_WIDGET(editor_.gobj()));
  for (guint i = 0; i < g_list_model_get_n_items(controllers); ++i) {
    auto *c = G_OBJECT(g_list_model_get_item(controllers, i));
    if (GTK_IS_DROP_TARGET(c) || GTK_IS_DROP_TARGET_ASYNC(c))
      gtk_event_controller_set_propagation_phase(GTK_EVENT_CONTROLLER(c),
                                                 GTK_PHASE_NONE);
    g_object_unref(c);
  }
  g_object_unref(controllers);
  back_.signal_clicked().connect([this] {
    try {
      flush();
      if (source_ && read_source && commit) {
        auto now = read_source();
        if (!project::same_document_state(now.document, source_->document,
                                          false))
          throw std::runtime_error(
              "A origem mudou; reabra o contexto antes de retornar");
        auto after = now;
        auto buffer = editor_.get_buffer();
        auto origin = [this](std::size_t p) {
          for (const auto &r : projection_.spans)
            if (r.view_start <= p && p < r.view_end)
              return r.source_start + p - r.view_start;
          return projection_.spans.empty()
                     ? source_->selection.cursor
                     : projection_.spans.back().source_end;
        };
        after.selection = {
            origin(buffer->get_iter_at_mark(buffer->get_insert()).get_offset()),
            origin(buffer->get_iter_at_mark(buffer->get_selection_bound())
                       .get_offset())};
        commit(now, std::move(after));
      }
      if (back)
        back();
    } catch (const std::exception &e) {
      status_.set_text(e.what());
    }
  });
  undo_.signal_clicked().connect([this] { run_history(false); });
  redo_.signal_clicked().connect([this] { run_history(true); });
  save_.signal_clicked().connect([this] {
    try {
      flush();
      if (save)
        save();
      status_.set_text("Documento integral salvo; perfil de trabalho não "
                       "altera a saída editorial.");
    } catch (const std::exception &e) {
      status_.set_text(e.what());
    }
  });
}
VisibilityLensPage::~VisibilityLensPage() {
  lifetime_.reset();
  commit_idle_.disconnect();
  if (paste_cancel_)
    paste_cancel_->cancel();
  g_signal_handlers_disconnect_by_data(editor_.gobj(), this);
}
void VisibilityLensPage::reset() {
  commit_idle_.disconnect();
  if (paste_cancel_)
    paste_cancel_->cancel();
  paste_cancel_.reset();
  ++generation_;
  source_.reset();
  pending_.clear();
  projection_ = {};
  discard_draft_.set_visible(false);
  restoring_ = true;
  editor_.get_buffer()->set_text("");
  restoring_ = false;
  preedit_ = false;
}
void VisibilityLensPage::open(application::DocumentEditState source,
                              const std::string &profile) {
  flush();
  projection_.profile_id = profile;
  refresh(std::move(source));
  Glib::signal_idle().connect_once(sigc::track_obj(
      [this] {
        if (get_mapped())
          editor_.grab_focus();
      },
      *this));
}
void VisibilityLensPage::refresh(application::DocumentEditState source) {
  const auto next =
      application::project_visibility(source.document, projection_.profile_id);
  if (paste_cancel_)
    paste_cancel_->cancel();
  ++generation_;
  restoring_ = true;
  source_ = std::move(source);
  projection_ = next;
  auto buffer = editor_.get_buffer();
  const auto previous = buffer->get_text().raw();
  if (previous != projection_.text) {
    const auto delta = application::text_delta(previous, projection_.text);
    const auto start =
        project::utf8_character_count(previous.substr(0, delta.byte_offset));
    auto a = buffer->get_iter_at_offset(start),
         b = buffer->get_iter_at_offset(
             start + project::utf8_character_count(delta.removed));
    auto at = buffer->erase(a, b);
    if (!delta.inserted.empty())
      buffer->insert(at, delta.inserted);
  }
  buffer->remove_all_tags(buffer->begin(), buffer->end());
  render_styles();
  const auto at = application::visibility_view_offset(
      projection_, source_->selection.cursor);
  if (buffer->get_iter_at_mark(buffer->get_insert()).get_offset() !=
          static_cast<int>(at) ||
      buffer->get_iter_at_mark(buffer->get_selection_bound()).get_offset() !=
          static_cast<int>(at))
    buffer->place_cursor(buffer->get_iter_at_offset(at));
  restoring_ = false;
  const auto &p = *std::find_if(
      source_->document.visibility_profiles.begin(),
      source_->document.visibility_profiles.end(),
      [&](const auto &p) { return p.id == projection_.profile_id; });
  title_.set_text(
      p.name + " · " +
      std::to_string(project::utf8_character_count(projection_.text)) + "/" +
      std::to_string(project::utf8_character_count(source_->document.content)) +
      " caracteres");
  status_.set_text(projection_.diagnostics.empty()
                       ? "Trechos omitidos continuam na origem. Clipboard usa "
                         "somente o texto exibido."
                       : std::to_string(projection_.diagnostics.size()) +
                             " critério(s) sem trecho confiável. Alterações "
                             "continuam na origem; reveja a ancoragem ou o "
                             "perfil no Documento integral.");
}
void VisibilityLensPage::queue_edit(std::size_t a, std::size_t b,
                                    const std::string &s) {
  // A native mutation invalidates an outstanding paste even before its idle
  // transaction is consolidated, including if the caret returns to its offset.
  ++generation_;
  if (paste_cancel_)
    paste_cancel_->cancel();
  pending_.push_back({a, b, s});
  commit_idle_.disconnect();
  commit_idle_ = Glib::signal_idle().connect([this] {
    if (preedit_)
      return true;
    try {
      flush();
    } catch (const std::exception &e) {
      status_.set_text(e.what());
    }
    return false;
  });
}
void VisibilityLensPage::flush() {
  if (preedit_)
    throw std::runtime_error(
        "Conclua a composição de texto antes de sair da lente");
  if (flushing_ || pending_.empty())
    return;
  commit_idle_.disconnect();
  flushing_ = true;
  try {
    if (!source_ || !read_source || !commit)
      throw std::runtime_error("Lente sem origem ativa");
    auto now = read_source();
    if (!project::same_document_state(now.document, source_->document, false))
      throw std::runtime_error(
          "A origem mudou; edição da lente não foi aplicada");
    auto after = application::edit_visibility(now, projection_, pending_);
    commit(now, std::move(after));
    pending_.clear();
    refresh(read_source());
    flushing_ = false;
    discard_draft_.set_visible(false);
  } catch (const std::exception &e) {
    flushing_ = false;
    discard_draft_.set_visible(true);
    throw std::runtime_error(std::string(e.what()) +
                             ". Edição não aplicada preservada nesta lente: "
                             "copie o texto ou descarte-a explicitamente.");
  }
}
void VisibilityLensPage::run_history(bool redo) {
  try {
    flush();
    if (history)
      history(redo);
    if (source_ && read_source)
      refresh(read_source());
  } catch (const std::exception &e) {
    status_.set_text(e.what());
  }
}
void VisibilityLensPage::paste() {
  try {
    flush();
  } catch (const std::exception &e) {
    status_.set_text(e.what());
    return;
  }
  if (!source_)
    return;
  if (paste_cancel_)
    paste_cancel_->cancel();
  paste_cancel_ = Gio::Cancellable::create();
  const auto generation = generation_;
  auto buffer = editor_.get_buffer();
  const auto a = buffer->get_iter_at_mark(buffer->get_insert()).get_offset(),
             b = buffer->get_iter_at_mark(buffer->get_selection_bound())
                     .get_offset();
  const std::weak_ptr<int> alive = lifetime_;
  auto clipboard = editor_.get_clipboard();
  auto request = std::make_shared<LensClipboardRead>();
  request->cancel = paste_cancel_;
  request->done = [this, alive, generation, a, b](std::string text,
                                                  std::string error) {
    if (alive.expired())
      return;
    try {
      if (!error.empty())
        throw std::runtime_error(error);
      auto buffer = editor_.get_buffer();
      if (generation != generation_ || !source_ || !editor_.get_mapped() ||
          buffer->get_iter_at_mark(buffer->get_insert()).get_offset() != a ||
          buffer->get_iter_at_mark(buffer->get_selection_bound())
                  .get_offset() != b) {
        status_.set_text("Colagem cancelada: origem, perfil ou seleção mudou.");
        return;
      }
      if (!g_utf8_validate(text.data(), text.size(), nullptr))
        throw std::runtime_error("Clipboard não contém texto UTF-8 válido");
      if (text.empty())
        return;
      buffer->begin_user_action();
      auto begin = buffer->get_iter_at_offset(std::min(a, b)),
           end = buffer->get_iter_at_offset(std::max(a, b));
      auto at = buffer->erase(begin, end);
      buffer->insert(at, text);
      buffer->end_user_action();
    } catch (const Glib::Error &e) {
      status_.set_text(e.what());
    } catch (const std::exception &e) {
      status_.set_text(e.what());
    }
  };
  clipboard->read_async(
      {"text/plain;charset=utf-8", "text/plain"}, Glib::PRIORITY_DEFAULT,
      [clipboard, request](const Glib::RefPtr<Gio::AsyncResult> &r) {
        try {
          Glib::ustring mime;
          request->stream = clipboard->read_finish(r, mime);
          if (!request->cancel->is_cancelled())
            read_lens_clipboard_chunk(request);
        } catch (const Glib::Error &e) {
          if (!request->cancel->is_cancelled())
            request->done({}, e.what());
        }
      },
      request->cancel);
}
void VisibilityLensPage::render_styles() {
  if (!source_)
    return;
  auto buffer = editor_.get_buffer();
  for (const auto &f : source_->document.formatting) {
    auto &tag = tags_[{f.style, f.value}];
    if (!tag) {
      tag = buffer->create_tag();
      using S = project::DocumentTextStyle;
      switch (f.style) {
      case S::Bold:
        tag->property_weight() = Pango::Weight::BOLD;
        break;
      case S::Italic:
        tag->property_style() = Pango::Style::ITALIC;
        break;
      case S::Underline:
        tag->property_underline() = Pango::Underline::SINGLE;
        break;
      case S::Strikethrough:
        tag->property_strikethrough() = true;
        break;
      case S::Foreground:
        tag->property_foreground() = f.value;
        break;
      case S::FontFamily:
        tag->property_family() = f.value;
        break;
      case S::FontSize:
        tag->property_size_points() = std::stod(f.value);
        break;
      case S::AlignLeft:
        tag->property_justification() = Gtk::Justification::LEFT;
        break;
      case S::AlignCenter:
        tag->property_justification() = Gtk::Justification::CENTER;
        break;
      case S::AlignRight:
        tag->property_justification() = Gtk::Justification::RIGHT;
        break;
      case S::AlignJustify:
        tag->property_justification() = Gtk::Justification::FILL;
        break;
      case S::Quote:
        tag->property_style() = Pango::Style::ITALIC;
        tag->property_left_margin() = 28;
        tag->property_indent() = 10;
        break;
      case S::Heading:
      case S::Subheading:
      case S::Heading2:
      case S::Heading3:
      case S::Heading4:
      case S::Heading5:
      case S::Heading6:
        tag->property_weight() = Pango::Weight::BOLD;
        tag->property_scale() = f.style == S::Heading      ? 1.6
                                : f.style == S::Subheading ? 1.2
                                : f.style == S::Heading2   ? 1.4
                                : f.style == S::Heading3   ? 1.3
                                : f.style == S::Heading4   ? 1.2
                                : f.style == S::Heading5   ? 1.1
                                                           : 1.0;
        tag->property_pixels_above_lines() = 10;
        tag->property_pixels_below_lines() = 6;
        break;
      }
    }
    for (const auto &r : projection_.spans) {
      const auto a = std::max(f.start_offset, r.source_start),
                 b = std::min(f.end_offset, r.source_end);
      if (a < b)
        buffer->apply_tag(
            tag, buffer->get_iter_at_offset(r.view_start + a - r.source_start),
            buffer->get_iter_at_offset(r.view_start + b - r.source_start));
    }
  }
}
} // namespace inde::ui
