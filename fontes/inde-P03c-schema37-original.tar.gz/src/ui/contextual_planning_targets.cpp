#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "inde/application/project_service.hpp"
#include <memory>
#include <optional>
namespace inde::ui {
using namespace contextual_ui;
void ContextualPlanningPage::associate_target() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto part = selected().id;
    auto *d = new OverlayDialog("Associar trecho ou ocorrência", *owner, true);
    d->set_secondary_text(
        "Aponte para um trecho já marcado no Documento ou uma ocorrência da "
        "montagem. Sem copiar prosa, certificar realização ou alterar ordens. "
        "Também pode marcar uma nova seleção na consulta abaixo; destinos "
        "não reconciliados são recusados.");
    auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
    type->append("document", "Trecho marcado de Documento");
    type->append("composition", "Ocorrência de montagem");
    type->set_active_id("document");
    set_accessible_label(*type, "Formato do alvo textual");
    auto *search = Gtk::make_managed<Gtk::Entry>();
    search->set_max_length(200);
    search->set_placeholder_text("Buscar Documento ou montagem pelo nome");
    set_accessible_label(*search, "Buscar fonte textual");
    auto *find = Gtk::make_managed<Gtk::Button>("Buscar fontes textuais");
    auto *pick = Gtk::make_managed<Picker>("Fonte textual");
    auto *target = Gtk::make_managed<Picker>("Trecho ou ocorrência");
    auto *before = Gtk::make_managed<Gtk::Button>("Fontes anteriores"),
         *after = Gtk::make_managed<Gtk::Button>("Mais fontes");
    auto *count = label("");
    auto *selection =
        Gtk::make_managed<Gtk::Expander>("Ou marcar nova seleção no Documento");
    auto *selection_body =
        Gtk::make_managed<Gtk::Box>(Gtk::Orientation::VERTICAL, 6);
    auto *source_text = Gtk::make_managed<Gtk::TextView>();
    source_text->set_editable(false);
    source_text->set_wrap_mode(Gtk::WrapMode::WORD_CHAR);
    set_accessible_label(*source_text, "Selecionar trecho da fonte sem editar");
    auto *source_scroll = Gtk::make_managed<Gtk::ScrolledWindow>();
    source_scroll->set_min_content_height(170);
    source_scroll->set_child(*source_text);
    selection_body->append(*source_scroll);
    auto *label_entry = Gtk::make_managed<Gtk::Entry>();
    label_entry->set_max_length(200);
    set_accessible_label(*label_entry, "Nome da nova seleção marcada");
    selection_body->append(*label("Nome do novo trecho"));
    selection_body->append(*label_entry);
    selection->set_child(*selection_body);
    auto *page = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 6);
    page->append(*before);
    page->append(*count);
    page->append(*after);
    auto *error = label("");
    error->add_css_class("error");
    for (auto *w : std::initializer_list<Gtk::Widget *>{
             type, search, find, pick, page, target, selection, error})
      d->get_content_area()->append(*w);
    auto *source_label = label("Fonte textual do Projeto");
    d->get_content_area()->append(*source_label);
    d->get_content_area()->reorder_child_after(*source_label, *find);
    auto *target_label = label("Trecho marcado ou ocorrência nesta fonte");
    d->get_content_area()->append(*target_label);
    d->get_content_area()->reorder_child_after(*target_label, *page);
    struct State {
      std::string kind{"document"}, search;
      std::size_t offset{};
      bool more{};
      std::optional<project::Document> document;
      std::optional<project::StoredComposition> composition;
    };
    auto state = std::make_shared<State>();
    selection->property_expanded().signal_changed().connect(sigc::track_obj(
        [selection, source_text, state] {
          source_text->get_buffer()->set_text(selection->get_expanded() &&
                                                      state->document
                                                  ? state->document->content
                                                  : "");
        },
        *this));
    auto load = [this, state, pick, target, before, after, count, error,
                 expected, selection, source_text] {
      selection->set_expanded(false);
      source_text->get_buffer()->set_text("");
      state->document.reset();
      state->composition.reset();
      target->set_rows({});
      try {
        const auto page = service_.reference_targets(
            expected.work_id, state->kind, state->search, state->offset);
        state->more = page.more;
        Picker::Rows rows;
        for (const auto &x : page.rows)
          rows.push_back({x.id, x.title + " · " + x.detail + " · " + x.id});
        pick->set_rows(rows);
        before->set_sensitive(state->offset > 0);
        after->set_sensitive(state->more);
        count->set_text("Página " + std::to_string(state->offset / 50 + 1));
        error->set_text("");
      } catch (const std::exception &e) {
        pick->set_rows({});
        before->set_sensitive(false);
        after->set_sensitive(false);
        error->set_text(e.what());
      }
    };
    pick->combo.signal_changed().connect(sigc::track_obj(
        [this, state, pick, target, error, selection, source_text] {
          selection->set_expanded(false);
          source_text->get_buffer()->set_text("");
          state->document.reset();
          state->composition.reset();
          target->set_rows({});
          if (pick->selected().empty())
            return;
          try {
            Picker::Rows rows;
            if (state->kind == "document") {
              service_.text_document(
                  pick->selected()); // size/owner guard before full loader
              state->document = project_.writing().document(pick->selected());
              if (!state->document)
                throw std::runtime_error("Documento ausente");
              for (const auto &a : state->document->anchors)
                rows.push_back({a.id, a.label + " · caracteres " +
                                          std::to_string(a.start_offset) + "–" +
                                          std::to_string(a.end_offset) + " · " +
                                          a.id});
            } else {
              state->composition =
                  project_.compositions().load(pick->selected());
              const auto &c = state->composition->value;
              for (const auto &o : c.blocks.placements())
                rows.push_back(
                    {o.id, c.blocks.block(o.block_id).label + " · " +
                               std::string(experimental::name(o.mode)) +
                               (c.blocks.visible(o, c.profile) ? " · visível"
                                                               : " · oculta") +
                               " · " + o.id});
            }
            target->set_rows(rows);
            error->set_text(rows.empty()
                                ? "Nenhum trecho marcado/ocorrência nesta "
                                  "fonte. Nenhum vínculo foi criado."
                                : "");
          } catch (const std::exception &e) {
            error->set_text(e.what());
          }
        },
        *this));
    auto query = [state, type, search, load] {
      state->kind = type->get_active_id();
      state->search = search->get_text();
      state->offset = 0;
      load();
    };
    type->signal_changed().connect(sigc::track_obj(query, *this));
    find->signal_clicked().connect(sigc::track_obj(query, *this));
    search->signal_activate().connect(sigc::track_obj(query, *this));
    before->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->offset >= 50)
            state->offset -= 50;
          load();
        },
        *this));
    after->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->more)
            state->offset += 50;
          load();
        },
        *this));
    load();
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Marcar seleção e abrir", Gtk::ResponseType::APPLY);
    d->add_button("Associar alvo e abrir", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, state, target, error, expected, part, source_text,
         label_entry, selection](int r) {
          if (r != Gtk::ResponseType::ACCEPT && r != Gtk::ResponseType::APPLY)
            return;
          std::string id;
          try {
            if (r == Gtk::ResponseType::APPLY) {
              Gtk::TextIter first, last;
              if (!selection->get_expanded() || !state->document ||
                  !source_text->get_buffer()->get_selection_bounds(first, last))
                throw std::runtime_error("Abra o Documento e selecione um "
                                         "trecho não vazio na consulta");
              id = service_.associate_range(
                  expected, part, *state->document, first.get_offset(),
                  last.get_offset(), label_entry->get_text());
            } else if (state->kind == "document" && state->document)
              id = service_.associate_anchor(expected, part, *state->document,
                                             target->selected());
            else if (state->kind == "composition" && state->composition)
              id = service_.associate_occurrence(
                  expected, part, *state->composition, target->selected());
            else
              throw std::runtime_error(
                  "Escolha a fonte e o trecho ou ocorrência");
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(sigc::track_obj(
              [this, id] {
                try {
                  emit_text(id);
                } catch (const std::exception &e) {
                  status_.emit(e.what());
                }
              },
              *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
} // namespace inde::ui
