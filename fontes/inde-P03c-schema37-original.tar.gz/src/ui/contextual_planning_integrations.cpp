#include "contextual_planning_helpers.hpp"
#include "contextual_planning_page.hpp"
#include "contextual_projection.hpp"
#include "inde/application/project_service.hpp"
#include <algorithm>
#include <map>
#include <memory>
namespace inde::ui {
using namespace contextual_ui;
void ContextualPlanningPage::navigate_context(const std::string &plan,
                                              const std::string &part) {
  auto current = service_.snapshot(plan);
  if (current.work_id != work_id_)
    throw std::runtime_error("Origem de outra Obra");
  auto at =
      std::find_if(current.participations.begin(), current.participations.end(),
                   [&](auto &v) { return v.id == part; });
  if (at == current.participations.end())
    throw std::runtime_error("Participação de origem não existe mais");
  loading_ = true;
  const auto found = plans_.set_active_id(plan);
  loading_ = false;
  if (!found)
    throw std::runtime_error("Composição de origem indisponível");
  selected_id_ = part;
  offset_ =
      static_cast<std::size_t>(at - current.participations.begin()) / 50 * 50;
  snapshot_ = std::move(current);
  render();
}
void ContextualPlanningPage::edit_bridge() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto work = work_id_;
    const auto part = selected().id;
    auto *d = new OverlayDialog("Receber de outra composição", *owner, true);
    d->set_secondary_text(
        "Mesma Obra, contexto próprio. Somente Contexto recebido herda "
        "declarações sob as escolhas da origem. Não copia estados, não escolhe "
        "opções da origem e não deduz causalidade.");
    auto *plans = Gtk::make_managed<Picker>("Composição de origem");
    Picker::Rows rows;
    for (const auto &x : service_.plans(work))
      if (x.id != expected.plan_id)
        rows.push_back({x.id, x.title + " · " + x.id});
    plans->set_rows(rows);
    auto *parts = Gtk::make_managed<Picker>("Participação de outra composição");
    auto source = std::make_shared<application::ContextualSnapshot>();
    auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
    for (const auto *k :
         {"context", "succession", "cause", "motivation", "condition"})
      type->append(k, kind(k));
    type->set_active_id("context");
    set_accessible_label(*type, "Tipo entre composições");
    auto *note = Gtk::make_managed<Gtk::Entry>();
    note->set_max_length(2048);
    set_accessible_label(*note, "Nota da dependência entre composições");
    auto *error = label("");
    error->add_css_class("error");
    for (auto *widget :
         std::initializer_list<Gtk::Widget *>{plans, parts, type, note, error})
      d->get_content_area()->append(*widget);
    plans->combo.signal_changed().connect(sigc::track_obj(
        [this, plans, parts, error, source] {
          *source = {};
          parts->set_rows({});
          if (plans->selected().empty())
            return;
          try {
            *source = service_.snapshot(plans->selected());
            Picker::Rows rows;
            for (const auto &x : source->participations)
              rows.push_back(
                  {x.id, caption(x.title.empty() ? x.description : x.title) +
                             " · " + x.id});
            parts->set_rows(rows);
            error->set_text("");
          } catch (const std::exception &e) {
            error->set_text(e.what());
          }
        },
        *this));
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Declarar vínculo entre composições",
                  Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, parts, type, note, error, source, expected, part](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            service_.add_bridge(expected, part, *source, parts->selected(),
                                type->get_active_id(), note->get_text());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(
              sigc::track_obj([this] { show_dependencies(); }, *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::show_references() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto part = selected().id;
    auto *d = new OverlayDialog("Referências desta participação", *owner, true);
    d->set_secondary_text(
        "Uma origem compartilhada, sem reentrada. Referenciar não declara "
        "presença, relação ativa, cronologia ou coordenada. As vistas "
        "consultam a contribuição neste contexto.");
    Picker::Rows choices;
    std::vector<std::string> rows;
    auto values = std::make_shared<
        std::map<std::string, application::ContextualReference>>();
    for (const auto &x : snapshot_.references)
      if (x.participation_id == part) {
        values->emplace(x.id, x);
        std::string title;
        try {
          const auto v =
              service_.reference_target(work_id_, x.kind, x.target_id);
          title = v.title + " · " + v.detail;
        } catch (const std::exception &e) {
          title = e.what();
        }
        choices.push_back({x.id, x.kind + " · " + title});
        rows.push_back(choices.back().second + "\n" + x.note + "\n" +
                       x.target_id);
      }
    auto *pick = Gtk::make_managed<Picker>("Referência contextual");
    pick->set_rows(choices);
    d->get_content_area()->append(*Gtk::make_managed<TextPager>(rows));
    d->get_content_area()->append(*pick);
    auto *bar = actions(*d->get_content_area());
    auto *error = label("");
    error->add_css_class("error");
    d->get_content_area()->append(*error);
    button(*bar, "Referenciar origem existente",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { edit_reference(); }, *this));
               },
               *this));
    button(*bar, "Consultar vista derivada",
           sigc::track_obj(
               [this, owner, d, pick, error, values] {
                 try {
                   const auto v = values->at(pick->selected());
                   next(d, sigc::track_obj(
                               [this, owner, v] {
                                 show_contextual_projection(
                                     *owner, project_, v.kind, v.target_id);
                               },
                               *this));
                 } catch (const std::exception &e) {
                   error->set_text(pick->selected().empty()
                                       ? "Escolha uma referência"
                                       : e.what());
                 }
               },
               *this));
    button(*bar, "Retirar referência",
           sigc::track_obj(
               [this, d, pick, error, expected] {
                 try {
                   service_.remove_reference(expected, pick->selected());
                 } catch (const std::exception &e) {
                   error->set_text(e.what());
                   return;
                 }
                 refresh(work_id_);
                 next(d, sigc::track_obj([this] { show_references(); }, *this));
               },
               *this));
    button(*bar, "Voltar ao contexto",
           sigc::track_obj(
               [this, d] {
                 next(d, sigc::track_obj([this] { show_context(); }, *this));
               },
               *this));
    d->add_button("Fechar", Gtk::ResponseType::CLOSE);
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
void ContextualPlanningPage::edit_reference() {
  auto *owner = dynamic_cast<Gtk::Window *>(get_root());
  if (!owner)
    return;
  try {
    const auto expected = observation(snapshot_);
    const auto part = selected().id;
    auto *d = new OverlayDialog("Referenciar origem existente", *owner, true);
    d->set_secondary_text(
        "Escolha a identidade, não copie seus dados. Unidades/linhas são da "
        "mesma Obra; demais origens são do Projeto. Não modifica escopo de "
        "obra ou autoridade canônica. Busca literal, caixa ASCII; 50 por "
        "página.");
    auto *type = Gtk::make_managed<Gtk::ComboBoxText>();
    for (const auto &[id, title] :
         std::initializer_list<std::pair<const char *, const char *>>{
             {"entity", "Elemento / Local"},
             {"relation", "Relação canônica"},
             {"unit", "Parte da narrativa"},
             {"line", "Linha narrativa"},
             {"time", "Data / referência temporal"},
             {"point", "Ponto temporal"},
             {"map", "Mapa"}})
      type->append(id, title);
    type->set_active_id("entity");
    set_accessible_label(*type, "Tipo de origem contextual");
    auto *search = Gtk::make_managed<Gtk::Entry>();
    search->set_max_length(200);
    set_accessible_label(*search, "Buscar origem contextual");
    auto *find = Gtk::make_managed<Gtk::Button>("Buscar origens");
    auto *pick = Gtk::make_managed<Picker>("Origem existente");
    auto *note = Gtk::make_managed<Gtk::Entry>();
    note->set_max_length(2048);
    set_accessible_label(*note, "Nota opcional da referência");
    auto *before = Gtk::make_managed<Gtk::Button>("Origens anteriores"),
         *after = Gtk::make_managed<Gtk::Button>("Mais origens");
    auto *count = label("");
    auto *error = label("");
    error->add_css_class("error");
    auto *paging = Gtk::make_managed<Gtk::Box>(Gtk::Orientation::HORIZONTAL, 6);
    paging->append(*before);
    paging->append(*count);
    paging->append(*after);
    for (Gtk::Widget *w : std::initializer_list<Gtk::Widget *>{
             type, search, find, pick, paging, note, error})
      d->get_content_area()->append(*w);
    struct Query {
      std::size_t offset{};
      std::string kind{"entity"}, search;
      application::ContextualReferencePage page;
    };
    auto state = std::make_shared<Query>();
    auto load = [this, state, pick, before, after, count, error, expected] {
      try {
        state->page = service_.reference_targets(expected.work_id, state->kind,
                                                 state->search, state->offset);
        Picker::Rows rows;
        for (const auto &x : state->page.rows)
          rows.push_back({x.id, x.title + " · " + x.detail + " · " + x.id});
        pick->set_rows(rows);
        before->set_sensitive(state->offset > 0);
        after->set_sensitive(state->page.more);
        count->set_text("Página " + std::to_string(state->offset / 50 + 1));
        error->set_text("");
      } catch (const std::exception &e) {
        state->page = {};
        pick->set_rows({});
        before->set_sensitive(false);
        after->set_sensitive(false);
        error->set_text(e.what());
      }
    };
    auto query = [state, type, search, load] {
      state->offset = 0;
      state->kind = type->get_active_id();
      state->search = search->get_text();
      load();
    };
    find->signal_clicked().connect(sigc::track_obj(query, *this));
    search->signal_activate().connect(sigc::track_obj(query, *this));
    type->signal_changed().connect(sigc::track_obj(query, *this));
    before->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->offset >= 50)
            state->offset -= 50;
          load();
        },
        *this));
    after->signal_clicked().connect(sigc::track_obj(
        [state, load] {
          if (state->page.more)
            state->offset += 50;
          load();
        },
        *this));
    load();
    d->add_button("Cancelar", Gtk::ResponseType::CANCEL);
    d->add_button("Referenciar neste contexto", Gtk::ResponseType::ACCEPT);
    d->signal_response().connect(sigc::track_obj(
        [this, d, pick, note, error, expected, part, state](int r) {
          if (r != Gtk::ResponseType::ACCEPT)
            return;
          try {
            auto at =
                std::find_if(state->page.rows.begin(), state->page.rows.end(),
                             [&](auto &x) { return x.id == pick->selected(); });
            if (at == state->page.rows.end())
              throw std::runtime_error("Escolha uma origem desta página");
            service_.add_reference(expected, part, *at, note->get_text());
          } catch (const std::exception &e) {
            error->set_text(e.what());
            d->keep_open_on_response();
            return;
          }
          refresh(work_id_);
          Glib::signal_idle().connect_once(
              sigc::track_obj([this] { show_references(); }, *this));
        },
        *this));
    d->present();
  } catch (const std::exception &e) {
    status_.emit(e.what());
  }
}
} // namespace inde::ui
