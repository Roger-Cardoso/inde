#pragma once
#include <string>
#include <map>
#include <vector>
namespace inde::ui {
using UiPreferences = std::map<std::string, std::string>;
[[nodiscard]] UiPreferences ui_preferences(const std::string &group,
                                           const std::vector<std::string> &keys);
// Reload under an advisory lock, merge only supplied keys, persist once and
// confirm. Other projects/unknown keys are retained; unreadable files stay intact.
[[nodiscard]] bool set_ui_preferences(const std::string &group,
                                      const UiPreferences &values) noexcept;
[[nodiscard]] std::string ui_preference(const std::string &group,
                                       const std::string &key,
                                       const std::string &fallback = {});
void set_ui_preference(const std::string &group, const std::string &key,
                       const std::string &value) noexcept;
[[nodiscard]] std::string project_preference_group(const std::string &id);
}
