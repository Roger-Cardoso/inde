#pragma once
#include "inde/application/document_visibility.hpp"
#include <functional>
#include <gtkmm.h>
#include <map>
#include <optional>
namespace inde::ui {
// A disposable view cache, never a Document or autosave source. Every edit is
// translated through the projection and committed by the original edit session.
class VisibilityLensPage final : public Gtk::Box {
public:
  VisibilityLensPage();
  ~VisibilityLensPage() override;
  void open(application::DocumentEditState, const std::string &profile);
  void flush();
  void reset();
  bool composing() const { return preedit_; }
  std::function<application::DocumentEditState()> read_source;
  std::function<void(const application::DocumentEditState &,
                     application::DocumentEditState)>
      commit;
  std::function<void(bool)> history;
  std::function<void()> save, back;

private:
  Gtk::Box toolbar_{Gtk::Orientation::HORIZONTAL, 6};
  Gtk::Button back_{"← Documento integral"}, undo_{"Desfazer"},
      redo_{"Refazer"}, save_{"Salvar"};
  Gtk::Button discard_draft_{"Descartar edição não aplicada"};
  Gtk::Label title_, explanation_, status_;
  Gtk::ScrolledWindow scroll_;
  Gtk::TextView editor_;
  std::optional<application::DocumentEditState> source_;
  application::VisibilityProjection projection_;
  std::vector<application::ProjectionEdit> pending_;
  std::map<std::pair<project::DocumentTextStyle, std::string>,
           Glib::RefPtr<Gtk::TextTag>>
      tags_;
  sigc::connection commit_idle_;
  Glib::RefPtr<Gio::Cancellable> paste_cancel_;
  std::shared_ptr<int> lifetime_{std::make_shared<int>(0)};
  std::uint64_t generation_{};
  bool restoring_{}, preedit_{}, flushing_{};
  void refresh(application::DocumentEditState);
  void queue_edit(std::size_t, std::size_t, const std::string &);
  void paste();
  void run_history(bool);
  void render_styles();
};
} // namespace inde::ui
