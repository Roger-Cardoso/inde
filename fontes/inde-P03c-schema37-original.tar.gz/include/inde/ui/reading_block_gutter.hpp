#pragma once
#include "inde/application/document_reading_order.hpp"
#include <gtkmm.h>
#include <functional>
namespace inde::ui {
// One virtualized gutter, not one GTK widget per paragraph. Coordinates come
// from TextView layout, so wrapped lines, styles, zoom and scrolling stay aligned.
class ReadingBlockGutter final : public Gtk::DrawingArea {
public:
  explicit ReadingBlockGutter(Gtk::TextView &);
  ~ReadingBlockGutter() override;
  void set_blocks(std::vector<application::ReadingBlock>);
  void cancel_drag();
  std::function<void(const std::string &, const std::string &, bool)> move;
private:
  Gtk::TextView &editor_;
  std::vector<application::ReadingBlock> blocks_;
  std::string focused_, dragging_;
  std::size_t destination_{};
  bool destination_after_{};
  double start_y_{}, pointer_y_{}, distance_{};
  sigc::connection scroll_timer_;
  void draw(const Cairo::RefPtr<Cairo::Context> &, int, int);
  double line_y(std::size_t, int *height = nullptr) const;
  std::size_t hit(double, double) const;
  std::pair<std::size_t, bool> drop_at(double) const;
  void focus_block(std::size_t, bool reveal);
  bool key(guint, guint, Gdk::ModifierType);
};
} // namespace inde::ui
