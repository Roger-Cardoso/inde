#pragma once

#include <cstddef>
#include <memory>
#include <stop_token>
#include <string>
#include <vector>

namespace inde::application {
struct TextMatch {
  std::size_t start{};
  std::size_t end{};
};
struct TextSearchRequest {
  std::string query;
  bool case_sensitive{};
  bool whole_word{};
  std::size_t maximum_matches{100000};
};
struct TextSearchResult {
  std::vector<TextMatch> matches;
  bool truncated{};
};

// Literal, non-overlapping matches. Offsets count Unicode scalars, as GTK does.
// Case folding never permits a match through half of an expanded scalar (ß).
// No regex or implicit Unicode normalization. Whole-word includes marks and _.
[[nodiscard]] TextSearchResult find_text(const std::string &text,
    const TextSearchRequest &request, std::stop_token cancellation = {});

// Worker-local, bounded to one document/text/case mode. Exact text equality is
// the cache key: IDs or revisions alone never authorize reuse of stale offsets.
// The query, word boundary option and limit are evaluated anew on every call.
class TextSearchCache final {
public:
  TextSearchCache();
  ~TextSearchCache();
  TextSearchCache(const TextSearchCache &) = delete;
  TextSearchCache &operator=(const TextSearchCache &) = delete;
  [[nodiscard]] TextSearchResult find(const std::string &document_id,
      const std::string &text, const TextSearchRequest &request,
      std::stop_token cancellation = {});
private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
} // namespace inde::application
