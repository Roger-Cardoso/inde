#pragma once
#include "inde/application/document_edit_session.hpp"
#include "inde/application/text_clipboard.hpp"
#include "inde/application/editor_interaction.hpp"
namespace inde::application {
struct VisibilitySpan {
  std::size_t source_start{}, source_end{}, view_start{}, view_end{};
  bool editable{true}; // Original LF at an omitted seam protects its boundary.
  bool operator==(const VisibilitySpan &) const = default;
};
struct VisibilityProjection {
  std::string document_id, profile_id, source_hash, text;
  std::vector<VisibilitySpan> spans;
  std::vector<std::string> diagnostics;
  bool allow_empty_insert{};
  bool operator==(const VisibilityProjection &) const = default;
};
struct ProjectionEdit {
  std::size_t start{}, end{};
  std::string text;
};
// Only original characters, no inserted ellipses or synthetic separators.
[[nodiscard]] VisibilityProjection
project_visibility(const project::Document &, const std::string &profile_id);
// Snapshot must match the full source, including omitted text, and the profile.
// Several native edits use their sequential VIEW coordinates. No omitted range
// is consumed; insertion at a seam belongs to the next visible run (end:
// previous).
[[nodiscard]] DocumentEditState
edit_visibility(const DocumentEditState &, const VisibilityProjection &,
                const std::vector<ProjectionEdit> &);
[[nodiscard]] std::size_t visibility_view_offset(const VisibilityProjection &,
                                                 std::size_t source);
[[nodiscard]] std::vector<TextRange> visibility_source_ranges(const VisibilityProjection &,
    std::size_t source_start, std::size_t source_end, bool editable_only = false);
[[nodiscard]] TextFragment copy_visibility_fragment(const project::Document &,
    const VisibilityProjection &, std::size_t start, std::size_t end, bool styles);
[[nodiscard]] DocumentEditState paste_visibility_fragment(const DocumentEditState &,
    const VisibilityProjection &, std::size_t start, std::size_t end,
    const TextFragment &, bool styles);
} // namespace inde::application
