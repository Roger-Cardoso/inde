#pragma once
#include "inde/project/writing.hpp"
namespace inde::application {
// Offsets are Unicode scalar positions, identical to GTK text-buffer offsets.
class SemanticAnchorEngine {
public:
  static project::SemanticAnchorEvidence
  evidence(const project::Document &, const project::DocumentAnchor &);
  // Transforms semantic anchors only. The caller transforms legacy layers
  // itself.
  static void edit(project::Document &, std::size_t start, std::size_t end,
                   const std::string &replacement);
  static void
  inspect(project::Document &); // fail-visible, never search/reattach
  // A deliberate permutation moves existing anchors, never reattaches them.
  // Refresh context only if their exact selected text was conserved. Evidence
  // already divergent before movement stays unresolved, never silently blessed.
  static void relocate(const project::Document &before, project::Document &after);
  static void reanchor(project::Document &, const std::string &annotation,
                       std::size_t start, std::size_t end);
};
} // namespace inde::application
