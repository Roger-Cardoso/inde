#pragma once
#include "inde/application/document_edit_session.hpp"
#include "inde/application/text_clipboard.hpp"
namespace inde::application {
[[nodiscard]] DocumentEditState paste_leaf_fragment(const DocumentEditState &,
    std::size_t start,std::size_t end,const TextFragment &,bool styles,const std::string &owner);
[[nodiscard]] DocumentEditState create_alternative(const DocumentEditState &,
    std::size_t start, std::size_t end, const std::string &resma_id={});
[[nodiscard]] DocumentEditState select_document_leaf(const DocumentEditState &,
    const std::string &resma_id, const std::string &leaf_id);
[[nodiscard]] DocumentEditState rename_document_leaf(const DocumentEditState &,
    const std::string &resma_id, const std::string &leaf_id, const std::string &label);
}
