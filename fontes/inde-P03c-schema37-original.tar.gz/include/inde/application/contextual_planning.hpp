#pragma once
#include "inde/application/narrative_builder.hpp"
#include <cstdint>
#include <array>
#include <string>
#include <vector>

namespace inde::application {
class ProjectService;
std::string contextual_kind_label(const std::string &);
struct ContextualPlan {
  std::string id, work_id, title;
};
struct ContextualUse {
  std::string participation_id, plan_id, plan_title;
};
struct ContextualMoment {
  std::string id, project_id, work_id, title, description, revision;
  std::vector<ContextualUse> uses;
  std::string scale{}, contents_plan_id{};
};
struct ContextualParticipation {
  std::string id, moment_id, title, description, note;
  std::int64_t position{};
  std::string scale{}, contents_plan_id{}, category{};
  bool parallel{};
};
struct ContextualSlot {
  std::string id, title, selected_option;
};
struct ContextualOption {
  std::string id, slot_id, title;
};
struct ContextualMembership {
  std::string participation_id, option_id;
};
struct ContextualDeclaration {
  std::string id, participation_id, kind, label, value;
};
struct ContextualDependency {
  std::string id, source, target, kind, note;
};
struct ContextualTextLink {
  std::string id, participation_id, document_id, title, observed_sha, note;
  std::string anchor_id{}, composition_id{}, occurrence_id{};
};
struct ContextualReference {
  std::string id, participation_id, kind, target_id, note;
};
struct ContextualBridge {
  std::string id, source_plan, source, target, kind, note;
};
struct ContextualReferenceTarget {
  std::string project_id, work_id, kind, id, title, detail, revision;
};
struct ContextualReferencePage {
  std::vector<ContextualReferenceTarget> rows;
  bool more{};
};
struct ContextualProjectionRow {
  std::string reference_id, plan_id, plan_title, participation_id, title, note;
  bool included{};
};
struct ContextualProjectionPage {
  std::vector<ContextualProjectionRow> rows;
  bool more{};
};
// Local authorial geometry; no coordinate or shape implies a narrative fact.
struct ContextualVisualItem {
  std::string id, participation_id, kind{"block"}, label, color{"#4589b2"},
      shape{"box"};
  std::int64_t x{40}, y{40}, width{240}, height{120};
  std::array<std::int64_t, 5> curve{500, 500, 500, 500, 500};
  bool expanded{};
  bool operator==(const ContextualVisualItem &) const = default;
};
struct ContextualSnapshot {
  std::string project_id, plan_id, work_id, title, revision;
  std::vector<ContextualParticipation> participations;
  std::vector<ContextualSlot> slots;
  std::vector<ContextualOption> options;
  std::vector<ContextualMembership> memberships;
  std::vector<ContextualDeclaration> declarations;
  std::vector<ContextualDependency> dependencies;
  std::vector<ContextualTextLink> text_links;
  std::vector<ContextualReference> references;
  std::vector<ContextualBridge> bridges;
  std::vector<ContextualVisualItem> visual;
};
std::vector<ContextualVisualItem> contextual_visual_layout(const ContextualSnapshot &);
// Pure proposals. No spatial order becomes narrative order without confirmation.
std::vector<std::string> contextual_selection_order(
    const ContextualSnapshot &, const std::vector<std::string> &parts,
    const std::string &order);
std::vector<ContextualVisualItem> contextual_arrange_selection(
    const ContextualSnapshot &, const std::vector<std::string> &parts,
    const std::string &arrangement);
struct ContextualOrigin {
  ContextualDeclaration declaration;
  std::string origin_title;
  bool local{};
  std::string plan_id{}, plan_title{};
};
struct ContextualView {
  bool included{};
  std::vector<ContextualOrigin> declarations;
  std::vector<std::string> notices;
};
struct ContextualTextObservation {
  std::string project_id, document_id, title, sha;
};
struct ContextualTextReview {
  ContextualTextLink link;
  ContextualTextObservation current;
  bool changed{};
};
struct ContextualMomentChoice {
  std::string id, title, description;
};
struct ContextualMomentPage {
  std::vector<ContextualMomentChoice> rows;
  bool more{};
};
// Shared identity, explicit choices/declarations and selective projections.
// Position/free notes never imply inherited conditions, causality, chronology,
// realization or authorial truth.
class ContextualPlanningService {
public:
  explicit ContextualPlanningService(ProjectService &s) : service_(s) {}
  std::vector<ContextualPlan> plans(const std::string &work) const;
  ContextualSnapshot snapshot(const std::string &plan) const;
  ContextualMoment moment(const std::string &id) const;
  ContextualMomentPage moments(const std::string &work,
                               const std::string &search = "",
                               std::size_t offset = 0) const;
  std::string create_plan(const std::string &work, const std::string &title);
  std::string create_moment(const ContextualSnapshot &,
                            const std::string &title,
                            const std::string &description,
                            const ContextualVisualItem *placement = nullptr);
  std::string reuse_moment(const ContextualSnapshot &,
                           const ContextualMoment &);
  void update_moment(const ContextualMoment &, const std::string &title,
                     const std::string &description);
  void set_note(const ContextualSnapshot &, const std::string &participation,
                const std::string &note);
  void detach(const ContextualSnapshot &, const std::string &participation);
  void move(const ContextualSnapshot &, const std::string &participation,
            int direction);
  void sequence_selection(const ContextualSnapshot &,
                          const std::vector<std::string> &ordered_parts,
                          bool reorder, bool declare_succession);
  // Scale is optional shared vocabulary, role/parallel belong to one use.
  void set_scale(const ContextualMoment &, const std::string &scale);
  void set_role(const ContextualSnapshot &, const std::string &participation,
                const std::string &category, bool parallel);
  std::string develop(const ContextualSnapshot &, const std::string &part);
  std::string compose_plan(const ContextualSnapshot &target,
                           const ContextualSnapshot &source);
  std::string group(const ContextualSnapshot &, const std::vector<std::string> &parts,
                    const std::string &title);
  ContextualSnapshot save_visual(const ContextualSnapshot &,
                                 const std::vector<ContextualVisualItem> &);
  std::string create_slot(const ContextualSnapshot &, const std::string &title);
  std::string create_option(const ContextualSnapshot &, const std::string &slot,
                            const std::string &title);
  void choose_option(const ContextualSnapshot &, const std::string &slot,
                     const std::string &option);
  void assign_option(const ContextualSnapshot &,
                     const std::string &participation,
                     const std::string &option);
  void remove_slot(const ContextualSnapshot &, const std::string &slot);
  void remove_option(const ContextualSnapshot &, const std::string &option);
  std::string declare(const ContextualSnapshot &,
                      const std::string &participation, const std::string &kind,
                      const std::string &label, const std::string &value);
  void update_declaration(const ContextualSnapshot &,
                          const ContextualDeclaration &);
  void remove_declaration(const ContextualSnapshot &, const std::string &id);
  std::string add_dependency(const ContextualSnapshot &,
                             const std::string &source,
                             const std::string &target, const std::string &kind,
                             const std::string &note);
  void remove_dependency(const ContextualSnapshot &, const std::string &id);
  std::string add_bridge(const ContextualSnapshot &target,
                         const std::string &target_part,
                         const ContextualSnapshot &source,
                         const std::string &source_part,
                         const std::string &kind, const std::string &note);
  void remove_bridge(const ContextualSnapshot &, const std::string &id);
  ContextualReferencePage reference_targets(const std::string &work,
                                            const std::string &kind,
                                            const std::string &search = "",
                                            std::size_t offset = 0) const;
  ContextualReferenceTarget reference_target(const std::string &work,
                                             const std::string &kind,
                                             const std::string &id) const;
  std::string add_reference(const ContextualSnapshot &, const std::string &part,
                            const ContextualReferenceTarget &,
                            const std::string &note = "");
  void remove_reference(const ContextualSnapshot &, const std::string &id);
  ContextualProjectionPage projection(const std::string &kind,
                                      const std::string &id,
                                      std::size_t offset = 0) const;
  std::string associate_anchor(const ContextualSnapshot &,
                               const std::string &part,
                               const project::Document &,
                               const std::string &anchor);
  std::string associate_range(const ContextualSnapshot &,
                              const std::string &part,
                              const project::Document &, std::size_t start,
                              std::size_t end, const std::string &label);
  std::string associate_occurrence(const ContextualSnapshot &,
                                   const std::string &part,
                                   const project::StoredComposition &,
                                   const std::string &occurrence);
  BuilderRealization text_destination(const ContextualSnapshot &,
                                      const std::string &link,
                                      bool observe = false) const;
  // Explicit read-only preview override, never persisted or enumerated.
  ContextualView context(const ContextualSnapshot &,
                         const std::string &participation,
                         const std::string &preview_slot = "",
                         const std::string &preview_option = "") const;
  bool included(const ContextualSnapshot &,
                const std::string &participation) const;
  std::vector<std::string>
  included_participations(const ContextualSnapshot &) const;
  ContextualTextObservation text_document(const std::string &document) const;
  void validate_text_destination(const std::string &document) const;
  std::string text_target(const ContextualSnapshot &,
                          const std::string &link) const;
  std::string create_text(const ContextualSnapshot &,
                          const std::string &participation,
                          const std::string &title);
  std::string associate_text(const ContextualSnapshot &,
                             const std::string &participation,
                             const ContextualTextObservation &);
  ContextualTextReview observe_text(const ContextualSnapshot &,
                                    const std::string &link) const;
  void review_text(const ContextualSnapshot &, const ContextualTextReview &,
                   const std::string &human_note);
  void remove_text_link(const ContextualSnapshot &, const std::string &id);

private:
  ProjectService &service_;
};
} // namespace inde::application
