#pragma once
#include "inde/application/document_edit_session.hpp"
namespace inde::application {
// Derived structural blocks, not narrative units. A multiline resma joins
// paragraphs so that covered leaves never become fragments of another block.
struct ReadingBlock {
  std::string id;
  std::size_t first{}, last{}, start{}, end{};
};
[[nodiscard]] std::vector<ReadingBlock> reading_blocks(const project::Document &);
// Move the same identities before another block; empty destination means end.
// No deletion/paste, new identities or changes to other narrative orders.
[[nodiscard]] DocumentEditState move_reading_block(const DocumentEditState &,
    const std::string &block_id, const std::string &before_block_id = {});
// A visible neighbour is an identity, not an index in a filtered rendering.
[[nodiscard]] DocumentEditState move_reading_relative(const DocumentEditState &,
    const std::string &block_id, const std::string &reference_id, bool after);
} // namespace inde::application
