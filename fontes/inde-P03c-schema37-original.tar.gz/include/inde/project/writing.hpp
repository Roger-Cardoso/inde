#pragma once
#include "inde/project/text_semantics.hpp"
#include "inde/project/document_paragraphs.hpp"
#include "inde/project/document_visibility.hpp"

#include <stop_token>

#include <cstddef>
#include <optional>
#include <string>
#include <vector>
#include <memory>

namespace inde::project {

enum class DocumentTextStyle {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Heading,
  Subheading,
  Quote,
  Heading2, Heading3, Heading4, Heading5, Heading6,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  FontFamily, FontSize, Foreground,
};

[[nodiscard]] std::string to_string(DocumentTextStyle value);
[[nodiscard]] DocumentTextStyle
document_text_style_from_string(const std::string &value);

// Formatação é uma camada sobre offsets Unicode do corpo. Ela enriquece a
// apresentação e nunca substitui os caracteres digitados.
struct DocumentFormatSpan {
  DocumentTextStyle style{DocumentTextStyle::Bold};
  std::size_t start_offset{};
  std::size_t end_offset{};
  std::string value{};
  bool operator==(const DocumentFormatSpan &) const = default;
};

// Only covered leaves own text. The active leaf is the original continuous
// Document.content range, never a second editable copy. Immutable covered
// payloads make ordinary editor/history copies inexpensive.
struct DocumentLeafContent {
  std::string text;
  std::vector<DocumentFormatSpan> formatting;
  bool operator==(const DocumentLeafContent &) const = default;
};
struct DocumentLeaf {
  std::string id, label;
  std::shared_ptr<const DocumentLeafContent> covered;
  bool operator==(const DocumentLeaf &b) const {
    return id==b.id && label==b.label && (covered==b.covered ||
      (covered && b.covered && *covered==*b.covered));
  }
};
struct DocumentResma {
  std::string id, label, top_id;
  std::size_t start{}, end{};
  std::vector<DocumentLeaf> leaves;
  bool operator==(const DocumentResma &) const = default;
};

[[nodiscard]] bool paragraph_style(DocumentTextStyle style);
void validate_format_span(const DocumentFormatSpan &span);

// Literal author templates. Never evaluated as code or fictional facts.
struct DocumentInlineCommand {
  std::string prefix, keyword, label, content;
  bool operator==(const DocumentInlineCommand &) const = default;
};
void validate_inline_commands(const std::vector<DocumentInlineCommand> &);

// Uma âncora nomeia uma posição ou um intervalo do Documento. A identidade
// permite que outras camadas a referenciem sem copiar o trecho textual.
struct DocumentAnchor {
  std::string id;
  std::string label;
  std::size_t start_offset{};
  std::size_t end_offset{};
};

// A entidade continua pertencendo ao Planejamento. O Documento apenas mantém
// uma referência explícita, opcionalmente situada numa âncora.
struct DocumentEntityReference {
  std::string id;
  std::string entity_id;
  std::optional<std::string> anchor_id;
  std::string notes;
};

// Referência sem incorporação: identidade do alvo, nunca uma cópia do texto.
struct DocumentTextReference {
  std::string id;
  std::string source_document_id;
  std::string target_document_id;
  std::optional<std::string> target_anchor_id;
  std::string notes;
  std::string created_at;
};

struct DocumentTextReferenceSummary {
  DocumentTextReference reference;
  std::string source_title;
  std::string target_title;
  std::optional<std::string> target_anchor_label;
};

enum class DocumentSearchMatch { None, Name, Content, NameAndContent };

// A finalidade organiza o trabalho do autor sem confundir Documento com
// unidade editorial. "Revisao" aqui significa revisao documental, não versão
// publicada da Obra nem alternativa narrativa.
enum class DocumentPurpose {
  MainText,
  Annotation,
  Revision,
  Outline,
  Research,
  Reference,
  Other,
};

[[nodiscard]] std::string to_string(DocumentPurpose value);
[[nodiscard]] std::string display_name(DocumentPurpose value);
[[nodiscard]] DocumentPurpose
document_purpose_from_string(const std::string &value);

// Grupo virtual da Biblioteca. Não representa uma pasta do sistema de
// arquivos e não altera a identidade nem a colocação editorial do Documento.
struct DocumentGroup {
  std::string id;
  std::string name;
  std::string description;
  std::string created_at;
  std::string updated_at;
};

struct RepeatedWord {
  std::string word;
  std::size_t count{};
};

struct LongParagraph {
  std::size_t paragraph_number{};
  std::size_t word_count{};
  std::size_t start_offset{};
};

struct DocumentTextStatistics {
  std::size_t words{};
  std::size_t characters_with_spaces{};
  std::size_t characters_without_spaces{};
  std::size_t paragraphs{};
  std::size_t sentences{};
  std::size_t reading_minutes{};
  std::vector<RepeatedWord> repeated_words;
  std::vector<LongParagraph> long_paragraphs;
};

[[nodiscard]] DocumentTextStatistics
analyze_document_text(const std::string &text,
                      std::size_t words_per_minute = 200,
                      std::size_t long_paragraph_words = 120,
                      std::stop_token cancellation = {},
                      bool include_details = true);

// Documento textual possui identidade própria. A colocação editorial é um
// vínculo opcional e nunca contém ou substitui o texto.
struct Document {
  std::string id;
  std::optional<std::string> editorial_node_id;
  std::string title;
  std::string content;
  std::string created_at;
  std::string updated_at;
  std::optional<std::size_t> word_goal;
  std::vector<DocumentFormatSpan> formatting;
  std::vector<DocumentAnchor> anchors;
  std::vector<DocumentEntityReference> entity_references;
  std::optional<std::string> group_id;
  DocumentPurpose purpose{DocumentPurpose::MainText};
  std::optional<std::string> revision_of_id;
  std::string revision_label;
  std::string perspective;
  DocumentSemantics semantics;
  std::vector<DocumentInlineCommand> inline_commands;
  DocumentParagraphs paragraphs{};
  std::vector<DocumentResma> resmas{};
  std::vector<VisibilityProfile> visibility_profiles{};
};

// Projeção leve para Biblioteca. O corpo completo só é materializado quando
// um Documento é aberto no editor.
struct DocumentSummary {
  std::string id;
  std::optional<std::string> editorial_node_id;
  std::string title;
  std::size_t character_count{};
  std::string created_at;
  std::string updated_at;
  std::size_t entity_reference_count{};
  DocumentSearchMatch search_match{DocumentSearchMatch::None};
  std::optional<std::string> group_id;
  DocumentPurpose purpose{DocumentPurpose::MainText};
  std::optional<std::string> revision_of_id;
  std::string revision_label;
  std::string perspective;
};

void validate(const Document &value);
void validate(const DocumentGroup &value);
[[nodiscard]] std::size_t utf8_character_count(const std::string &text);

} // namespace inde::project
