#pragma once
#include "inde/project/writing.hpp"
#include <string_view>
namespace inde::project {
inline constexpr std::size_t document_resma_limit=256, resma_leaf_limit=32;
inline constexpr std::size_t covered_leaf_text_limit=16*1024*1024;
// Explicit source-side insertion outside an empty/hidden slot at a boundary.
inline constexpr std::string_view outside_resma_owner="__outside_resma__";
void validate_alternatives(const Document &);
[[nodiscard]] std::vector<DocumentResma> edit_alternatives(
    const std::vector<DocumentResma> &, std::size_t old_length,
    std::size_t start, std::size_t end, std::size_t added,
    std::string_view preferred={});
[[nodiscard]] std::string resma_at(const std::vector<DocumentResma> &,
    std::size_t point, std::string_view preferred={});
[[nodiscard]] std::size_t alternatives_retained_bytes(const Document &);
void renew_alternative_identities(Document &);
}
