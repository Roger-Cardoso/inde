#pragma once
#include <cstddef>
#include <string>
#include <vector>
#include <memory>
namespace inde::project {
struct DocumentParagraph {
  std::string id;
  std::size_t start{}, end{}; // Derived Unicode coordinates, excluding LF.
  std::shared_ptr<const std::string> content{}; // Canonical immutable block payload.
  bool operator==(const DocumentParagraph &b) const {
    return id == b.id && start == b.start && end == b.end &&
      (content == b.content || (content && b.content && *content == *b.content));
  }
};
struct DocumentParagraphs {
  bool enabled{};
  std::vector<DocumentParagraph> rows;
  std::vector<std::string> retired;
  bool operator==(const DocumentParagraphs &) const = default;
};
inline constexpr std::size_t paragraph_identity_limit = 100000;
[[nodiscard]] bool canonical_paragraphs(const DocumentParagraphs &);
// Upgrade old offset-only partitions without changing identities or prose.
void consolidate_paragraphs(DocumentParagraphs &, const std::string &);
// The row sequence is logical order. Reordering shares the same payloads.
[[nodiscard]] std::string render_paragraphs(const DocumentParagraphs &);
void position_paragraphs(DocumentParagraphs &);
[[nodiscard]] DocumentParagraphs identify_paragraphs(const std::string &);
void validate_paragraphs(const DocumentParagraphs &, const std::string &);
// Exact edit coordinates; no full-body diff and no semantic inference.
[[nodiscard]] DocumentParagraphs edit_paragraphs(const DocumentParagraphs &,
    std::size_t start, std::size_t end, const std::string &replacement);
} // namespace inde::project
