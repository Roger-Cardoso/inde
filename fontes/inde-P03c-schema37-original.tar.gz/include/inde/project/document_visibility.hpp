#pragma once
#include <cstddef>
#include <string>
#include <vector>
namespace inde::project {
struct Document;
enum class VisibilityRuleKind {
  Paragraph,
  Resma,
  Anchor,
  SemanticType,
  Annotation,
  Style
};
struct VisibilityRule {
  VisibilityRuleKind kind{VisibilityRuleKind::Paragraph};
  std::string key;
  bool operator==(const VisibilityRule &) const = default;
};
struct VisibilityProfile {
  std::string id, name;
  bool include_all{true};
  std::vector<VisibilityRule> include, exclude;
  bool operator==(const VisibilityProfile &) const = default;
};
inline constexpr std::size_t visibility_profile_limit = 32,
                             visibility_rule_limit = 256;
std::string to_string(VisibilityRuleKind);
VisibilityRuleKind visibility_rule_kind(const std::string &);
std::string display_name(VisibilityRuleKind);
void validate_visibility_profiles(const std::vector<VisibilityProfile> &);
std::size_t visibility_retained_bytes(const Document &);
// Independent document copies get local profile IDs; structural references are
// rebased by exact identity maps. Missing bindings stay missing, never guessed.
void copy_visibility_profiles(const Document &source, Document &copy);
} // namespace inde::project
