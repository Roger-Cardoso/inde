#pragma once
#include "inde/project/writing.hpp"
namespace inde::persistence {
[[nodiscard]] std::string encode_alternatives(const std::vector<project::DocumentResma> &);
[[nodiscard]] std::vector<project::DocumentResma> decode_alternatives(const std::string &);
}
