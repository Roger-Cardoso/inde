#pragma once
#include "inde/project/document_paragraphs.hpp"
namespace inde::persistence {
std::string encode_paragraphs(const project::DocumentParagraphs &, bool legacy = false);
project::DocumentParagraphs decode_paragraphs(const std::string &);
}
