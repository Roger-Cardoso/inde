#pragma once
#include "inde/project/document_visibility.hpp"
namespace inde::persistence {
std::string encode_visibility(const std::vector<project::VisibilityProfile> &);
std::vector<project::VisibilityProfile> decode_visibility(const std::string &);
} // namespace inde::persistence
