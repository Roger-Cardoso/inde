# Planejamento por trechos — corte modular

Autorização humana após análise do trabalho narrativo, não nova pesquisa de
mercado. Aceite da entrega anterior é restrito à qualidade técnica; usabilidade
foi explicitamente considerada insuficiente. Esta entrega tem avaliação própria.

## Modelo e uso

Um acontecimento pode ser um trecho simples ou ter um interior explícito. O
interior reusa uma composição contextual da mesma Obra. Criar/desenvolver não
exige taxonomia; escala é um nome opcional na identidade. Decisão, fluxo, bloco
e sequência podem ser combinados sem uma hierarquia predeterminada.

Categoria opcional pertence à participação: principal/secundária/fundo ou outro
nome. Paralelo é independente e pode coexistir com a categoria. Não se deduz
simultaneidade, importância universal, causalidade ou presença canônica.

Desenvolver cria um interior vazio atomicamente quando ainda não existe;
abrir interior existente não cria histórico ou conteúdo. Usar composição como
trecho compartilha a própria origem, inclusive opções e vínculos. Reutilizar
acontecimento inclui trechos simples ou compostos, sem copiar o interior.

Agrupar move as participações escolhidas, conservando IDs, notas, papéis,
declarações, referências, texto e ordem interna. O grupo ocupa a primeira posição
escolhida; as demais peças mantêm ordem relativa. Dependências internas continuam
internas; as que cruzam a fronteira usam a representação de ponte, com mesma
identidade/tipo/nota/origem, sem inferência nova. Pontes existentes têm owners
rebasados. Membros de opções são recusados nesse comando sem alterações, porque
extrair só uma parte de uma opção mudaria seu alcance. A composição inteira com
opções pode ser usada como peça. Não há desagrupar genérico, templates ou repetição
automática de acontecimentos; reversão segue o histórico existente, sem refazer
automático de compensações.

Contenção não transmite declarações automaticamente. Contexto continua sendo
relação explícita, sob escolhas da origem. Compartilhar um interior não significa
que todas as suas consequências se tornam fatos no conjunto maior. Documento,
Montagem de texto e módulo de planejamento não são o mesmo conteúdo.

## Interface por escala de trabalho

Captura direta por título/Enter; com campo vazio, Novo trecho permite descrição
incompleta. Lista contém apenas o nível corrente; Abrir interior/Desenvolver e
Voltar ao conjunto conservam participação/página/rolagem. A trilha é persistida
como frames planos, não recursivamente embutida. Não há cópia/resumo obrigatório.
Ideia pendente impede troca silenciosa de conjunto/interior e seu rascunho faz
parte do contexto de interface, em preferências, não do Documento.

Menu Montagem concentra criação/reuso/composição/grupo/opções/atualização. O
menu Trabalhar trecho só aparece com seleção e contém edição, nota, escala,
papel, ordem, contexto e retirada. Menu contextual da linha oferece caminhos
equivalentes, incluindo suporte Menu/Shift+F10 existente. Não há tarefa essencial
exclusivamente por clique secundário. Paginação aparece só acima de 50 registros.

## Persistência e segurança

Schema32 aditivo: contextual_modules(moment_id, contents_plan_id nullable,
scale) e contextual_roles(participation_id, category, parallel), FKs compostas
de Projeto/Obra/owner, um interior por identidade e uma identidade por interior.
Migração não interpreta dados antigos. CAS inclui metadados e usos observados;
comandos usam transação/histórico e Save As inclui os novos owners.

Contenção é um DAG limitado a 16 níveis/200 composições por Obra/16.000 usos
compostos. Validação linear no grafo armazenado, não nos caminhos virtuais.
Snapshots locais permanecem 2.000 participações/8 MiB e coleções 4.000. Não há
expansão recursiva ao renderizar uma lista. Ciclos de dependência declarada não
são confundidos com ciclos de contenção. Prévia e confirmação de reversão usam
a mesma validação, inclusive contra uma prévia que ficou obsoleta.

## Evidência e avaliação

Testes: contextual_modules_tests e ui_contextual_modules_smoke; regressões
contextuais e CTest completo. Benchmark: modular_planning_benchmark, DAG de 10
composições/1.000 usos/900 arestas compartilhadas, sem baseline, expansão de
caminhos ou certificado de produtividade. Fixture: prepare_modular_review.
Resultados finais, hashes e limites ficam no relatório/manifesto externo da
tarefa. Não afirmar aceite humano deste corte, uso profissional certificado,
publicação, D06 ou migração de obra autoral.
