# Composição contextual — C01 (2026-10-14)

Primeiro incremento de INDE-NEXT-COMPOSICAO-CONTEXTUAL-01, autorizado após
aceite humano do lote 03. Não é D06 nem conclusão da composição contextual
avançada. Os 19 contratos canônicos continuam vigentes; C01 implementa a base
de identidade/participação, não opções, herança ou interpretação textual.

## Modelo e comandos

- `contextual_plans`: composições contextuais da Obra, separadas dos planos
  narrativos legados e das composições documentais/editoriais existentes.
- `contextual_moments`: identidade e conteúdo compartilhados, título ou
  descrição suficientes; sem data, elenco, condições ou efeitos obrigatórios.
- `contextual_participations`: referência à identidade; posição narrativa local
  e nota livre local. A mesma identidade pode participar repetidamente. A nota
  não é contexto estruturado, fato, herança ou resumo obrigatório.

Não converter dados antigos por título, posição ou vínculo. Não vincular
automaticamente acontecimentos a entidades do domínio D05. Não inferir
participação, sucessão, causa, motivação, condição, fidelidade ou realização.
Datas, ordem narrativa, fila de escrita e produção editorial não são fundidas.

UI: Planejar → Plano narrativo → Composição contextual. Composição e participação
são selecionadas sem uma nova área permanente na escrita. Consulta/escolha de
acontecimento é explícita, com até 50 opções por página. Edição compartilhada
mostra número de participações e composições e permite consultar todos os nomes
e IDs afetados. Retirada é confirmada com alcance claro e preserva a identidade
e todos os outros usos. C01 não oferece exclusão de conteúdo/composição.

## Consistência e recuperação

`ContextualPlanningService` abre a base do Projeto ativo; identidade e schema
exatos são verificados em transação. Comando local compara fingerprint do
snapshot completo da composição e devolve dados canônicos para validação;
linhas forjadas pelo chamador não substituem a leitura. Edição compartilhada
compara conteúdo/token e usos consultados, inclusive usos adicionados em outra
composição. O seletor confirma a mesma identidade e conteúdo exibidos antes da
reutilização. Novo conteúdo e participação são criados atomicamente.

Histórico do Projeto captura as novas tabelas; prévia e compensação existentes
fazem reversão com conflitos/FKs. Não há implementação paralela de undo. Save As
rebate owner de todas as três tabelas e conserva identidades internas. Falhas
de validação e CAS mantêm os formulários com erro inline e rascunho; refresh
pós-commit é separado para não repetir criação gravada.

## Schema e limites

Schema 29 aditivo e transacional; três tabelas inicialmente vazias, FKs de
Projeto/Obra e FKs compostas de participação impedindo cruzar Obras ou Projetos.
Nenhuma migração semântica. O schema 28 aceita somente sua versão suportada:
restaurar cópia completa anterior para regressar ao binário antigo, não apagar
tabelas ou fingir downgrade de projeto autoral.

Limites explícitos: 200 composições por Obra; 2.000 participações por composição
e 2.000 usos por acontecimento; consulta/snapshot de até 8 MiB. Conteúdo e nota
até 4.096 caracteres UTF-8, título até 200. Guarda conservadora de orçamento
verifica apenas composições afetadas por edição compartilhada, antes do commit;
não deixa conteúdo parcialmente gravado nem vista ilegível. Catálogo de
acontecimentos paginado em 50 + sentinela, com OFFSET limitado a 1.000.000.
Busca é por trecho literal; `lower()` SQLite ignora caixa apenas em ASCII, não
promete case folding completo em português. Unicode no conteúdo é preservado.

Sem busca a cada tecla, recomposição de prosa, enumeração de combinações ou
cache persistente confiado entre revisões. Snapshot inclui apenas uma composição;
alcance é consulta indexada de uma identidade. Paginação por OFFSET não congela
um catálogo mudado entre páginas; buscar novamente atualiza a observação.

## Próximos incrementos, sem execução automática

C02: encaixes/opções/participação conjunta e continuações compartilhadas.
C03: contribuições esparsas/dependências declaradas/herança com origem.
C04: associação textual muitos-para-muitos, transição/retorno, mudança técnica
sem veredito semântico e vistas derivadas, com zero reentrada. O fluxo textual
legado permanece; não recebeu semântica contextual por este incremento.

Planos/participações/seleção/página/rolagem de C01 entram no contexto salvo
existente, sem migrar preferências antigas obrigatoriamente. Ausência da nova
chave não invalida as vistas legadas. Revisão humana de ergonomia de C01 continua
um gate próprio; testes verdes não fornecem esse aceite.
