# P02 — folhas e resmas no Documento contínuo

Autorizado em2026-10-16 por “implemente p02”. Base P01 schema34 conservada;
schema35 aditivo. Não representa aceite humano, migração de obra original,
P03/P04 concluídos, D06 ou publicação.

## Trabalho disponível

Criar alternativa do trecho conserva a seleção atual e abre uma folha vazia no
mesmo editor. Sem seleção, usa o parágrafo no cursor. Dentro de uma resma,
cria outra folha da mesma resma. Seleção parcial/cruzamento e nesting não são
reinterpretados: uma nova resma exige faixa não sobreposta. Não é preciso
preencher formulário nem nomear parágrafos antes de experimentar.

Uma barra anterior/nome/próxima/gestão aparece somente no contexto de uma resma;
fora dela some. O menu e o contexto oferecem consulta/criação. A lista geral é
paginada25; o gestor mostra até32folhas e permite nomear a folha atual, escolher
uma folha e criar outra. IDs técnicos ficam em detalhes. Não são mini-editores.

Documento.content contém exclusivamente o texto corrente. Seleção, clipboard,
digitação e formatação continuam no GtkTextView nativo, atravessando os limites
sem incluir texto encoberto. Resma possui ID e intervalo; folha possui ID/rótulo;
topo é escolhido por ID. Folha ativa não pode ter payload duplicado. Só as folhas
encobertas possuem payload local texto+estilos. Alternativa não é histórico;
undo/redo restaura texto, limites, identidades, rótulos e topo juntos.

## Exclusão e limites de autoridade

Delete edita somente o texto visível. Não exclui resma ou folhas encobertas.
Apagar integralmente pode deixar uma resma vazia; a consulta geral conserva seu
acesso. Trocar para uma folha conservada repõe seu texto no mesmo ponto. Se a
exclusão atravessar resmas, o texto apagado do topo fica sujeito ao undo normal,
mas nenhuma alternativa encoberta é tocada. Não é ocultação de uso nem arquivo.

Intervalos vazios podem coincidir. A resma escolhida no contexto é dona da
inserção/clipboard/modelo inline; sem escolha, a ordem estável resolve o ponto.
As demais posições vazias são deslocadas, não recebem cópias da nova prosa.
Ao substituir texto existente sem dono explícito (como na busca), conserva-se
a folha de extensão positiva que contém o início da faixa. Uma resma vazia
coincidente não se apropria desse texto; sua posição permanece no limite,
sem virar uma resma aninhada dentro da folha parcialmente substituída.
Não há destruição de resmas/folhas nem limpeza automática neste corte.

Texto e formatação local são conservados por folha. Criar/trocar uma alternativa
que intersecta âncoras, inclusive de marcação semântica, é recusado com explicação.
Não move vínculos por posição nem faz uma folha herdar a identidade narrativa
de outra. Marcações ainda podem ser usadas no Documento; enquanto atingirem a
resma, a troca fica protegida. Vínculos entre folhas encobertas são protocolo
pendente P04. Contexto global do Documento não é reinterpretado como dado da folha.

Parágrafos continuam o mecanismo estrutural P01: trocar topo é substituição de
texto, não restauração de IDs de parágrafos retirados. IDs da resma/folha são
estáveis; parágrafo não é automaticamente alvo compartilhado nem folha narrativa.
Undo, diferentemente de trocar folha, restaura exatamente o estado de parágrafos.

## Conservação, custo e compatibilidade

Agregado opcional document_alternatives, owner/Documento com FK deferred,
CAS e mesma transação do corpo/parágrafos/estilos. SaveAs rebasa owner sem mudar
IDs. Revisão independente e cópia de resgate conservam as alternativas com IDs
locais novos. Snapshot3/journal6 incluem resmas; formatos anteriores continuam
lidos e são mantidos quando não há resmas. Payload incompleto não é degradado
para documento sem alternativas. Histórico/reversão inclui o agregado novo.

Payloads encobertos são compartilhados imutavelmente durante digitação/histórico;
não se copiam megabytes por tecla. Orçamento do histórico conta alocações
encobertas únicas, inclusive entre transações. Isso não certifica latência/RSS
do aplicativo inteiro. Igualdade tem fastpath de ponteiro, mas valores decodificados
são comparados por conteúdo; CAS não depende de endereço de memória.

Limites:256resmas/Documento,32folhas/resma,16MiB de texto encoberto,32MiB payload.
Continuam limites de journal/histórico existentes; recusa sem truncar/podar.
Clipboard e TXT/HTML incluem só o topo e não transportam resmas/identidades.
Exportação informa essa perda. Recorte independente parcial também não incorpora
as resmas e informa a limitação; a origem integral congelada conserva tudo.
Montagens antigas continuam independentes, não são convertidas em double-write.

P03 ocultação/perfis/lentes editáveis por marcações, inclusive semânticas e
intervalos intraparágrafo, e P04 novos usos compartilhados continuam pendentes.
Fonte/binário/fixture/iniciador e gates próprios na tarefa: P02-verificacao.json,
RELATORIO-RESMAS-P02.md e CONTINUIDADE-RESMAS-P02.md. Sessão longa, IME físico,
HiDPI/a11y integral e aceite humano não decorrem de teste automatizado.
