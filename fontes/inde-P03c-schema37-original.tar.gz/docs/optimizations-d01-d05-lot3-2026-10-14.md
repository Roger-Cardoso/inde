# INDE — lote 03 de D01–D05

O usuário confirmou o aceite humano dos lotes 01/02 e autorizou continuar,
parando antes de D06 para a composição contextual já elaborada. O lote 03
não herda esse aceite. Não promove/publica o candidato nem altera schema 28.

## Alterações

- D01: o gestor de espaços mantém o mesmo diálogo/campo de nome/lista durante
  salvar, atualizar e remover. Acrescenta ou retira somente o item afetado,
  conserva rascunho de novo nome em atualização/remoção e exibe feedback local.
  Atualizar conserva ID/nome e altera o estado usado por Retomar. Remover
  desabilita o botão antes de retirar o card em idle rastreado, impedindo dupla
  remoção/deleção do controle emissor. O estado vazio volta sem reconstrução.
  Persistência confirmada, guard de Projeto e snapshot capturado ao abrir
  permanecem. Não há CAS novo da lista composta entre processos.
- D03: escolha de tipo sem opção explícita e campos semânticos inválidos
  permanecem no formulário com mensagem e rascunho. A correção não renova a
  observação de documento/epoch/revisão. Contexto obsoleto não aplica campos;
  o autor pode copiar antes de cancelar/reabrir. Depois de uma aplicação que
  mudou a revisão, falha de apresentação não oferece repetição duplicada.
  A aplicação continua no histórico reversível; campos obrigatórios vazios
  continuam incompletude legítima, não escolha automática.
- D04: o guard devolve a leitura canônica que acabou de validar dentro da
  transação. Criar/editar unidade, editar linha, mover unidade, derivar, mover
  na linha e prévia de movimento reutilizam essa observação. Nunca usam as
  linhas fornecidas pelo chamador como autoridade de gravação. Não há cache
  entre transações nem redução da abrangência das evidências/schema/limites.

## Verificação e limitações

`inde_optimization_lot3_tests` instala observação SQLite somente no teste,
conta uma leitura do snapshot de origem nos sete comandos, confere retorno
canônico com linhas adulteradas pelo chamador, recusa projeto/revisão obsoletos,
rollback de validação posterior e integridade. Validação da cópia derivada
continua uma leitura separada necessária, não removida pelo novo guard.

O driver GTK cumulativo verifica mesmo campo/modal do gestor, rascunho retido,
identidades, remoção dupla, estado vazio, escolha explícita, número inválido,
correção, undo/redo e contexto semântico obsoleto. A reapresentação de formulário
por `keep_open_on_response` usa idle; o teste espera prontidão com limite, não
trata um tick do timer como conclusão. `--sanitize-optimization-lot3` instrumenta
gestor, campos semânticos e driver; demais objetos de UI/dependências Release.

O teste antigo de preferências falhou numa execução com retry limitado a
200 ms e passou isoladamente. O retry do teste passou a deadline de cinco
segundos; caso adicional segura o lock por 350 ms e verifica falha não bloqueante
seguida de retry/preservação. Nenhum mecanismo de preferências do produto mudou.

Resultados efetivos de Release/CTest/GTK/sanitizadores e ensaio do mecanismo
ficam no relatório de entrega. Não equivalem a aceite humano do lote 03.

Resultado final: Release completa; 36/36 CTest (114,63 s); ASan/UBSan focais de
núcleo e de duas unidades GTK/driver; dois passes Release GTK claro/escuro,
todos passaram. Trace prova uma leitura de origem nos sete comandos. Ensaio
do padrão guard+releitura vs reutilizar guard, 30 pares sem build/testes/GTK
concorrentes: 100 unidades p50 3,975 → 2,037 ms; 1.000 unidades 28,237 → 13,750 ms.
Reprodução de mecanismo, não binário antigo/latência global; não mede UI ou memória.

## Fronteira funcional

O lote prepara retomada, rascunhos e confirmação sobre observação válida para
a evolução contextual, sem implementar situações compartilhadas, condições,
contribuições, escolhas ou projeções herdadas novas. Essa trilha permanece
`INDE-NEXT-COMPOSICAO-CONTEXTUAL-01`; seus critérios/gates precisam ser detalhados
antes de codificar, como exige o contrato. D06 e domínios seguintes não iniciados.
