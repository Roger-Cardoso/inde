# P03c — uma escrita, instrumentos especializados e projeção estrutural

Implementação autorizada em 2026-10-16 para corrigir a separação e limitação do
P03b. Não confundir entrega técnica com aceite humano; confirmado só até P02.

## Contrato de trabalho

Há um único GtkTextView de escrita, uma sessão de histórico, uma seleção e um
Documento aberto. Especialização é conjunto de instrumentos/realces, não cópia
ou modo de documento. Visibilidade é outro eixo: mudar especialização conserva
o perfil aplicado e não altera conteúdo nem propriedades autorais.

Retomar um contexto de navegação conserva especialização e perfil válidos;
abrir outro Documento começa em Texto. Escolha ativa é contexto de interface,
não propriedade autoral nem decisão editorial. Estatísticas declaram escopo
do Documento integral, inclusive quando a escrita exibe apenas um recorte.

| Especialização | Instrumentos de entrada |
| --- | --- |
| Texto e formatação (início) | Escrita, estilos, cor, alinhamento, busca e clipboard |
| Semântica | Realce por tipo, tooltip com evidências, marcar seleção, comentários e inspetor lateral |
| Linguística | Consulta lexical/construções existentes, repetição e parágrafos longos |
| Estrutura | Identidades de parágrafos, folhas/resmas, alças e ordem, visibilidade |
| Vínculos narrativos | Trechos, entidades e referências/planejamento já existentes |

Menu contextual acompanha a especialização; edição/undo/copy/cut/paste e atalhos
continuam transversais. Não foi inventada nova análise linguística, inferência
semântica, reancoragem automática, taxonomia narrativa ou especialização vazia
de comandos. Consultas/formulários auxiliares não criam outro editor do mesmo
Documento. Composição continua sendo outra apresentação de trabalho narrativo,
não substitui a identidade do texto nem recebe expansão de escopo neste corte.

## Origem e apresentação

Parágrafos identificados passam a conservar payload UTF-8 imutável por ID.
A sequência de IDs é dado persistido, não efeito dos offsets do buffer. O codec2
guarda coleção `{id,text}` e `order:[id...]`; coordenadas são reconstruídas.
Mover compartilha os mesmos conteúdos, altera a sequência e remapeia consumidores
legados de intervalos. O corpo linear permanece como cache validado para export,
serviços e armazenamento compatíveis. Divergência entre corpo/cache e blocos é
erro, não autorização para escolher um deles e perder o outro silenciosamente.

Migração37 consolida payloads legados1 dentro da transação do migrador. Nenhuma
obra real é aberta automaticamente. Repositório, CAS, SaveAs, snapshots, journal,
remoção/restauração e cópias conservam a estrutura. Snapshot5/journal8 aceitam
versões anteriores; a base37 é recusada por binário antigo. Documentos sem
identificação estrutural continuam legados válidos, até adoção explícita P01.
Este corte **não** implementa identidade universal lexical, ocorrências múltiplas
do mesmo bloco, inserção de trechos compartilhados ou montagem editorial P04.

## Operações sob visibilidade parcial

O mesmo buffer conserva a representação integral e usa uma tag de apresentação
invisível para omitidos. A tag não é o mecanismo de edição: transações revalidam
a origem e decompõem a seleção em intervalos visíveis. Nenhum perfil é corpo
editorial alternativo, tampouco escolhe silenciosamente exportação.

- Digitação nativa revalida os iteradores GTK após a transação canônica; teclado
  mantém o agrupamento de digitação e a composição IME separada no histórico.
- Recortar/substituir seleção descontínua conserva omitidos e fronteiras LF
  originais necessárias à identidade dos blocos ocultos. Copiar pega o exibido;
  colar estilos é explícito e não transporta IDs/bindings.
- Botão do meio lê PRIMARY pelo mesmo streaming limitado e cancelável do
  clipboard, sem perder a seleção que oferece o texto. Arrasto textual transfere
  uma **cópia de prosa**, sem estilos/identidades/vínculos; a alça move blocos
  conservando identidades. Não há MOVE textual assíncrono nativo que possa apagar
  seleção antiga em outro Documento. Esse contrato é igual na leitura integral
  e na filtrada; não existe uma classe de editor reduzida só para filtros.
- Formatação e limpeza de estilos operam por intervalo exibido. Busca é feita
  na projeção (não consome o limite com ocorrências ocultas) e os resultados
  retornam a coordenadas canônicas; não há match através de junção oculta.
- Nova marcação semântica pode criar marcações para fragmentos visíveis em uma
  operação. Uma ação que exige **um vínculo contínuo** exige alvo contínuo;
  não cria um vínculo envolvendo texto invisível para contornar a restrição.
- Parágrafo identificado vazio explicitamente visível conserva posição de
  inserção. Projeção vazia sem destino não inventa ponto no material oculto.
- Exclusão sem evidência confiável suspende a exibição; substituição integral
  de trecho semântico pode deixá-lo ambíguo/fora do perfil, sem apagar a origem.
- Falha de entrada conserva tentativa acessível para copiar/descarte explícito.

## Ordem em projeções

Toda alça/teclado/ação declara bloco, identidade do vizinho e lado antes/depois.
Com apenas5,10,15 exibidos, mover15 antes10 produz `...8,9,15,10...`; mover5 depois15
produz `...13,14,15,5...`. Os ocultos mantêm ordem relativa. O lado do mesmo vizinho
resolve a ambiguidade do espaço que visualmente também antecede outro vizinho.
Resmas multilinha seguem indivisíveis; movimento que rompe trecho vinculado é
recusado atomicamente. Cronologia, causalidade e ordens do planejamento/editorial
não são derivadas da leitura do Documento.

## Evidências e fronteiras

O manifesto P03c-verificacao.json da tarefa registra resultados terminais e
lacunas; compilar/testar não prova produtividade, conforto prolongado ou aceite.
Sanitizadores são focais com dependências Release, não aplicação toda Debug/LSan.
IME sintético não certifica dispositivos reais; capturas não são auditoria a11y
ou HiDPI. Benchmark anterior não mede esta edição unificada e não é reutilizado
como ganho de desempenho. Observação GTK intermitente P03a continua aberta até
causa demonstrada. P04, D06 e publicação seguem fora deste corte.

O cache linear continua persistido/serializado por compatibilidade, junto com
os conteúdos de bloco; isso pode aumentar armazenamento. A TextView conserva
o corpo integral: não é paginação preguiçosa nem promessa de redução de RSS.
Compartilhamento imutável no histórico, mapas por demanda, busca binária e
prefixos retiram trabalho repetido, mas não substituem medição comparativa de
latência GTK/SQL/renderização e sessão real. Nenhum percentual de ganho foi inferido.
