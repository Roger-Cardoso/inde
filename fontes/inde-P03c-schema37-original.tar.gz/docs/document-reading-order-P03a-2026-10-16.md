# Ordem de leitura — P03a

O usuário aceitou a entrega anterior até P02 e autorizou iniciar o restante,
acrescentando círculos laterais para arrastar blocos. Este primeiro incremento
do P03 implementa reordenação; não encerra ocultação/perfis/lentes filtradas.
Schema35 mantido. Nenhum texto oculto por perfil é simulado por exclusão.

## Trabalho do escritor

Ao lado esquerdo, fora da superfície de escrita, cada bloco tem um círculo.
Arrastar mostra uma marca do destino; só soltar confirma. Escape cancela sem
escrever. Arrastar perto das extremidades rola o texto. Um clique sem arrasto
não muda a ordem. A seleção do bloco depois de mover continua no mesmo editor.

Na faixa de círculos, setas percorrem blocos; Ctrl+acima/abaixo move o escolhido;
Home/End percorrem extremos; Enter devolve foco ao texto; Tab continua nativo.
O menu Ações do Documento oferece os dois comandos de movimento do bloco onde
está o cursor, sem exigir mouse ou gesto. Documentos legados precisam primeiro
da adoção explícita de identidades de parágrafo do P01.

## Unidades e conservação

Um parágrafo identificado é a unidade automática inicial, não uma decisão ou
uma cena inferida. LF separa parágrafos; linhas quebradas visualmente não criam
outros blocos. Vazios e último parágrafo são unidades. Uma resma que cruza limites
de parágrafo une esses parágrafos numa unidade indivisível, marcada por um ponto
adicional sob o círculo. Não divide resmas nem duplica folhas. Trechos manuais
continuam âncoras independentes, não são convertidos automaticamente em módulos.

A operação permuta as mesmas identidades; reconstrói os separadores LF entre
parágrafos. Não cria/aposenta IDs. Topo, resma, folhas encobertas e referências
continuam os mesmos. Estilos acompanham os caracteres e podem ser repartidos.
Âncoras positivas precisam continuar intervalos únicos, contíguos e na mesma
ordem interna; movimento que inverteria/fragmentaria um trecho ou retiraria um
LF incluído nele é recusado inteiro. Âncoras pontuais acompanham seu parágrafo.
Essa proteção é explícita; não estende silenciosamente o bloco selecionado.

Marcação semântica conserva o trecho e o binding. A evidência textual é
inspecionada antes: divergência anterior continua ambígua/órfã; não é reparada
por mover. Para vínculos resolvidos e texto selecionado idêntico, somente contexto
e revisão da evidência são atualizados, em lote. Não é reancoragem por similaridade.
A restrição P02 de trocar folhas com vínculos permanece; P04 não foi antecipado.

Uma transação de edição/histórico, salvamento CAS, snapshot, journal, reabertura
e Salvar como usam o estado já existente. Nenhuma tabela/migração nova. A entrega
inclui uma barreira de recuperação: após desfazer/refazer até o estado já salvo,
a sessão pode ser confirmada sem nova escrita do corpo, mas somente após drenar
os workers e comparar o estado completo com o disco. Divergência/erro conserva
o checkpoint; não há limpeza forçada nem descarte de registros.
Mover altera a posição do texto no próprio Documento; não reordena nós editoriais,
sucessão causal, tempo ficcional ou fila de escrita. Consequências interpretativas
da nova sequência são julgamento do autor, não validação automática de coerência.

## Custo e limites

Um gutter virtualizado, sem widget por parágrafo. A pintura consulta o layout
do GtkTextView e apenas os blocos na região visível; coordenadas são convertidas
entre widgets para respeitar bordas/padding/rolagem. A lista estrutural é derivada
quando a edição muda, não por cópia de prosa em cada frame. Reordenar é operação
sobre o corpo, com cópia linear do texto e histórico normal; não promete custo
constante nem comprova conforto em sessão longa. Preserva o limite P01 de100.000
identidades ativas+retiradas e demais limites P02.

Pendências deliberadas: P03b ocultação/perfis de visibilidade e projeções editáveis
por quaisquer marcações, inclusive semânticas intraparágrafo; P04 usos de identidade
no planejamento/editorial. Não apresentar realce colorido como filtro editável.
Novo aceite humano aberto. Gates próprios no manifesto P03a da tarefa; resultados
históricos P02 não certificam esta fonte. Nenhum D06, commit/publicação ou obra
autoral aberta/migrada. Pacotes anteriores preservados.
