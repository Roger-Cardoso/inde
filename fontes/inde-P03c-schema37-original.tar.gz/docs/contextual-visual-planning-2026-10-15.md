# Planejamento como composição visual editável

Autorização: aplicar a lógica visual do protótipo do autor ao planejamento
modular, implementando faltantes e adaptando o existente. Possível papel de meio
principal de planejamento é direção a avaliar, não aceite antecipado. O botão
Planejamento visual é acessível no cabeçalho narrativo; a superfície é padrão
dentro da composição. Planos anteriores e lista continuam disponíveis.

## Trabalho e autoridade

Anotar sem classificação, distribuir trechos, comparar percursos em faixas,
ajustar extensão e curva, reunir uma seleção e trabalhar seu interior. Conteúdo
compartilhado e participação local permanecem os mesmos do schema32. A superfície
não gera cópias de acontecimentos nem do texto. Documento mantém autoridade.

Disposição é autoral: coordenadas, extensão, cor, legenda, forma, cinco alturas de
curva, faixas, marcos e expansão são gravados no Projeto. Posição não declara
ordem narrativa, cronologia, categoria, simultaneidade ou causalidade. Guias de
alinhamento são ajuda geométrica, não vínculos. Faixa é organização visual livre,
não um owner semântico; mover somente sua moldura não move os trechos contidos.
Para mover peças juntas, selecione-as; para constituir um módulo, Agrupar.

As ligações desenhadas são dependências explicitamente declaradas no nível
corrente. Contenção continua explícita e diferente de dependência. Outros usos
do mesmo trecho compartilham conteúdo/interior, mas têm disposição própria.

## Interação

- Duplo clique no vazio e captura acima/Enter: cria naquele ponto em transação
  única. Captura comum também aceita apenas título ou descrição incompleta.
- Arrastar corpo move; Shift permite seleção múltipla; arrastar vazio seleciona
  um retângulo; canto inferior direito muda extensão. Cinco pontos ajustam os
  percursos quebrado/curvo. Reta não atribui valor narrativo à altura.
- Roda aproxima; botão central desloca câmera; Panorama/Home enquadra; menu
  oferece Focalizar seleção. Faixas/marcos e propriedades aparecem sob Superfície
  ou menu contextual. Nenhuma operação essencial depende de clique secundário.
- Tab/Shift+Tab percorrem trechos; setas movem 10 unidades, Shift+setas 50;
  Ctrl+A seleciona trechos; Ctrl+G agrupa; Enter abre/desenvolve; F2 abre
  propriedades com coordenadas, dimensões, cor e alturas por teclado. Escape
  cancela o gesto ainda não gravado. Histórico do Projeto reverte gestos gravados.
- Ctrl+Z/Ctrl+Shift+Z (ou Ctrl+Y) na superfície desfaz/refaz até 16 disposições
  desta sessão e composição. O mesmo acesso existe em Superfície. São operações
  normais de geometria com CAS, sem reverter conteúdo ou edição externa. Outra
  mudança no conjunto invalida a pilha local; o histórico durável permanece.
  Agrupamento altera estrutura: sua reversão usa o histórico do Projeto.
- Lista é a alternativa com os mesmos dados, seleção e comandos. Não converte
  visual em ordem. Ordem local permanece editável explicitamente.
- Expandir/recolher mostra uma prévia de um nível; abrir interior permite sua
  edição visual própria, e Voltar restaura câmera/modo/seleção/rascunho. Prévia
  mostra até seis células, avisando outras partes; não é expansão recursiva nem
  editor de todos os níveis simultaneamente. Até oito prévias por composição.
  Prévia enumera partes/opções, não certifica a escolha ativa do interior; membros
  de opções são identificados. A superfície do próprio interior distingue os
  usos fora da escolha atual, sem ocultá-los ou descartá-los.

## Persistência

Schema33 aditivo, tabela contextual_visual_items, FK composta de Projeto/Obra/
composição e da participação para blocos. Faixas/marcos têm identidade própria,
sem criar fato narrativo. Migração cria tabela vazia e não interpreta desenhos
ou arquivos do protótipo. Layout inicial não gravado é apenas sugestão; gestos
gravados conservam as posições de todos os blocos apresentados.

Revisão contextual inclui disposição; gesto ou formulário obsoleto é recusado
atomicamente. Criação no ponto é atômica. Save As rebasa owner; retirada de uso
inclui sua representação; agrupamento move as representações existentes com as
participações e conserva coordenadas/curvas, deixando faixas e marcos do conjunto
na origem e criando o bloco externo. Histórico conserva/reverte esses efeitos.

Limites por composição: 2.000 participações, 2.400 elementos visuais, agregado
8 MiB; posição ±100.000, largura80–20.000, altura64–4.000, alturas de curva0–1.000.
Contagem visual e limite de prévias são verificados também na simulação e
confirmação de reversão, inclusive quando uma prévia segura ficou obsoleta.
Limites modulares anteriores continuam: 200 composições/interiores por Obra,
16 níveis e 16.000 usos compostos. Prévia local limitada, sem enumerar caminhos
compartilhados. Pintura por invalidação, com descarte fora da janela; câmera e
rascunho em preferências isoláveis, geometria no banco com histórico.

Não inclui importador .sopa, exportador visual novo, desenho vetorial arbitrário,
desagrupar genérico, comparação editável de várias composições independentes na
mesma superfície ou inferência do significado de curvas. Não há benchmark de
produtividade/sessão longa nem certificação de leitor de tela/HiDPI/IME físico.
Testes e hashes atuais ficam no manifesto externo da entrega; aceite humano
continua aberto. D06, publicação, promoção e bancos autorais não autorizados.
