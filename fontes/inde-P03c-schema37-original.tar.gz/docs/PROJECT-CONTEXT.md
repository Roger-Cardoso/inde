# Candidato privado atual — editor unificado e especializações P03c / 2026-10-16

Pedido explícito: implementar especializações no mesmo editor e corrigir a
visualização separada/limitada do P03b. Texto/formatação é o início; Semântica,
Linguística, Estrutura e Vínculos narrativos reorganizam ferramentas e realces,
sem trocar Documento, seleção, fonte, histórico ou perfil de visibilidade.
A antiga VisibilityLensPage saiu do fluxo e do alvo de produção; o explorador
semântico é inspetor lateral da mesma escrita. Busca, formatação, clipboard e
marcações tratam somente os intervalos exibidos; vínculos únicos não atravessam
material oculto. Movimento usa identidade do vizinho + antes/depois, não índice
filtrado. [Contrato](document-unified-editor-P03c-2026-10-16.md).

Schema37: parágrafos consolidados conservam conteúdos imutáveis por identidade,
sequência explícita e coordenadas derivadas. Document.content é representação
linear validada de compatibilidade; Documentos legados sem estrutura continuam
válidos. Migração36→37, codec de blocos2, journal8/snapshot5 com leitura dos
formatos anteriores (binários antigos não abrem a base37).
Não é implementação do motor completo por palavra/frase nem P04. Restrições de
folhas atravessadas por âncoras permanecem explícitas, sem reassociação implícita.

Gates próprios P03c-verificacao.json na tarefa (em andamento enquanto não houver
resultado terminal). Aceite humano confirmado só até P02; P03a/P03b/P03c não
recebem aceite por automação. P04/D06, commit/publicação e obras autorais fora do
escopo. Pacotes anteriores congelados. Cabeçalhos seguintes são históricos.

# Contexto anterior — visibilidade e lentes P03b / 2026-10-16

Pedido atual: “Iniciar p3b”. Perfis persistentes por documento, ocultação reversível
e lente contínua editável por parágrafos/resmas/trechos/tipos semânticos/marcações
individuais/estilos, inclusive intraparágrafo. Schema36 aditivo. Corpo integral
continua autoritativo; edição mapeada conserva omitidos e folhas encobertas.
[Contrato e limites](document-visibility-P03b-2026-10-16.md). Perfis são de trabalho,
não escolhem saída editorial. Ferramentas completas/arrasto/marcação/alternativas
permanecem no original; LF protetores não são consumidos pela lente.
Gates próprios em P03b-verificacao.json da tarefa; não transferir gates antigos.
Aceite humano confirmado só até P02, sem inferir aceite P03a/P03b. P04 pendente;
sem D06, commit/publicação ou obra original aberta/migrada. Pacotes anteriores
preservados. Os cabeçalhos seguintes são históricos, não estados atuais.

# Contexto anterior — ordem de leitura P03a / 2026-10-16

Usuário confirmou aceite humano de tudo entregue até P02 e autorizou iniciar o
restante, com círculo lateral esquerdo fora da escrita para arrastar blocos.
Primeiro incremento P03a: parágrafos/resmas indivisíveis na ordem do Documento,
mesmas identidades/folhas/vínculos, movimento atômico com undo; gesto, Escape e
alternativa por teclado/menu. [Contrato e limites](document-reading-order-P03a-2026-10-16.md).
Schema35 mantido; pacotes aceitos anteriores congelados. Aceite novo aberto.
P03b ocultação/perfis/lentes filtradas editáveis e P04 ainda pendentes; não
confundir realce com filtro nem reordenar planejamento, cronologia ou editorial.
Sem D06, commit/publicação ou obra autoral aberta/migrada. Gates próprios em
P03a-verificacao.json na tarefa; não transferir evidências históricas.

# Contexto anterior — folhas/resmas P02 / 2026-10-16

Autorizado “implemente p02”: folhas/resmas com identidades próprias e topo por
ID no editor contínuo; alternativas encobertas guardam texto/estilos imutáveis,
topo continua exclusivamente em Document.content. Schema35 aditivo, transação/
CAS/undo/journal e SaveAs conservam alternativas; copiar revisão/resgate cria
IDs locais novos. [Contrato e limites](document-resmas-P02-2026-10-16.md).
Delete edita apenas topo; resmas vazias continuam acessíveis, sem destruir folhas
encobertas. Controles contextuais, criação pela seleção/parágrafo, nomes opcionais.
Criar/trocar com âncoras que intersectam é recusado: não transferir vínculos por
posição. P03/P04 ainda pendentes; gates próprios no manifesto P02 da tarefa.
Aceite humano aberto; sem D06, obra original aberta/migrada, commit ou publicação.
Pacotes anteriores preservados; cabeçalhos seguintes são históricos.

# Contexto anterior — documento estrutural P01 / 2026-10-16

Início autorizado da integração escrita/planejamento/editorial, depois da
discussão de folhas, resmas, visibilidade e lentes semânticas. Primeiro corte
deliberado: identidades persistentes dos parágrafos no editor contínuo, sem
duplicar prosa ou inferir significado. Schema34 aditivo; adoção explícita para
legados e identificação automática para novos Documentos criados pela interface.
[Contrato, compatibilidade e limites](document-structural-foundation-P01-2026-10-16.md).
Gates atuais e limites no manifesto P01-verificacao.json da tarefa; não transferir
gates históricos para esta fonte. Resmas/alternativas, ocultação/lentes editáveis
e novos usos de identidade por planejamento/editorial ainda não entregues.
Aceite humano aberto; sem D06, commit/promoção/publicação ou obra autoral aberta.
Pacotes anteriores preservados. Este cabeçalho não concede aceite aos anteriores.

# Contexto anterior — refinamento operativo / 2026-10-15

Schema33 mantido. Continuação autorizada do planejamento visual: revisão em lote
de ordem local/sucessão explícita, organização geométrica com prévia/undo,
seleção de faixa+blocos contidos, seleção parcial por teclado e navegação local,
alvo correto de menu/cancelamento e leitura econômica de prévias compartilhadas.
[Contrato e limites](contextual-operative-refinement-2026-10-15.md). Gates e
pacote próprios em OPERATIVO-verificacao.json na tarefa; não transferir os gates
históricos abaixo para este conteúdo. Aceite humano aberto; nenhum D06,
commit/promoção/publicação ou obra autoral aberta. Pacotes anteriores preservados.

# Contexto anterior — composição visual / 2026-10-15

Schema33 cumulativo sobre o corte modular32. Superfície editável e persistente
integrada ao planejamento; lista e mecanismos anteriores conservados. Direção
autorizada pelo usuário após examinar seu protótipo, sem aceite antecipado de
usabilidade ou promoção a meio principal. [Contrato e limites](contextual-visual-planning-2026-10-15.md).
Resultados técnicos/hashes no manifesto privado da tarefa; não extrapolar
resultados históricos abaixo para este conteúdo. Sem migração de obra autoral,
commit, publicação ou D06. Entregas congeladas anteriores preservadas.

# Contexto histórico — aceite humano e publicação / 2026-10-12

Aceite humano do candidato de teclado confirmado e publicação no GitHub
autorizada pelo usuário. Código e documentação técnica publicados como snapshot;
conversas integrais e acervo privado permanecem locais. Schema 28 mantido.
[Identidade, evidências e limites](publication-2026-10-12.md).
Os registros abaixo preservam os estados históricos de cada emissão.

# Contexto histórico — teclado contextual / 2026-10-12

Usuário aprovou a proposta de teclado e autorizou aplicação. Registro explícito
por janela e contexto, paleta transitória, ajuda e preferências locais de atalhos;
campos nativos, IME e confirmação de risco têm prioridade. Navegar no calendário
não escolhe data; cronologia não reordena narrativa. Schema 28 e núcleo de dados
inalterados. [Contrato e roteiro de revisão](keyboard-workflow-2026-10-12.md).
As 417 famílias aprovadas não significam 417 combinações globais: comandos
diretos, contextuais, nativos e de paleta são camadas distintas. A matriz e o
catálogo implementado devem ser consultados no novo manifesto de atalhos da
tarefa. Debug/sanitizers são focais, não builds integrais certificados.
Novo aceite humano pendente. Sem commit, promoção ou publicação; entrega
anterior preservada. Registros seguintes são históricos.

# Contexto histórico — vocabulário autoral / 2026-10-12

Usuário confirmou aceite do bloco anterior e aprovou todas as propostas da
auditoria de vocabulário de 2026-10-12. Aplicação na cópia privada atual, sem
renomear nomes autorais, chaves ou dados e sem migração: schema 28 mantido.
Formulários comuns substituem exigência de chave/JSON; detalhes técnicos são
opcionais. As quatro ordens e os estados de informação permanecem distintos.
[Contrato, proteções e revisão](author-vocabulary-2026-10-12.md).
O manifesto da nova entrega registra a verificação deste candidato; aceite
humano do novo executável continua pendente. Não houve commit, publicação ou
substituição de entregas congeladas. Registros abaixo são históricos.

# Contexto histórico — realização textual e continuidade / 2026-10-11

Usuário confirmou aceite humano do corte de acesso/tema e autorizou este bloco.
Schema 28 aditivo, sem reescrever os vínculos legados nem changesets anteriores.
Planejamento não armazena uma segunda cópia do trecho: Documento/bloco é a
autoridade textual. Independência de prosa é decisão explícita com proveniência.
As quatro ordens seguem independentes; avisos são derivados de declarações e
nunca bloqueiam escrever/salvar. Presença exige intenção específica.
[Contrato e escopo](narrative-realization-continuity-2026-10-11.md).
Verificação técnica deste corte concluída: 33/33 CTest, 291 unidades sem avisos,
Debug e sanitizers focais do núcleo, 16 verificações da nova interface,
32 de regressão, dois startups e inspeção de seis quadros finais.
Os hashes e limites ficam no manifesto de realização/continuidade da tarefa.
Nenhuma aprovação técnica histórica se transfere automaticamente a este hash.
Novo aceite humano pendente. Candidatos e cópias anteriores preservados.
As seções históricas mantêm o estado da emissão, não revogam aceites posteriores.

# Contexto histórico — compatibilidade de tema herdado / 2026-10-11

O terminal humano revelou CSS Orchis incompatível com GTK 4.14.5. Principal e
laboratório agora preparam base Adwaita antes de inicializar GTK, sem alterar
fontes/ícones/preferências do desktop; override explícito preservado. Sistema
detecta Dark também em maiúsculas. [Contrato](theme-compatibility-2026-10-11.md).
Schema 27; CTest 32/32 e auditoria das 286 unidades sem avisos finais. Matrizes
normal e focal de tema com reprodução negativa; sonda real do desktop sem janela.
Novo manifesto: `outputs/reforma-acesso-planejamento-tema-entrega-2026-10-11.json`
na raiz da tarefa. Aceite humano pendente, não commitado, sem publicação.
Os testes abaixo são históricos do candidato anterior, não deste executável.

# Contexto anterior — acesso inicial e interação narrativa / 2026-10-11

Correção autorizada de Projeto limpo, biblioteca de estruturas e layout fixo.
Schema 27 sem nova migração. Primeira Obra/universo em contexto, menus por item,
seleção comparativa com múltiplos alvos, modelos recolhidos e seções de largura
integral sem GtkPaned no workspace narrativo. Auditoria de avisos em compilação
limpa e execução GTK. Ver [contrato e revisão](narrative-access-2026-10-11.md).
Verificação técnica concluída: CTest 31/31, 277 unidades recompiladas sem avisos
finais, 52 verificações de execução e dois startups sem avisos, Debug e sanitizers
focais e onze quadros inspecionados. Manifesto privado
`outputs/reforma-acesso-planejamento-entrega-2026-10-11.json` na raiz da tarefa.
Aceite humano pendente; fonte não commitada e candidatos anteriores preservados.

# Contexto anterior — alternativas, linhas e impacto / 2026-10-11

Continuação autorizada por “prossiga”, sem inferir aceite retroativo do primeiro
corte. Base Git 995fbb27 + primeiro construtor privado congelado. Schema 27:
derivação contextual completa, proveniência/comparação por linhagem, ordem própria
das linhas e prévia de movimentos com autoridade declarada dos vínculos.
Documentos e cadastros externos compartilhados mediante reconhecimento explícito;
nenhuma promoção canônica, ativação ou colocação editorial automática.
Ver [contrato e revisão](narrative-alternatives-2026-10-11.md).
Verificação técnica concluída: Release/CTest 30/30, Debug e ASan/UBSan focais,
GTK alternativas 8/8 + instrumentado 8/8, regressão construtor 8/8 e temporal 8/8,
startup principal/laboratório e inspeção visual selecionada. Aceite humano pendente.
Manifesto privado: `outputs/reforma-alternativas-narrativas-entrega-2026-10-11.json`
na raiz desta tarefa; evidências e limites não equivalem a aprovação de produto.
As quatro ordens permanecem independentes. Reconhecimento de entidades por último.
Fonte não commitada; entregas anteriores congeladas, sem push/tag/publicação.

# Contexto anterior — fundação do construtor narrativo / 2026-10-11

Base verificada e aceita pelo usuário: `995fbb27f8ee9359643a90f0220bc71269ef5e9a`,
branch privada `codex/reforma-fluxo-temporal-2026-10-10`. A proposta de construtor
integrado foi autorizada com rigor explícito sobre quatro ordens independentes.
Este primeiro corte entrega contrato/reparo operacional e uma realização textual
inicial, não encerra os quatro blocos da proposta. Schema 26 aditivo.
Leia [contrato](narrative-builder-contract-2026-10-11.md) e
[estado e revisão](narrative-builder-increment-2026-10-11.md).
Montagem, cronologia, fila opcional de escrita e apresentação editorial não se
sincronizam por posição. Precedência legada não recebe classificação automática.
Texto continua no Documento; Local planejado não cria presença, relações em foco
não alteram relações canônicas. Reconhecimento de entidades continua por último.
Derivação com contexto adicional fica protegida até a implementação de cópia
completa. Aceite deste novo corte continua pendente; sem push ou publicação.
O conteúdo abaixo é histórico e não identifica o candidato atual.

# Contexto anterior — auxiliar de exclusão e integração do tempo / 2026-10-10

Predecessor verificado: `9dadf11dcb0a64e35e91719ea1547f93d3e4c523`, fase
temporal contínua. O pedido atual corrige a experiência de exclusão protegida:
listar usos nomeados, abrir sua origem, retornar à exclusão com nova inspeção,
desvincular o único calendário e revisar sucessões explicitamente. A Biblioteca
de Tempo e a configuração do calendário agora têm acesso em Tempo ficcional.
Consulte `removal-assistant-2026-10-10.md` e o manifesto deste incremento.
Schema 25 mantido; sem push ou publicação. O candidato anterior e suas cópias
de revisão são preservados. Verificação técnica não é aceite humano desta
correção. Reconhecimento de entidades continua por último; reforma cartográfica
e fusos não foram antecipados. O conteúdo abaixo é histórico, não identifica
o HEAD atual.

# Contexto histórico — Editor conectado ao Projeto / 2026-10-04

Fonte: codex/editor-interaction-2026-10-04, HEAD-base f155bd8, sem
commit/push/release. Predecessor imediato: editor-montagem-2026-10-04,
148 itens congelados. A reforma E5-S1R recebeu aceite humano geral no pedido
atual (“gostei, ficou bom”). O usuário priorizou interações do editor com o
Projeto; E5-S2 de montagem persistente fica em espera.

Este corte muda o editor PRINCIPAL, não o laboratório: menu contextual para
criar entidade/tipo, vincular existente, criar relação/tipo com sentido explícito,
materialização associativa, distribuição semântica e popup inline de dados do
Projeto. Duas novas definições protegidas v1, sem migração ou mudança de codecs:
inde.semantic.entity-mention e inde.semantic.materialization.
Schema 18, semântico 2, checkpoint 4, clipboard 2 e journal/envelope 1 mantidos.

Ocorrência nova usa uma anotação com entidade canônica e evidência de âncora,
não uma segunda cópia de DocumentEntityReference. Projeções consultam ambas
as origens e deduplicam IDs. Relação canônica é distinta de relação entre
marcações; materialização não cria evento temporal, informação inferida ou data.
Criação de entidade/tipo/vínculo é atômica e CAS; relação/tipo usa transação
com snapshots esperados das duas entidades e do tipo.

Texto/desfazer/recuperação conservam vínculos. Desfazer no editor não apaga
cadastros do Projeto. Intervalos são Unicode capturados antes de trocar foco;
Projeto/Documento/revisão/IME guardam confirmação. Dados inline são revisados
em prévia e só inseridos/vinculados por escolha. Análise é projeção do rascunho,
sem NLP automático, porcentagens por união e sobreposição, limites declarados.

Leia editor-project-interaction-2026-10-04.md e BRIEF.md do diretório pai.
Evidências atuais: outputs/editor-interacao-*. Tentativas incompletas ficam em
logs separados; apenas verificação final e hashes válidos constituem entrega.
Gate técnico: 16 CTest, 17 verificações GTK, 18 capturas, preservação de linhas
anteriores e ASan/UBSan focal de 18 unidades passaram. Criação atômica fora do
worker limpa seu baseline antigo após sucesso; teste cobre o próximo autosave.
Revisão humana desta interação é pendente; não inferir certificação IBus,
45 minutos ou release. Catálogos lexicais continuam somente leitura, sem binding.
Revisar este incremento antes de novo corte. Sol/medium para UX; high para
integridade persistente. Calendário após Etapa 5, gen7/HTML dispensados.

## Contexto histórico do predecessor E5-S1R (não descreve o novo editor)

Fonte isolada: branch codex/editor-workshop-2026-10-04, HEAD-base
f155bd866d32c9326e5853a2882e6adbfca6ba23, alterações sem commit/push/release.
Original externo e nove arquivos sujos preservados. Predecessor imediato:
editor-etapa5-spike-2026-10-04, congelado com 87 itens no manifesto.

Incremento semântico 3 aceito. Editor principal mantém SHA
b0a0569458607db73bae1227e06be2c44722499e094927bd3b3cb1f7a0619e5a.
Schema 18, semântico 2, checkpoint 4, clipboard 2, journal/envelope 1.
Laboratório E5-S1 recebeu feedback crítico, não aceite humano de UX.

E5-S1R reforma profundamente a montagem: limites de recorte escolhidos pelo
autor, foco identificado, biblioteca/usos sincronizados, edição/leitura separadas,
painéis/versões simultâneos, múltiplos Documentos, alternativas por família e
promoção a bloco independente. Camadas conserváveis são reidentificadas; cortes,
perspectivas globais compostas e conflitos recebem avisos, sem vencedor automático.

Montagem, blocos e versões permanecem em memória. Criação confirmada salva
Documento novo e independente somente na cópia preparada, após prévia e avisos;
não sobrescreve origens, não salva vínculos vivos/sessão. Editor principal não
ganha laboratório ou novo backend. Build experimental OFF por padrão.

Leia editor-workshop-2026-10-04.md, implementation-status.md,
architecture-decisions.md e development-roadmap.md. Estado anterior preservado
em editor-stage5-spike-2026-10-04.md; limitações antigas não descrevem a reforma.
Evidências e manifesto outputs/editor-montagem-* no workspace de entrega.
Tentativas falhas são diagnóstico; somente resultados finais/hashes atuais contam.
Não alterar artefatos congelados nem inferir gate humano de CTest/sanitizer.

Gate próprio: 15 CTest, vazio limpo/vazio/Atlas em display/perfil privados,
seleção/versões/rascunhos/reutilização/promoção/múltiplas origens, draft de 100 mil
palavras, prévia/criação/readback, integridade/FKs e todas as linhas anteriores.
Contador SQLite change_log pode avançar com novo Documento, separado da auditoria
autoral. Sementes/origens e perfil real permanecem intactos. ASan/UBSan focal
em dez unidades experimentais e drivers; núcleo/dependências Release, LSan off.
Não certifica IBus, resistência de 45 minutos, latência percebida ou publicação.

Próximo: revisão humana E5-S1R e ajustes delimitados. E5-S2 requer autoridade
única, conversão/recuperação e política de camadas antes de schema persistente.
Calendários reais/fictícios e unidades após Etapa 5. Gen7/HTML dispensados,
binding lexical mantém gate próprio. Nenhuma etapa inteira encerrada.
GPT-6.1 Sol/high para persistência/integração; medium para UX delimitada.
