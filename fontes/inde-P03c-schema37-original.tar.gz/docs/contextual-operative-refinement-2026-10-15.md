# Refinamento operativo da composição visual

Continuação autorizada dos pontos imaturos/omitidos do planejamento discutido.
Schema33 mantido; sem migração nova ou transformação automática de planos.
Não amplia a meta contextual nem inicia D06. Aceite humano próprio permanece
aberto; ver manifesto OPERATIVO-verificacao.json externo ao checkout para gates.

## Revisar o encadeamento sem repetir cadastro

Selecione ao menos dois trechos → Superfície (ou menu contextual) → Revisar
sequência selecionada. A revisão começa na ordem local atual. O autor pode
pedir proposta esquerda→direita ou cima→baixo e movê-los na revisão antes de
confirmar. Empates espaciais usam ordem local, não identificadores aleatórios.
Até50 linhas por página, com movimento entre páginas, sem2.000 widgets de lista.

Aplicar ordem local e declarar sucessão são escolhas independentes. Sucessão
vem desligada. Reordenar permuta somente os lugares dos selecionados: não
compacta/intercala novamente os outros trechos, não muda o desenho, o texto,
cronologia, ordem de escrita ou editorial. Aplicar somente sucessão não muda
ordem local. As ligações anteriores, inclusive suas notas e sentidos inversos,
permanecem intactas; consulta recolhida e aviso de inversões ajudam a revisá-las.
Não resolve ciclos, escolhe alternativas ou afirma coerência narrativa.

Somente sucessões adjacentes ausentes são acrescentadas; ligações iguais não
são duplicadas. Sucessão não transmite declarações como Contexto recebido.
Trechos de opções permanecem opções. Outros usos do mesmo conteúdo não mudam.
IDs, vínculos, categorias, paralelismo, escalas e interiores são preservados.

Uma transação, revisão contextual/CAS e operação de histórico para o lote.
Não gravar nada ao revisar/cancelar; falha tardia/limite/confirmação obsoleta
reverte o lote inteiro. Repetir sem diferenças não cria operação vazia.
Reversão estrutural/da ordem usa histórico do Projeto, não undo geométrico.

## Organizar a superfície

Com vários trechos selecionados → Organizar trechos selecionados. Prévia sem
gravação, confirmação explícita, cancelar restaura. Alinhar esquerda/direita/
topo/base; distribuir intervalos horizontal/vertical entre extremos (mínimo3);
ou montar fila/coluna com40 unidades livres entre peças (mínimo2).

Só coordenadas dos blocos selecionados mudam; tamanho, curva, cor, legenda,
faixas, marcos, conteúdo e relações não são reinterpretados. Distribuição que
não cabe sem sobrepor é recusada; fila pode aumentar a extensão do conjunto.
Limites são recusados integralmente, sem comprimir/clamp individual. Distribuição
inteira admite diferença de uma unidade entre intervalos. Save_visual/CAS e
desfazer/refazer local16 permanecem; histórico durável conserva cada confirmação.

Faixa selecionada → Selecionar faixa e trechos inteiramente contidos. Acrescenta
à seleção somente blocos inteiramente dentro da moldura observada; não inclui
marcos, blocos cortados ou outras faixas. A faixa e as peças escolhidas podem
ser movidas juntas; não cria pertencimento persistente. Nova seleção é necessária
se o desenho mudar. Agrupar continua sendo a operação que cria um módulo real.

## Interação e custo

Tab/Shift+Tab seguem a ordem local do plano, independente da ordem de gravação
dos UUIDs. Ctrl+Shift+seta direita/esquerda amplia a seleção até o próximo/anterior
na ordem local, sem circular nos limites: Tab permite escolher o início de uma
seleção parcial sem ponteiro; Escape limpa. Menu secundário resolve seu alvo antes de abrir/avaliar os comandos;
abrir por teclado conserva a seleção. Shift-roda respeita o limite de câmera.
Cancelamento do gesto restaura também câmera e guias, sem persistência parcial.

Prévia de interiores compartilhados lê cada composição distinta apenas uma vez
por atualização e distribui o resumo aos seus usos. Só um snapshot de interior
completo fica vivo nesse processamento; não há cache de oito agregados grandes
nem expansão recursiva. Revisão/ordenação operam sobre uma seleção limitada,
com índices em memória em vez de transações por vizinho e buscas repetidas em
toda a lista. Não há benchmark de latência/memória/produtividade que quantifique
ganho; mecanismo econômico não é comprovação de conforto em sessão longa.

## Limites mantidos

Não inclui desagrupar genérico de interiores compartilhados, edição simultânea
de vários interiores independentes, importador .sopa, exportador visual novo ou
editor vetorial geral. Faixa não possui filhos semânticos. Não há significado
automático de posição/curva/cor. Limites anteriores2.000 usos/2.400 elementos/
8MiB, oito prévias de um nível,200 planos e16 níveis continuam.

Original do protótipo, .sopa, entregas congeladas e cópias de avaliação anteriores
não são sobrescritos. Validação usa fixtures sintéticas isoladas; não certifica
acessibilidade/IME físico/HiDPI/Wayland nem substitui o passe humano real.
