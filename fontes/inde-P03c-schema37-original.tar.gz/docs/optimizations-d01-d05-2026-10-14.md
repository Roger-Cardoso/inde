# Primeiro lote de otimização D01–D05 — 2026-10-14

Base: commit aceito `89b47f27e83d76e1ef61a46cb6c29b8c75c305c4`, schema 28.
O usuário autorizou iniciar as cinco primeiras metas da fila de otimização.
Este é um candidato local, sem promoção, publicação ou alteração de projeto autoral.

## Mudanças

- D01: posição documental armazena somente identidade, cursor, seleção e rolagem.
  Registros antigos continuam aceitos. Espaços nomeados continuam snapshots próprios.
  A leitura de contexto usa um único lote; a escrita agrupa chaves e confirma o
  resultado. Valores idênticos não reescrevem o arquivo. O setter recarrega sob
  lock consultivo não bloqueante e conserva chaves/comentários desconhecidos;
  arquivo ilegível não é substituído. Escritores que ignorem o lock continuam
  fora da coordenação. Valores compostos do mesmo campo usam último escritor.
- D02: a contagem básica conserva as regras existentes e deixa recorrências e
  parágrafos longos para quando as ferramentas são abertas. Resultado atrasado
  continua invalidado por geração. Tamanho digitado exige Enter; +/- aplicam a
  escolha explicitamente. A seleção e o contexto continuam conferidos no idle.
- D03: comprimento e conversão Unicode são preparados uma vez por texto na
  operação. Checkpoints de 256 escalares e mapa de IDs evitam percursos desde
  o início e buscas cruzadas. SHA-256, janela de 32 escalares, gravity, revision,
  inspeção inicial, ambiguidades e reancoragem permanecem iguais. O índice
  não sobrevive à operação e não cria confiança entre revisões. A redação da
  ambiguidade não presume múltiplos candidatos; construções recebem nome próprio.
- D04: a vista reaproveita dados do snapshot, prepara posições/contagens e mantém
  o mapa de identidades da estrutura completa. A parte fora da linha é nomeada
  como tal. Empates na ordem de escrita continuam estáveis; partes sem posição
  ficam ao fim. Ctrl+Enter usa o mesmo percurso do botão Escrever.
- D05: relações possuem páginas de 50 + uma sentinela. Nomes são buscados pelos
  IDs da página, com lote limitado, sem carregar todas as entidades. Joins de
  nomes são necessários somente na busca textual. Filtros reiniciam a paginação.
  Seletores mostram resumo e ID curto. Formulários preservam rascunho em erro;
  depois de uma criação durável, erro de apresentação não convida a repetir criação.
  A página de relações entra no contexto salvo; estados antigos sem esse campo
  continuam aceitos e abrem a primeira página.

Nenhuma tabela, schema, taxonomia narrativa ou catálogo foi alterado. A meta de
composição contextual futura não foi implementada por este lote.

## Verificação

`inde_optimization_tests` adiciona comparação diferencial com o motor de âncoras
do commit aceito, congelado em `tests/semantic_anchor_reference.cpp` e nunca ligado
ao produto. Exercita 500 edições com Unicode, bordas, gravity, estados pendentes,
divergência externa, evidência ausente, limites inválidos e overflow de revisão.
Também testa dois escritores de preferências, idempotência, corrupção, métricas
básicas/completas, cancelamento e relações com mais de 50 resultados.

`tests/ui_optimization_smoke.cpp` é um driver opt-in ligado aos objetos reais da
interface, em fixture sintética com configuração própria. Verifica posição compacta,
formatação por confirmação, páginas/filtro de relações, vínculo fora da linha e
rascunho retido. Drivers existentes de toolbar e continuidade complementam o passe.
Verificação do lote: 34/34 CTest; comparação diferencial de 500 edições;
ASan/UBSan focal sobre teste, referência, preferências, texto, âncoras e coordenador
de análise, com demais dependências Release e LSan desligado. Drivers GTK ligados
aos 111 objetos reais da interface passaram o percurso do lote em claro/escuro e
a continuidade com seleção/rolagem/espaços nomeados, incluindo outro processo.
Os resultados de desempenho e a identidade exata dos artefatos ficam na entrega.
Os testes não representam aceite humano, IME real ou sessão longa.

## Alcance restante

São os primeiros recortes dos cinco domínios. Gestor de espaços, cache Unicode de
busca, snapshots compartilhados, formulários contextuais, comparação/continuidade
de planos, criação transacional com vínculo de obra, CAS de ficha e ficha progressiva
permanecem no plano. Este lote não encerra D01–D05 e não inicia D06–D09.

Avaliação humana continua necessária para conforto, IME, teclado físico, temas,
acessibilidade e sessão longa. Preservar a base aceita até decisão de promoção.
