# P03b — visibilidade reversível e lentes de trabalho

Pedido: “Iniciar p3b”. Incremento privado sobre P03a, sem antecipar seu aceite
humano. O aceite confirmado pelo usuário continua sendo até P02. Schema36
aditivo; nenhum P04, D06, commit, publicação ou abertura de obra original.

## Fonte e intenção

Document.content continua sendo o único corpo autoritativo: as folhas de cima.
Perfis não contêm prosa, cópias de folhas, ordem alternativa ou escolha editorial.
Ocultar não apaga, não troca o topo e não elimina uma resma ou suas alternativas.
Os parágrafos, folhas e resmas conservam identidades. Um perfil acompanha uma
reordenação P03a pelas identidades, não pela antiga posição.

Um perfil tem ID, nome, base integral ou união dos critérios de inclusão, menos
a união das exclusões. Exclusão prevalece. Critérios implementados: parágrafo,
resma, trecho manual, tipo semântico (incluindo vocabulário customizado), marcação
individual e estilo. Tipos/estilos sem ocorrências podem produzir zero resultado.
Referência estrutural ausente ou semântica não confiável gera diagnóstico, sem
reassociação automática. Exclusão não confiável suspende a lente inteira: não
revela automaticamente o que deveria ocultar. Inclusões não resolvidas não
ganham texto por aproximação. Anotações arquivadas não alimentam a lente.
Marcações documentais permitidas pelo domínio selecionam o documento inteiro;
marcações de trecho selecionam intervalos inclusive dentro do parágrafo.

## Trabalho pela interface

No documento integral, selecionar os blocos e usar “Experimentar leitura sem os
blocos escolhidos” cria um perfil de trabalho e abre sua lente. O menu do
Documento oferece “Visibilidade e lentes…” para criar, nomear e rever perfis,
adicionar/remover critérios, abrir a lente ou apagar apenas o perfil. Os seletores
são paginados (50 itens); não criam um widget por parágrafo de uma obra grande.

A lente é um GtkTextView contínuo derivado. Permite selecionar, escrever, copiar,
recortar, colar texto puro, desfazer/refazer no histórico compartilhado, salvar o
documento integral e voltar ao original com seleção/cursor mapeados. Formatação
existente é representada. Não constitui um segundo documento editável persistido.
Somente a definição do perfil persiste; reabrir começa no documento integral,
não numa escolha editorial ou perfil ativo implícito.

Ferramentas completas, busca/substituição, formatação, criação/troca de folhas,
marcação, arrasto e exportação continuam no documento integral neste incremento.
Seus comandos não recebem offsets da lente. A exportação integral avisa que os
perfis de trabalho não escolhem a saída. Não foi implementada saída editorial
filtrada nem a integração P04.

## Edição conservadora

O mapa usa offsets Unicode da origem e da vista; texto copiado é composto somente
por caracteres exibidos da origem. LF originais dos parágrafos exibidos mantêm
legibilidade, sem separadores inventados. LF adjacentes a texto omitido são
protegidos: apagar tudo que se vê não funde nem aposenta parágrafos ocultos.
Para junções estruturais, voltar ao original. Uma lente sem trecho editável pode
exigir desfazer ou voltar ao documento integral; não cria destino por adivinhação.

Uma edição nativa vira plano atômico de alterações somente nos intervalos
editáveis. Inserção na junção pertence ao próximo trecho visível; no fim, ao
anterior. Limites de resmas ocultas/vazias não absorvem essa inserção. Folhas
encobertas conservam os payloads compartilhados imutáveis. SHA256 do corpo
integral e rederivação do perfil recusam projeção obsoleta, inclusive se mudou
apenas o texto omitido. IDs, estilos, âncoras e evidência passam pelos mesmos
mecanismos conservadores do editor. Substituição semântica integral pode deixar
a evidência ambígua e o trecho sair da lente; o texto novo permanece na origem,
sem validação ou reancoragem narrativa automática.

Colagem lê em blocos limitados antes de recortar e revalida contexto/seleção.
Seleção primária por botão do meio e drop textual nativo estão desativados apenas
na lente, pois não compartilham esse contrato assíncrono. IME em composição
bloqueia saída/salvamento da lente. Se a transação falhar, o rascunho visível é
conservado para cópia e descarte explícito; não é silenciosamente perdido nem
salvo como substituto do corpo integral.

## Persistência, cópias e limites

Schema36 guarda um agregado JSON estrito por documento, com FK e limite2MiB.
Máximo32 perfis por documento e256 critérios combinados por perfil. Histórico
contabiliza seus bytes. Journal7/snapshot4 conservam perfis; versões anteriores
continuam legíveis. SaveAs, CAS, rollback, remoção/restauração e undo conservam o
agregado. Salvamento cego sem perfis não pode apagar perfis existentes.

Cópias independentes integrais ganham IDs de perfil novos e rebase explícito de
parágrafos/resmas. Trechos/marcações que não têm correspondente confiável ficam
indisponíveis com diagnóstico; não são religados por posição. Recortes parciais
não herdam um perfil como se descrevesse a nova origem. A restrição P02 sobre
troca de folhas com âncoras permanece até P04.

Projeção limitada a16MiB,16.384 intervalos finais (incluindo separadores protegidos)
e100mil intervalos coletados antes de união. Mapas de camadas são montados apenas
para os tipos usados pelo perfil; inspeção semântica ocorre apenas quando exigida.
São limites de segurança/implementação, não resultados de benchmark. Não alegar
certificação de desempenho global, produtividade, acessibilidade integral, IME
físico, HiDPI, sessão longa ou aceite humano a partir de testes automatizados.

Gates, hashes, roteiro e checkpoint atuais ficam nos artefatos P03b da tarefa.
Não transferir gates históricos de P03a/P02 para esta fonte; manter a observação
intermitente GTK do P03a aberta até causa determinada.
