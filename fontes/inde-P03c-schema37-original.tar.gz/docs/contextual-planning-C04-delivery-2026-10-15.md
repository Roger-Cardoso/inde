# Composição contextual — integração funcional C04

Meta: INDE-NEXT-COMPOSICAO-CONTEXTUAL-01, 19 contratos preservados. Este documento
descreve o incremento cumulativo, não substitui o veredito humano ou a referência
publicada. Schema 31, migração aditiva sobre 30, somente em fixtures/candidato.

## Uma origem, consultas em várias vistas

`contextual_references` liga uma participação a uma identidade canônica: elemento
(incluindo Local), relação, unidade, linha, referência temporal, ponto ou mapa.
Exatamente um alvo por registro, FKs compostas e remoção RESTRICT. Nota situada
opcional. Não cria escopo de obra, presença, relação ativa, data de acontecimento,
coordenada ou vínculo legado. Unidades/linhas são selecionadas na mesma Obra.
Demais identidades pertencem ao Projeto. Busca explícita, literal, caixa ASCII;
aliases são pesquisados para elementos. ID permanece visível para homônimos.

As consultas reversas (`projection`) partem do alvo indexado, filtram antes do
limite e devolvem 50 + sentinela. Botões sob demanda na ficha de elemento, menu
de relação, parte, linha, ponto, data e mapa/Local usam a mesma consulta. Outra
consulta abre as contribuições atuais com composição, participação e declaração
de origem. Editar na origem muda a declaração uma vez; as demais vistas não têm
resumos ou cópias a sincronizar. Não há cache duradouro nem invalidação global:
cada nova consulta lê as origens pertinentes na transação solicitada. Uma janela
já aberta é uma observação; reabrir consulta atualiza, edição usa CAS.

## Contexto entre composições

`contextual_bridges` declara origem e destino de composições diferentes da mesma
Obra. `context` consulta contribuições transitivamente; sucessão, causa,
motivação e condição continuam outras relações e não transmitem estado.
Escolhas de origem continuam na origem. Comparação temporária substitui somente
a escolha do contexto inicial; uma volta por ciclo não muda sua prévia.
Reutilizar um acontecimento não cria ponte nem iguala estados.

Consulta BFS com visita por participação; carregamento de composição somente
quando sua origem é pedida. Ciclos e valores diferentes conservam todas as
origens, sem precedência ou vencedor implícito. Origem fora da escolha atual é
indisponível, não falsa. Limites: 32 composições, 16.000 participações e orçamento
conservador de 32 MiB de dados consultados, incluindo notas. Excesso interrompe
explicitamente; não há combinação cartesiana ou recomposição por tecla.

Consultar origem permite editar e voltar. A trilha guarda composição,
participação, encaixe/opção de consulta e rolagem; 16 retornos, formatos antigos
aceitos. O contrato de continuidade do aplicativo continua único.

## Texto inteiro, seleção e ocorrência

Vínculos 30 de Documento inteiro permanecem intactos. `contextual_text_targets`
acrescenta âncora de Documento ou ocorrência de montagem. Não migra/duplica alvos
legados. Trecho pode ser escolhido entre marcas existentes ou marcado como nova
seleção numa consulta não editável: salvar marca + vínculo é uma única operação
atômica com observação completa do Documento, histórico e rollback.

Carregadores de Documento/montagem, igualdade de estado, versões, offsets Unicode
e estados de âncora existentes são reutilizados. Âncora ausente/vazia/não
reconciliada e ocorrência ausente/vazia/de referência são recusadas ao associar
ou abrir. Ocorrência oculta continua identificada como oculta, não é escolhida
silenciosamente no perfil. Mudar visibilidade ou versão permanece na montagem.

Identidade de âncora/ocorrência não é FK rígida para metadado embutido: edição
autoral pode remover o alvo. O vínculo fica pendente e consultável/removível;
não bloqueia a prosa nem inventa substituto. Os owners Documento/montagem têm FK.
Retirada não exclui texto, marca, bloco ou ocorrência. Usos reversos da escrita
e aviso de retirada de ocorrência incluem os vínculos contextuais.

SHA é observado na associação/conferência solicitada, não por tecla nem a cada
abertura de Documento inteiro. Hash de trecho/ocorrência é do recorte, não do
Documento todo. Abertura usa a navegação de trecho/ocorrência já existente.
Revisão opcional compara somente mudança técnica e guarda nota humana, nunca
infere fidelidade, divergência narrativa, realização ou significado.
Rascunho não aplicado de bloco continua outra autoridade: é possível abrir a
ocorrência para trabalhá-lo, mas associação e conferência da versão aplicada
são recusadas enquanto houver esse rascunho. O sistema não o aplica nem descarta
silenciosamente e não trata o hash da versão aplicada como hash do rascunho.

## Consistência e manutenção

Snapshots locais continuam 8 MiB/2.000 participações/4.000 por coleção; os 4.000
alvos textuais são combinados entre formatos. Página de referências tem orçamento
agregado de 8 MiB. IDs/owners são relidos canonicamente sob CAS; declarar ponte
valida snapshots de origem e destino na mesma transação. Origem consultada depois
é atual, não uma cópia congelada da decisão. Save As rebasa todos os project_id.
Histórico captura as tabelas novas pelo mesmo mecanismo de sessão SQLite, com
rótulos e navegação de usos. Retirada com dependentes exige desvinculação explícita.

Migração não interpreta vínculos antigos. Falha no registro 31 reverte DDL e
versão. Não há downgrade autoral destrutivo: voltar ao binário anterior exige
cópia completa anterior do Projeto. Referência publicada schema 28 não foi aberta
para migração. Sem commit, promoção, publicação ou início de D06.

## Verificação reproduzível

- `inde_contextual_delivery_tests`: origens/escolhas/ciclos, sete autoridades,
  paginação/filtro/alias, ausência de promoção, CAS, remoção, âncoras/seleção,
  ocorrências/revisão, histórico, Save As/reabertura, limite de 32 composições,
  migração 30→31 e rollback injetado. Testes C01 e C02–C04 permanecem regressões.
- `tools/build_ui_workspace_smoke.py --test contextual --delivery-context`:
  driver GTK ligado aos objetos reais. Origem externa/edição/retorno,
  referência/vista derivada/edição única, rascunho inválido preservado, navegação
  Unicode por âncora e ocorrência. Capturas de janelas reais para inspeção.
- `--sanitize-builder` instrumenta seis unidades privadas contextuais + driver;
  outras dependências Release, LSan desligado. `build_contextual_sanitizers.py`
  instrumenta cinco unidades de núcleo + teste. Não sanitização integral.
- `contextual_delivery_benchmark.cpp`: 10 composições, 1.000 participações,
  999 arestas e 1.000 referências. Trinta amostras e um aquecimento descartado.
  Medir isoladamente; não comparar seus números com benchmarks históricos de
  outras fixtures nem chamá-los de ganho global, produtividade ou conforto.

O fechamento funcional deve ser acompanhado do relatório/manifesto final em
outputs da tarefa, com resultados efetivamente executados e seus limites.
Teste verde e inspeção de render não são aceite humano, validação profissional,
acessibilidade certificada, IME/teclado físico, sessão longa ou release.
