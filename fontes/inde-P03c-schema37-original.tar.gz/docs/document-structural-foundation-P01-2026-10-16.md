# Documento estrutural P01 — fundação, não resmas/lentes concluídas

Continuação autorizada em2026-10-16 após discussão de documento contínuo,
folhas/resmas, topo por identidade, ocultação independente e filtros baseados em
marcações inclusive semânticas. A meta final não é um conjunto de mini-editores:
seleção/edição/cópia comuns sobre a leitura apresentada, sem atingir material
omitido, e vínculo com planejamento/editorial sem duplicar autoridade textual.

## Corte inicial

Documento.content continua sendo o corpo autoritativo. DocumentParagraphs é
metadado estrutural opcional: IDs locais ao Documento, início/fim Unicode e
identidades retiradas. Não guarda cópias de prosa, não equivale a folha/resma,
unidade narrativa, marcação semântica ou página física. LF separa parágrafos;
CR permanece texto, não é normalizado. Vazios e último parágrafo têm identidade.
Linhas visuais quebradas pela janela não criam unidades.

Os deltas exatos de inserção/exclusão atualizam limites sem varrer todo o corpo.
O motor trata limites/identidades em memória, não consulta SQLite por tecla.
Inserção antes de texto sobrevivente desloca sua identidade, mesmo em parágrafos
repetidos. Divisão mantém a identidade na primeira parte com conteúdo original
sobrevivente; outras partes recebem novas IDs. Junção conserva a primeira
identidade sobrevivente e retira as excedentes. Reescrever somente o corpo do
mesmo parágrafo mantém sua identidade estrutural, sem confirmar equivalência
semântica. Conteúdo removido não fica copiado no catálogo de retiradas; undo e
recuperação conservam seus estados pelos mecanismos existentes.

IDs retiradas não são reutilizadas nem redirecionam vínculos automaticamente.
Neste corte ainda não são alvos novos de planejamento/editorial. Trechos manuais
continuam âncoras existentes, com intervalo próprio e estados próprios. Não
converte âncora em parágrafo, não herda interpretação durante divisão/fusão.

## Interface e compatibilidade

O editor normal continua sendo Gtk::TextView contínuo. O menu Ações do Documento
ganha Parágrafos do documento…: consulta paginada50 e seleção do parágrafo no
mesmo buffer, sem molduras/cartões permanentes. Não exige nomear cada parágrafo.
Novos Documentos criados por essa interface identificam seu corpo automaticamente.
Documentos legados permanecem sem estrutura até Identificar parágrafos, uma
operação explícita e desfeita/refeita na sessão. APIs antigas/geradores que criam
documentos sem estrutura continuam aceitos; não migra corpos existentes em lote.

Digitação, Enter, exclusão, seleção transversal e clipboard continuam nos canais
nativos; o hook acompanha os deltas e recusa uma edição inválida antes de mudar
o buffer. Operações compostas de busca/clipboard usam a mesma transformação pura.
Restore/undo não reaplicam o delta duas vezes. IDs integram igualdade/CAS e o
orçamento do histórico; não são guardadas apenas em preferências ou widgets.
Desfazer a adoção pode restaurar o estado sem estrutura, mas somente mediante
CAS contra a estrutura exata observada; refazer devolve as mesmas identidades.
Uma atualização cega ou que desconhece os IDs existentes não pode descartá-los.

Schema34 aditivo: document_paragraph_structures, uma linha opcional por Documento,
FK composta deferred de owner/Documento, cascade na retirada, payload versionado
validado contra o corpo. Sem alteração automática de Documento legado. Save As
rebasa owner mantendo IDs; recortes independentes ganham novas IDs locais e aviso,
enquanto a origem integral congelada conserva as anteriores. Revisão/cópia de
resgate em novo Documento identifica seus novos parágrafos, não compartilha IDs.

Journal5 e snapshot documental2 incluem a estrutura; formatos anteriores1–4/1
continuam lidos. Quando não há estrutura, a codificação antiga é mantida. Uma
montagem importada continua independente da origem, conforme contrato anterior;
não foi convertida em escrita compartilhada neste corte. TXT/HTML não exportam
identidades; relatório explicita a limitação. Não são backups sem perdas.

Limites:100.000 identidades ativas+retiradas, payload estrutural32MiB, orçamento
existente de journal64MiB e histórico64MiB. Excesso é recusado sem truncar/podar;
nenhum benchmark de produtividade/latência/memória profissional foi certificado.

## Pendências e gates

P02: trechos/resmas e alternativas no Documento contínuo; P03: ocultação, camadas,
perfis e lentes editáveis de intervalos; P04: usos pelo planejamento/editorial.
Ainda não há setas de alternativas, filtro editável de diálogos nem substituição
editorial de folhas/resmas implementados por esta fundação.

Testes/logs/alcance no manifesto P01-verificacao.json da tarefa. Separar Release,
Debug/sanitizers focais, GTK de produção, integridade e passe humano. Aceite
humano aberto, sem D06, publicação, commit/promoção ou obra autoral aberta.
