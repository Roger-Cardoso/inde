# D01–D05, lote 02 — 2026-10-14

Autorização: “implemente o próximo lote, mas não considere isso como tendo
passado pelo aceite humano ainda”. Candidato na mesma branch isolada, baseado
em `89b47f27e83d76e1ef61a46cb6c29b8c75c305c4`, schema 28.

## Recorte implementado

- D02: `TextSearchCache` prepara uma projeção Unicode por texto/modo de caixa
  e a reutiliza nas consultas seguintes. A chave confere ID e texto exato,
  não apenas revisão. Uma projeção por worker, sem SQLite, GTK ou persistência;
  troca de texto/Documento/modo exige preparação nova. Consulta, palavra inteira
  e limite continuam avaliados de novo. Preparação cancelada não entra no cache.
  O mesmo worker de Localizar usa essa projeção; fila e gerações conservadas.
- D04: `move_unit` conserva a ordenação e normalização de posições, mas não
  executa UPDATE para uma unidade cuja posição resultante já é igual à lida.
  Em ordem normalizada, uma troca adjacente altera duas posições, não todas.
  Importação com posições densas continua normalizada pelo mesmo algoritmo.
  Guard transacional, leitura canônica e quatro ordens permanecem independentes.
- D05: o formulário de editar ficha conserva uma cópia imutável da observação.
  A sobrecarga `update_entity(input, expected)` usa UPDATE condicional comparando
  identidade, categoria, nome, resumo e timestamps dentro da transação. Mudança
  ou exclusão recusa a gravação e não cria histórico de alteração. O rascunho
  fica aberto, com explicação de como preservar/copiar e reabrir a ficha atual.
  Repetir Salvar não renova a observação nem força sobrescrita.

## Limites do contrato

O cache troca CPU repetida por retenção de um texto/projeção; não promete menor
memória. A primeira preparação, mudança de conteúdo e mudança de caixa ainda
pagam o percurso completo. Comparação exata continua O(n); a cópia GTK do
snapshot, a procura literal, o debounce e a entrega permanecem. O cache não
compartilha projeções com estatísticas, semântica ou revisão. É destruído com
o workspace; fechar o painel não elimina sua última projeção.

A escrita proporcional remove trabalho de UPDATE/captura, não a ordenação,
a leitura de evidência ou a validação completas. Não representa cache de plano.

CAS é por valor completo, não por contador duradouro. Uma alteração e retorno
ao mesmo valor, incluindo timestamps (ABA), não é detectável por esse contrato.
Aliases, relações e escopos são dados separados e não são fundidos nessa ficha.
A API preexistente de atualização programática sem observação permanece para
compatibilidade; a proteção nova cobre o formulário de ficha e chamadores que
usam explicitamente a sobrecarga guardada. Outros formulários não receberam CAS.
Não há merge automático, migração nem escolha semântica feita pelo sistema.

## Verificação reproduzível

- `inde_optimization_lot2_tests`: 4.480 consultas com variações de Unicode,
  caixa, palavra inteira, limite e repetição, comparadas à busca congelada da
  base aceita (`tests/text_search_reference.cpp`, apenas nos testes).
- Troca de ID/texto/modo, UTF-8 inválido, cancelamento e gerações do worker.
- Observadores SQL em fixture sintética contam UPDATEs de posições, conferem
  tokens intactos, normalização densa, no-op, guard obsoleto e ordem de linha.
- Ficha concorrente com timestamp idêntico, recusa sem histórico, rollback
  por falha no log, escritores em processos distintos e exclusão sem ressurreição.
- Driver GTK real estende o lote 01 com busca após troca de consulta/texto/caixa
  e formulário em conflito, repetição de Salvar, Cancelar/reabrir e edição válida.

O relatório de entrega registra as execuções efetivas e o benchmark. Não confundir
os testes acima com aceite humano. Conforto, teclado físico, IME, acessibilidade
e sessão longa continuam pendentes; lote 01 e base aceita estão preservados.

Resultado técnico final: Release completa, 35/35 CTest, ASan/UBSan focal e dois
passes GTK (claro/escuro) contra 111 objetos de produção passaram. Benchmark
pareado de 30 amostras, sem build/testes concorrentes: consultas repetidas em
524.280 bytes, p50 44,357 → 3,176 ms; em 2.097.120 bytes, 179,357 → 13,595 ms.
Primeira preparação não melhorou: 45,989 → 46,785 ms e 179,805 → 193,387 ms.
Funções isoladas; não mede GTK, memória de pico, latência total ou conforto.
Isso não altera o estado de aceite humano, que permanece pendente.
