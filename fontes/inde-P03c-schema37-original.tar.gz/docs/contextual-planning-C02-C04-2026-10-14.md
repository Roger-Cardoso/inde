# Composição contextual — continuidade C02/C03 e núcleo textual C04

Data: 2026-10-14. C01 avaliado como promissor, inicial/incompleto e sem aceite
humano; autorização explícita de continuar a implementação a fundo. Nenhuma
aprovação/promoção/publicação inferida. D06 fora do escopo; bancos autorais não
abertos. Fonte normativa: os 19 contratos de INDE-NEXT-COMPOSICAO-CONTEXTUAL-01.

## Fluxo implementado

Planejar → Plano narrativo → Composição contextual. Acontecimento compartilhado
continua distinto de participação local. Encaixes são opcionais e contêm opções;
vários participantes na mesma opção participam conjuntamente. Escolha só muda
por ação explícita; encaixe não resolvido é válido. Participações sem encaixe são
comuns, sem cópias quando a escolha muda. Uma opção pode incluir participações
distantes; não precisa de árvore completa ou duplicação de B–Y.

Contexto desta participação é consulta temporária. Declarações locais estruturam
somente o que o autor quer acompanhar: fato declarado/intenção/conhecimento/
crença/relato, assunto curto e valor opcional. Não são fichas globais de entidade,
simulação universal ou reconhecimento da prosa. Notas livres não são interpretadas.

Dependências têm origem/destino/tipo explícitos. Contexto recebido consulta as
declarações disponíveis da origem e seus antecedentes explicitamente ligados.
Sucessão/causa/motivação/condição não herdam automaticamente. Condição não é
linguagem de expressões nem verificação automática de cumprimento. Origem fora
da escolha é indisponível nesse recorte, não falsa. Valores diferentes conservam
ambas as origens. Ciclos têm visita limitada e aviso, sem precedência automática.

Consulta de origem permite editar uma declaração ali e voltar ao contexto
consultado; navegação não copia os dados. Comparação de uma opção mostra valores
e origens da escolha salva e da prévia, somente leitura, sem alterar a escolha.

Escrever neste contexto reutiliza vínculo existente em uma ação quando não há
ambiguidade; múltiplos Documentos exigem escolha explícita. Se não existe vínculo,
escolher Documento do Projeto ou criar vazio+vincular atomicamente. Abrir não
confirma realização; texto não é preenchido pelo planejamento. A transição usa
a continuidade existente, com volta ao planejamento e posições documentais.

Textos associados são muitos-para-muitos. Observar/conferir é deliberado e
opcional: SHA diferente indica somente conteúdo técnico alterado. Não compara
fidelidade narrativa, não cria continuidade por mudança de estilo nem exige
checklist/resumo paralelo. Conferência humana registra observação e nota livre,
não veredito automático. Desvincular preserva Documento e participação.

## Modelo e recuperação

Schema 30 aditivo: contextual_slots/options/option_members, declarations,
dependencies e text_links. Migração de 29 cria estruturas vazias, sem atribuir
escolhas ou significado a dados anteriores. FKs compostas preservam Projeto,
Obra e composição. As dependências deste recorte são internas à composição;
acontecimentos podem ser reutilizados em outras sem igualar contextos.

Snapshot/CAS inclui novas origens. Todo comando relê canonicamente sob transação;
rows fornecidas pelo chamador não são autoridade. UI retém identidade/revisão
para comandos e compartilha uma observação imutável nos seletores, evitando
uma cópia multi-MiB para cada botão. Não é cache confiado entre revisões.

Criação de Documento+vínculo usa a transação do repositório de escrita existente:
falha de CAS não deixa Documento órfão. Histórico do Projeto captura as novas
tabelas; prévia/reversão/conflitos continuam os mesmos mecanismos. Save As
rebate todos os owners novos, preservando identidades internas. Retirar uma
participação com encaixe/declarações/arestas/texto é recusado até desvinculação
explícita; conteúdo compartilhado e outras origens permanecem.

Destino textual é validado sem carregar corpo antes de trocar área. Falhas
conservam origem; se a escrita já apresentou modal de erro, a restauração espera
seu fechamento. Abrir vínculo existente não recalcula SHA do corpo. SHA é
calculado somente para associação, observação ou conferência solicitadas.

## Limites e pendências

Mantidos 200 composições por Obra, 2.000 participações por composição/2.000 usos
por acontecimento, snapshot 8 MiB, até 4.000 registros em cada coleção nova.
Consulta/seletores mostram até 50 por página; contextos percorrem somente origens
explicitamente pertinentes. Nenhum produto cartesiano das escolhas e nenhum
processamento da prosa por tecla. Navegação de origens guarda até 16 retornos.
Observação textual até 32 MiB; não é promessa de escala ilimitada/memória de pico.

Ainda não implementados: vínculos de contexto entre composições; referências
contextuais a identidades/relações/datas/mapas e integração derivada com vistas
legadas de unidades/linhas/fichas/tempo/mapa; vínculos textuais por âncora ou
ocorrência de composição documental; ergonomia profissional/acessibilidade/
sessão longa certificadas. Não declarar a meta inteira ou C04 completo.

## Evidência

Novo teste de núcleo: A1/A2 + conjunto + B–Y + Z1/Z2, origens transitive, escolhas
incompletas, contexto distinto sob identidade compartilhada, prévia sem mutação,
ciclo/valores diferentes/fontes inativas, CAS, retirada, texto M:N, criação
atômica/rollback, revisão/reversão, Save As e migração 29→30 com falha injetada.
UTF-8 longo sem título e corrupção sintética também verificados.

GTK de produção: criar/selecionar opções, declarar sem classificação automática,
manter rascunho inválido/obsoleto, contexto distante, consultar/editar origem e
voltar, vínculo e escrita longa, cursor45/bound20/rolagem preservados, atualização
sem reentrada, observação técnica opcional, prévia somente leitura, destino
inexistente e integridade. Driver espera prontidão com limite; não são teclado
físico/IME, conforto humano ou sanitização integral. Scripts/logs/resultados do
pacote de tarefa discriminam dependências Release e LSan desligado.

Roteiro humano: use somente fixture sintética do pacote; abrir Projeto antigo
pode migrar para 30. Retorno ao binário anterior exige cópia completa anterior,
não downgrade autoral in-place. Aceite humano de C01 e da continuidade permanece
aberto até novo veredito explícito.
